import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import '../../locator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/core/models/category.dart';
import 'package:grouped_list/grouped_list.dart';

class EditViewCategory extends StatefulWidget {
  const EditViewCategory({Key key}) : super(key: key);

  @override
  State<EditViewCategory> createState() => _EditViewCategoryState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _EditViewCategoryState extends State<EditViewCategory>  with TickerProviderStateMixin {

  String  Title = "";
  final CategoryIconService _categoryIconService = locator<CategoryIconService>();
  List<IncomingList> incominglist = [];
  List<ExpenseList> expenseList = [];

  List GrupData = [];
  List AccountData = [];
  List _elements = [];
  bool isEdit = true;
  var db = DBHelper();

@override
  void initState() {
    // TODO: implement initState
  getdataInit();
    super.initState();
  }

  getdataInit() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      Title =  prefs.getString("Tittle");
    });
    print(Title);

    if(Title == "Income"){
      incominglist = await db.getIncomingList("incominglist");

      for (var i = 0; i < incominglist.length; i++) {
        _elements.add({'name': incominglist[i].name, 'group': incominglist[i].name,  'id': incominglist[i].id});

      }
    }else if(Title == "Expense"){
      expenseList = await db.getExpenseList("expenselist");

      for (var i = 0; i < expenseList.length; i++) {
        _elements.add({'name': expenseList[i].name, 'group': expenseList[i].name,  'id': expenseList[i].id});

      }
    }



  }

  Widget stackBehindDismiss() {
    return Container(
      alignment: Alignment.centerRight,
      padding: EdgeInsets.only(right: 20.0),
      color: Colors.red,
      child: Icon(
        Icons.delete,
        color: Colors.white,
      ),
    );
  }

  void deleteItem(index, id) async {
    if(Title == "Income"){
      var delete = await db.updateIncomingList("incominglist", id,"1");
    }else if(Title == "Expense"){
      var delete = await db.updateExpenseList("expenselist", id,"1");
    }
    setState(() {
      _elements.removeAt(index);
    });


  }

  void undoDeletion(index, item, id) async {
    if(Title == "Income"){
      var delete = await db.updateIncomingList("incominglist", id,"0");
    }else if(Title == "Expense"){
      var delete = await db.updateExpenseList("expenselist", id,"0");
      print(delete.toString());
    }
    setState(() {
      _elements.insert(index, item);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 120,
        leading: Row(
          children: [
            IconButton(
              icon: Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.of(context).pushNamed("newtransaction");
              },
            ),
            Align(
                child: Text(Title, textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 12,),))
          ],
        ),
        centerTitle: true,
        title: Text(Title),
        actions: [
          isEdit ?
          IconButton(
            icon: Icon(
              Icons.delete,
              color: Colors.white,
            ),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      action: SnackBarAction(
                          label: "OK",
                          onPressed: () {
                          }),
                      content: Text("Please swipe list to delete")
                  )
              );
              setState(() {
                isEdit = false;
              });
              // Navigator.of(context).pushNamed("newtransaction");
            },
          ) : IconButton(
            icon: Icon(
              Icons.check,
              color: Colors.white,
            ),
            onPressed: () {
              setState(() {
                isEdit = true;
              });
              // Navigator.of(context).pushNamed("newtransaction");
            },
          ),
          IconButton(
            icon: Icon(
              Icons.add,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.of(context).pushNamed("add_category_view");
            },
          ),
        ],
      ),
      body: Container(
        // color: backgroundColor,
        child:

        GroupedListView<dynamic, String>(
          elements: _elements,
          groupBy: (element) => element['group'],
          groupComparator: (value1, value2) => value2.compareTo(value1),
          itemComparator: (item1, item2) => item1['name'].compareTo(item2['name']),
          order: GroupedListOrder.ASC,
          useStickyGroupSeparators: false,
          groupSeparatorBuilder: (String value) => Container(
            padding: const EdgeInsets.all(3.0),
            child: Container( ),
          ),
          indexedItemBuilder : (c, element, index) {
            return InkWell(
              child: Card(
                  elevation: 8.0,
                  margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
                  child: isEdit ?
                  Container(
                    // color: Colors.grey,
                    padding: EdgeInsets.all(20.0),
                    child: Text(element['name']),
                    ) : Dismissible(
                    background:  stackBehindDismiss() ,
                    key: ObjectKey(_elements[index]),
                    child: Container(
                      padding: EdgeInsets.all(20.0),
                      child: Text(element['name']),
                    ),
                    onDismissed: (direction) {
                      var item = _elements.elementAt(index);
                      deleteItem(index, element['id']);
                       ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            action: SnackBarAction(
                                label: "UNDO",
                                onPressed: () {
                                  //To undo deletion
                                  undoDeletion(index, item, element['id']);
                                }),
                              content: Text("Item deleted")
                          )
                      ) ;
                    },
                  )
                ,
                  ) ,
              onTap: () {
                setState(() {
                  print( element['id']);
                });
              },
            );
          },
          // itemBuilder: (c, element) {
          //
          //
          //
          // },
        )

      ),
    );
  }

}