import 'package:flutter/material.dart';
// import 'package:flutter_beautiful_popup/main.dart';
import 'package:flutter_simple_calculator/flutter_simple_calculator.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import '../../locator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/core/models/category.dart';
import 'package:intl/intl.dart';  //for date format
class AddCategoryView extends StatefulWidget {
  const AddCategoryView({Key key}) : super(key: key);

  @override
  State<AddCategoryView> createState() => _AddCategoryViewState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _AddCategoryViewState extends State<AddCategoryView>  with TickerProviderStateMixin {

  String  Title = "";
  final CategoryIconService _categoryIconService = locator<CategoryIconService>();
  List<Category> accountgrouplist = [];


  final _nameController = TextEditingController();
  bool _validateName = false;
  final formatter = new NumberFormat("#,###");
  var db = DBHelper();

@override
  void initState() {
    // TODO: implement initState
  getdataInit();
    super.initState();


  }

  getdataInit() async{

    accountgrouplist =  await _categoryIconService.accountgrouplist.toList();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {

      Title =  prefs.getString("Tittle");
    });

  }





  insertData(_nameController) async{
    if(Title == "Income"){
      var data = IncomingList(_nameController, "", "0",);
      await db.saveIncomingList("incominglist", data);
    }else if(Title == "Expense"){
      var data = ExpenseList(_nameController, "", "0",);
      await db.saveExpenseList("expenselist", data);
    }


    // final popup = BeautifulPopup(
    //   context: context,
    //   template: TemplateSuccess,
    // );
    // popup.show(
    //   barrierDismissible: false,
    //   close: Container(),
    //   title: 'Money & Revenue',
    //   content: 'Successfuly add data',
    //   actions: [
    //     popup.button(
    //       label: 'OK',
    //       onPressed: (){
    //         Navigator.of(context).pushNamed("edit_category_view");
    //       },
    //     ),
    //   ],
    //
    // );
  }
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 120,
        leading: Row(
          children: [
            IconButton(
              icon: Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.of(context).pushNamed("edit_category_view");
              },
            ),
            Align(
                child: Text("Account", textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 12,),))
          ],
        ),
        centerTitle: true,
        title: Text("Add"),

      ),
      body: new Column(
        children: <Widget>[

          new ListTile(

            leading: Container(
              child: Text("Name"),
              width: width / 7.0,
            ),
            title: new TextField(
              onChanged: (text){
                print(text);
              },
              // focusNode: myFocusNodeAccount,
              controller: _nameController,
              decoration: InputDecoration(
                errorText: _validateName ? 'Please input this field' : null,
              ),
              onTap: (){
              },
            ),
          ),


          SizedBox(height: 30,),
          Align(
              alignment: Alignment.center,
              child: Container(

                width: width / 1.2,
                child: RaisedButton(
                  child: Text(
                    'Save',
                    style: TextStyle(fontSize: 16),
                  ),
                  color: Colors.deepOrange,
                  textColor: Colors.white,
                  onPressed: () async {
                    setState(() {
                      _nameController.text.isEmpty ? _validateName = true : _validateName = false;  // _ammountController.text.isEmpty ? _validateAmmount = true : _validateAmmount = false;
                    });
                    if(_validateName == false ){
                      insertData(_nameController.text);
                    }
                  },
                ),
              )
          )
        ],
      )
    );
  }

}