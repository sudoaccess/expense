import 'package:flutter/material.dart';
import 'package:grouped_list/grouped_list.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';

class AccountListView extends StatefulWidget {
  const AccountListView({Key key}) : super(key: key);

  @override
  _AccountListViewState createState() => _AccountListViewState();
}

class _AccountListViewState extends State<AccountListView> {
  var _accountList = <AccountList>[];

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      final db = DBHelper();
      _accountList = await db.getAccountList("accountlist");
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Account')),
      body: SafeArea(
        child: Column(
          children: [
            _buildList(),
            _buildBottomAppBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildList() {
    return Expanded(
      child: GroupedListView<AccountList, String>(
        elements: _accountList,
        groupBy: (element) => element.accountgroup,
        groupSeparatorBuilder: (String groupByValue) {
          return Container(
            color: Colors.grey.shade200,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(groupByValue, style: TextStyle(color: Colors.grey.shade600)),
            ),
          );
        },
        itemBuilder: (context, element) {
          return InkWell(
            child: Container(
              color: Colors.white,
              child: Row(
                children: [
                  Checkbox(value: element.isChecked, onChanged: (value) {}),
                  Text(element.name, style: TextStyle(color: Colors.grey.shade800)),
                ],
              ),
            ),
            onTap: () {
              _accountList[_accountList.indexOf(element)].toggle();
              setState(() {});
            },
          );
        },
      ),
    );
  }

  Widget _buildBottomAppBar() {
    return Row(
      children: [
        _buildBottomButton('Cancellation', textColor: Colors.grey, onPressed: () {
          Navigator.pop(context);
        }),
        SizedBox(height: 36, child: VerticalDivider(width: 0)),
        _buildBottomButton('Ok', textColor: Colors.deepOrange, onPressed: () {
          _ok();
        }),
      ],
    );
  }

  Widget _buildBottomButton(String label, {VoidCallback onPressed, Color textColor}) {
    return Expanded(
      child: TextButton(
        child: Text(label.trim(), style: TextStyle(color: textColor)),
        style: TextButton.styleFrom(
          backgroundColor: Colors.white,
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
        onPressed: onPressed,
      ),
    );
  }

  void _ok() {
    final _selectedAccountList = _accountList.where((element) => element.isChecked).toList();
    Navigator.pop(context, _selectedAccountList);
  }
}
