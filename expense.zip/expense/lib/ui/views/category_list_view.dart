import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/models/category_list_model.dart';

class CategoryListView extends StatefulWidget {
  const CategoryListView({Key key}) : super(key: key);

  @override
  _CategoryListViewState createState() => _CategoryListViewState();
}

class _CategoryListViewState extends State<CategoryListView> {
  var _incomingList = <IncomingList>[];
  var _expenseList = <ExpenseList>[];

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      final db = DBHelper();
      _incomingList = await db.getIncomingList("incominglist");
      _expenseList = await db.getExpenseList("expenselist");
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Category', style: TextStyle(fontWeight: FontWeight.bold)),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Incoming'),
              Tab(text: 'Expense'),
            ],
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: TabBarView(
                children: [
                  _buildIncomingList(),
                  _buildExpenseList(),
                ],
              ),
            ),
            _buildBottomAppBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildIncomingList() {
    return ListView.separated(
      itemCount: _incomingList.length,
      separatorBuilder: (context, index) => Divider(height: 0),
      itemBuilder: (context, index) {
        return _buildIncomingItem(index, _incomingList[index]);
      },
    );
  }

  Widget _buildIncomingItem(int index, IncomingList data) {
    return InkWell(
      child: Container(
        color: Colors.white,
        child: Row(
          children: [
            Checkbox(value: data.isChecked, onChanged: (value) {}),
            Text(data.name.trim()),
          ],
        ),
      ),
      onTap: () {
        _incomingList[index].toggle();
        setState(() {});
      },
    );
  }

  Widget _buildExpenseList() {
    return ListView.separated(
      itemCount: _expenseList.length,
      separatorBuilder: (context, index) => Divider(height: 0),
      itemBuilder: (context, index) {
        return _buildExpenseItem(index, _expenseList[index]);
      },
    );
  }

  Widget _buildExpenseItem(int index, ExpenseList data) {
    return InkWell(
      child: Container(
        color: Colors.white,
        child: Row(
          children: [
            Checkbox(value: data.isChecked, onChanged: (value) {}),
            Text(data.name.trim()),
          ],
        ),
      ),
      onTap: () {
        _expenseList[index].toggle();
        setState(() {});
      },
    );
  }

  Widget _buildBottomAppBar() {
    return Row(
      children: [
        _buildBottomButton('Cancellation', textColor: Colors.grey, onPressed: () {
          Navigator.pop(context);
        }),
        SizedBox(height: 36, child: VerticalDivider(width: 0)),
        _buildBottomButton('Ok', textColor: Colors.deepOrange, onPressed: () {
          _ok();
        }),
      ],
    );
  }

  Widget _buildBottomButton(String label, {VoidCallback onPressed, Color textColor}) {
    return Expanded(
      child: TextButton(
        child: Text(label.trim(), style: TextStyle(color: textColor)),
        style: TextButton.styleFrom(
          backgroundColor: Colors.white,
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
        onPressed: onPressed,
      ),
    );
  }

  void _ok() {
    final selectedList = <String, dynamic>{};
    selectedList['incoming'] = _incomingList.where((element) => element.isChecked).toList();
    selectedList['expense'] = _expenseList.where((element) => element.isChecked).toList();
    Navigator.pop(context, selectedList);
  }
}
