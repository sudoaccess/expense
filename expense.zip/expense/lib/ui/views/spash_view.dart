import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/models/category.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/ui/views/home_view.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:splashscreen/splashscreen.dart';

import '../../locator.dart';

class SpashView extends StatefulWidget {
  const SpashView({Key key}) : super(key: key);

  @override
  State<SpashView> createState() => _SpashViewtState();
}


class _SpashViewtState  extends State<SpashView>   {


  @override
  void initState() {
    super.initState();
  }




  @override
  Widget build(BuildContext context) {

    return Scaffold(
        backgroundColor: backgroundColor,
        body: SafeArea(child: buildSpashScreen()));
  }

  buildSpashScreen() {
    return SplashScreen(
        seconds: 2,
        navigateAfterSeconds: HomeView(),
        title: new Text(
          'Revenue & Payment',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w600,color:Colors.white),
        ),
        image: new Image.asset(
          'assets/icons/icon.png',
          height: 100,
          width: 100,
        ),
        backgroundColor: Colors.black,
        loadingText: Text(
          'A place for all of your expenses.',
          style: TextStyle(fontStyle: FontStyle.italic, color: Colors.white),
        ),
        photoSize: 100.0,
        loaderColor: Colors.orange);
  }
}
