import 'package:flutter/material.dart';
// import 'package:flutter_beautiful_popup/main.dart';
import 'package:flutter_simple_calculator/flutter_simple_calculator.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import '../../locator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/core/models/category.dart';
import 'package:intl/intl.dart';  //for date format
class EditViewAccountGroup extends StatefulWidget {
  const EditViewAccountGroup({Key key}) : super(key: key);

  @override
  State<EditViewAccountGroup> createState() => _EditViewAccountGroupState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _EditViewAccountGroupState extends State<EditViewAccountGroup>  with TickerProviderStateMixin {

  String  Title = "";
  final CategoryIconService _categoryIconService = locator<CategoryIconService>();
  List<Category> accountgrouplist = [];

  final _groupController = TextEditingController();
  final _nameController = TextEditingController();
  final _ammountController = TextEditingController();
  final _noteController = TextEditingController();

  bool _validateGroup = false;
  bool _validateName = false;
  bool _validateAmmount = false;
  bool _validateNote = false;
  final formatter = new NumberFormat("#,###");
  bool _checkConfiguration() => true;
  var db = DBHelper();

@override
  void initState() {
    // TODO: implement initState
  getdataInit();
    super.initState();

  if (_checkConfiguration()) {
    Future.delayed(Duration.zero,() {
      _showModalGroup(context);
    });
  }
  }

  getdataInit() async{

    accountgrouplist =  await _categoryIconService.accountgrouplist.toList();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {

      Title =  prefs.getString("Tittle");
    });

  }

  _showModalAmount(context) {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Column(
            children: [
              Container(
                height: 50,
                color: backgroundColor,
                child:Padding(
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child:  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Amount", style: TextStyle(color: Colors.white),),
                      Row(
                        children: [
                          // Text("Today", style: TextStyle(color: Colors.white),),
                          IconButton(
                            icon: Icon(
                              Icons.close,
                              color: Colors.white,
                            ),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                          ),
                        ],
                      )

                    ],
                  ),
                ),
              ),
              Expanded(child:
              SimpleCalculator(
                // onTappedDisplay: (data, TapDownDetails){
                //   print(data);
                //   print(TapDownDetails);
                // },
                value: 0,
                hideExpression: true,
                onChanged: (key, value, expression) {
                  var realValue = value.round();
                  _ammountController.text = formatter.format(realValue);
                  if(key.toString() == "OK"){
                    Navigator.pop(context);
                  }

                },
                theme:  CalculatorThemeData(
                  displayColor: secondaryColor,
                  displayStyle: const TextStyle(fontSize: 80, color: Colors.yellow),
                ),
              ))
            ],

          ) ;
        });
  }

  _showModalGroup(context) {
    showModalBottomSheet(
        isScrollControlled:true,
        context: context,
        builder: (context) {
          return   Container(
            color: backgroundColor,
            height:  MediaQuery.of(context).size.height /1.4,
            child:  Column(
              children: [
                ListTile(
                  leading: Padding(
                    padding: EdgeInsets.only(left: 10),
                    child: Text('Account Group', style: TextStyle(fontSize: 15 ,color: Colors.white, fontWeight: FontWeight.bold),),
                  ),
                  title:  Align(
                  alignment : Alignment.topRight,
                    child: IconButton(
                      icon: Icon(
                        Icons.close,
                        color: Colors.white,
                      ),
                      onPressed: () {
                        if(_groupController.text == ""){
                          _groupController.text = accountgrouplist[0].name;
                        }

                        Navigator.pop(context);
                      },
                    ),
                  ),
                ),
                Divider(),
                Expanded(
                    child: ListView.separated(
                    padding: const EdgeInsets.all(8),
                    itemCount: accountgrouplist.length,
                    itemBuilder: (BuildContext context, int index) {
                      return GestureDetector(
                        onTap: (){
                          _groupController.text = accountgrouplist[index].name;
                          Navigator.pop(context);
                          print(index);
                        },
                        child: Container(
                          height: 25,
                          // color: Colors.amber[accountgrouplist[index]],
                          child: Padding(
                            padding: EdgeInsets.only(left: 10),
                            child: Text(' ${accountgrouplist[index].name}', style: TextStyle(fontSize: 15 ,color: Colors.white),),
                          ),
                        ),
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) => const Divider(color: Colors.white,),
                )
                )
              ],
            ),
          ) ;
        });
  }

  insertGroup(_groupController, _nameController, _ammountController, _noteController) async{
    var suggestion = AccountList(_nameController, "",_groupController,  _ammountController, _noteController, "0");
    await db.saveAccountList("accountlist", suggestion);
    // final popup = BeautifulPopup(
    //   context: context,
    //   template: TemplateSuccess,
    // );
    // popup.show(
    //   barrierDismissible: false,
    //   close: Container(),
    //   title: 'Money & Revenue',
    //   content: 'Successfuly add data',
    //   actions: [
    //     popup.button(
    //       label: 'OK',
    //       onPressed: (){
    //         Navigator.of(context).pushNamed("edit_account_view");
    //       },
    //     ),
    //   ],
    //
    // );
  }
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 120,
        leading: Row(
          children: [
            IconButton(
              icon: Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.of(context).pushNamed("edit_account_view");
              },
            ),
            Align(
                child: Text("Account", textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 12,),))
          ],
        ),
        centerTitle: true,
        title: Text("Add"),

      ),
      body: new Column(
        children: <Widget>[
          new ListTile(
            leading: Container(
              child: Text("Group"),
              width: width / 4.5,
            ),
            title: new TextField(
              controller: _groupController,
              readOnly: true,
              decoration: InputDecoration(
                errorText: _validateGroup ? 'Please input this field' : null,
              ),
              onTap: (){

                _showModalGroup(context);
              },
            ),
          ),
          new ListTile(

            leading: Container(
              child: Text("Name"),
              width: width / 4.5,
            ),
            title: new TextField(
              onChanged: (text){
                print(text);
              },
              // focusNode: myFocusNodeAccount,
              controller: _nameController,
              decoration: InputDecoration(
                errorText: _validateName ? 'Please input this field' : null,
              ),
              onTap: (){
                // _showModalAccount(context);
              },

            ),
          ),

          new ListTile(
            leading: Container(
              child: Text("Amount"),
              width: width / 4.5,
            ),
            title: new TextField(
              decoration: InputDecoration(
                errorText: _validateAmmount ? 'Please input this field' : null,
              ),
              controller: _ammountController,
              readOnly: true,
              onTap: (){
                _showModalAmount(context);
              },
            ),
          ),
          new ListTile(
            leading: Container(
              child: Text("Note"),
              width: width / 4.5,
            ),
            title: new TextField(
              controller: _noteController,
            ),
          ),
          SizedBox(height: 30,),
          Align(
              alignment: Alignment.center,
              child: Container(

                width: width / 1.2,
                child: RaisedButton(
                  child: Text(
                    'Save',
                    style: TextStyle(fontSize: 16),
                  ),
                  color: Colors.deepOrange,
                  textColor: Colors.white,
                  onPressed: () async {
                    setState(() {
                      _groupController.text.isEmpty ? _validateGroup = true : _validateGroup = false;
                      _nameController.text.isEmpty ? _validateName = true : _validateName = false;
                      // _categoryController.text.isEmpty ? _validateCategory= true : _validateCategory = false;
                      // _ammountController.text.isEmpty ? _validateAmmount = true : _validateAmmount = false;
                    });
                    // final index = DefaultTabController.of(context).index;
                    // String type = "";
                    // if(index == 0){
                    //   type = "income";
                    // }else if(index == 1){
                    //   type = "expense";
                    // }else{
                    //   type = "transfer";
                    // }
                    // print(_validateAccount.toString());
                    if(_validateGroup == false && _validateName == false ){
                      insertGroup(_groupController.text, _nameController.text, _ammountController.text, _noteController.text);
                      // await model.addTransaction(context, type, _dateController.text, _noteController.text, imageLocalDir, imageLocalDir2, _pictureDescController.text, _ammountController.text, dataCategory, dataAcount);
                    }

                    //
                  },
                ),
              )
          )

        ],
      )

    );
  }

}