import 'dart:collection';

import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/enums/viewstate.dart';
import 'package:moneymanager/core/models/category.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';

import 'package:moneymanager/ui/views/base_view.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/account.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/app_fab.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/app_bar_title_widget.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/calendar_popup.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/empty_transaction_widget.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/home.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/list_month.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/list_week.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/month_year_picker_widget.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/pop_up.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/setting.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/table_calendar.dart';
import 'package:moneymanager/ui/widgets/stats_view/stats.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/summary_widget.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/transactions_listview_widget.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:intl/intl.dart'; //for date format
import 'package:moneymanager/ui/widgets/indonesia_format.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../locator.dart';
import '../../globals.dart' as globals;

class HomeView extends StatefulWidget {
  const HomeView({Key key}) : super(key: key);

  @override
  State<HomeView> createState() => _HomeViewtState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _HomeViewtState extends State<HomeView> with TickerProviderStateMixin {
  TabController _tabController, _tabControllerMenu;
  String tittle = "";
  var waktu = Waktu();
  DateTime datetime = DateTime.now();
  final formatCurrency = new NumberFormat.simpleCurrency(locale: 'id_ID');
  CalendarController _controller;
  Map<DateTime, List<dynamic>> _events;
  List listData = [];

  List listDataWeekday = [];

  List months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'Mei',
    'Jun',
    'Jul',
    'Agt',
    'Sep',
    'Okt',
    'nov',
    'Des'
  ];
  List monthsAngka = [
    '01',
    '02',
    '03',
    '04',
    '05',
    '06',
    '07',
    '08',
    '09',
    '10',
    '11',
    '12'
  ];
  List monthsList = [];
  List<dynamic> _selectedEvents;
  // int _selectedIndex = 0;
  bool floatingShow = true;

  HomeModel model2;
  String thisDay, thisMonth;

  final CategoryIconService _categoryIconService =
      locator<CategoryIconService>();
  var Listweek2;

  final formatter = new NumberFormat("#,###");

  @override
  void initState() {
    super.initState();
    _controller = CalendarController();
    _tabController = TabController(length: 3, vsync: this);
    _tabControllerMenu = TabController(length: 5, vsync: this);
    setState(() {
      DateTime tempData = DateTime.now();
      var datatemp = tempData.toString().split(" ");
      var datatemp2 = datatemp[0].toString().split("-");

      thisDay = datatemp2[2].toString();
      thisMonth = datatemp2[1].toString();
      globals.dataBodyCalendar =  TableCalendarWidgetView(model: null,  currentTimeModel: null);
    });

    getMothList();
    // requestPermission();
  }

  void getMothList() async {
    var now = new DateTime.now();
    var current_mon = now.month;

    for (var i = 0; i < months.length; i++) {
      if (i < current_mon) {
        monthsList.add({"bulanVar": months[i], "bulanAngka": monthsAngka[i]});
      }
    }

    return;
  }

  void _showOverlay(BuildContext context) {
    Navigator.of(context).push(TutorialOverlay());
  }

  void _showPopup(BuildContext context, date, model) {
    Navigator.of(context).push(CalendarPopup(date.toString(), model));
  }

  DateTime getDate(DateTime d) => DateTime(d.year, d.month, d.day);


  _onItemTapped(index, model) {
    setState(() {
      globals.selectedIndexBottomNav = index;

      if (index == 0) {
        floatingShow = true;
        globals.dataBody = HomeBar(model.currentTimeModel, model, globals.dataBodyCalendar);
        // return HomeBar(datetime, model);
      } else if (index == 1) {
        globals.dataBody = StatsBar(model);
        floatingShow = false;
        // return StatsBar();
      } else if (index == 2) {
        globals.dataBody = AccountBar();
        floatingShow = false;
        // return AccountBar();
      } else {
        globals.dataBody = AccountBar();
        floatingShow = false;
        // return SettingBar();
      }
    });

  }

  getAppBar(index, model) {
    DateTime dataDate = DateTime.parse(model.currentTimeModel.toString());
    tittle = Waktu(dataDate).LLL() + " " + dataDate.year.toString();
    if (index == 0) {
      return AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.search,
            color: Colors.white,
          ),
          onPressed: () {
            _showOverlay(context);
            // do something
          },
        ),
        centerTitle: true,
        title: Text('Transaction'),
        bottom: TabBar(
          onTap: (index) async {
            if (index == 0) {
              if (globals.isShowing) {
                setState(() {
                  globals.isShowing = false;
                });
                // await  model.titleClicked();
              }

              await model.prevMonth();
              setState(() {
                tittle = Waktu(model.currentTimeModel).LLL() +
                    " " +
                    model.currentTimeModel.year.toString();
              });
              // prevMonth(model.currentTimeModel, context, model);

              await model.update(model.currentTimeModel.toString());
              globals.dataBody = HomeBar(model.currentTimeModel, model, globals.dataBodyCalendar);
            } else if (index == 1) {

              // await  model.titleClicked();
              setState(() {
                if (globals.isShowing) {
                  globals.isShowing = false;
                } else {
                  globals.isShowing = true;
                }
                globals.dataBody = HomeBar(model.currentTimeModel, model, globals.dataBodyCalendar);
              });

            } else {

              setState(() {
                globals.isShowing = false;
              });

              await model.nextMonth();
              setState(() {
                tittle = Waktu(model.currentTimeModel).LLL() + " " +model.currentTimeModel.year.toString();
              });

              // nextMonth(model.currentTimeModel, context, model);
              await model.update(model.currentTimeModel.toString());
              globals.dataBody = HomeBar(model.currentTimeModel, model, globals.dataBodyCalendar);
            }
          },
          indicatorColor: Colors.transparent,
          controller: _tabController,
          tabs: <Widget>[
            Tab(
              icon: Icon(Icons.chevron_left),
            ),
            Tab(
                child: Center(
              child: Text(tittle),
            )),
            Tab(
              icon: Icon(Icons.chevron_right),
            )
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return BaseView<HomeModel>(
      onModelReady: (model) async {
        await model.init();

        globals.dataBody = HomeBar(model.currentTimeModel, model, globals.dataBodyCalendar);
        Listweek2 = Listweek(listData: listData, model: model);
        setState(() {
          globals.dataBodyCalendar =  TableCalendarWidgetView(model: model,  currentTimeModel: model.currentTimeModel);
        });
      },
      builder: (context, model, child) => Scaffold(
          // appBar: getAppBar(_selectedIndex, model),
          bottomNavigationBar: BottomNavigationBar(
            backgroundColor: backgroundColor,
            showUnselectedLabels: true,
            items: <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(Icons.book_outlined),
                label: '$thisDay/$thisMonth',
                backgroundColor: backgroundColor,
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.bar_chart),
                label: 'Stats',
                backgroundColor: backgroundColor,
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.account_balance_wallet),
                label: 'Account',
                backgroundColor: backgroundColor,
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.settings),
                label: 'Settings',
                backgroundColor: backgroundColor,
              ),
            ],
            currentIndex:  globals.selectedIndexBottomNav,
            selectedItemColor: Colors.amber[800],
            onTap: (index) {
              _onItemTapped(index, model);
            },
          ),
          floatingActionButton: Visibility(
            visible: floatingShow,
            child: AppFAB(model.closeMonthPicker),
          ),
          body: globals.dataBody),
    );
  }


}
