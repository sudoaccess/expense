import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import '../../locator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/core/models/category.dart';
import 'package:grouped_list/grouped_list.dart';

class EditViewAccount extends StatefulWidget {
  const EditViewAccount({Key key}) : super(key: key);

  @override
  State<EditViewAccount> createState() => _EditViewAccountState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _EditViewAccountState extends State<EditViewAccount>  with TickerProviderStateMixin {

  String  Title = "";
  final CategoryIconService _categoryIconService = locator<CategoryIconService>();
  List<AccountList> accountgrouplist = [];

  List GrupData = [];
  List AccountData = [];
  List _elements = [];
  bool isEdit = true;
  var db = DBHelper();

@override
  void initState() {
    // TODO: implement initState
  getdataInit();
    super.initState();
  }

  getdataInit() async{

    accountgrouplist = await db.getAccountList("accountlist");

    for (var i = 0; i < accountgrouplist.length; i++) {
      _elements.add({'name': accountgrouplist[i].name, 'group': accountgrouplist[i].accountgroup, 'id': accountgrouplist[i].id});


    }
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      Title =  prefs.getString("Tittle");
    });

  }

  Widget stackBehindDismiss() {
    return Container(
      alignment: Alignment.centerRight,
      padding: EdgeInsets.only(right: 20.0),
      color: Colors.red,
      child: Icon(
        Icons.delete,
        color: Colors.white,
      ),
    );
  }

  void deleteItem(index, id) async {
    var delete = await db.updateAccountList("accountlist", id,"1");

    setState(() {
      _elements.removeAt(index);
    });
  }

  void undoDeletion(index, item, id) async {
    var undo = await db.updateAccountList("accountlist", id, "0");
    setState(() {
      _elements.insert(index, item);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 120,
        leading: Row(
          children: [
            IconButton(
              icon: Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.of(context).pushNamed("newtransaction");
              },
            ),
            Align(
                child: Text(Title, textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 12,),))
          ],
        ),
        centerTitle: true,
        title: Text("Account"),
        actions: [
          isEdit ?
          IconButton(
            icon: Icon(
              Icons.delete,
              color: Colors.white,
            ),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      action: SnackBarAction(
                          label: "OK",
                          onPressed: () {
                          }),
                      content: Text("Please swipe list to delete")
                  )
              );
              setState(() {
                isEdit = false;
              });
              // Navigator.of(context).pushNamed("newtransaction");
            },
          ) : IconButton(
            icon: Icon(
              Icons.check,
              color: Colors.white,
            ),
            onPressed: () {
              setState(() {
                isEdit = true;
              });
              // Navigator.of(context).pushNamed("newtransaction");
            },
          ),
          IconButton(
            icon: Icon(
              Icons.add,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.of(context).pushNamed("edit_account_group_view");
            },
          ),
        ],
      ),
      body: Container(
        // color: backgroundColor,
        child:   GroupedListView<dynamic, String>(
          elements: _elements,
          groupBy: (element) => element['group'],
          groupComparator: (value1, value2) => value2.compareTo(value1),
          itemComparator: (item1, item2) => item1['name'].compareTo(item2['name']),
          order: GroupedListOrder.ASC,
          useStickyGroupSeparators: true,
          groupSeparatorBuilder: (String value) => Padding(
            padding: const EdgeInsets.all(3.0),
            child: Text(
              value,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, ),
            ),
          ),
          indexedItemBuilder : (c, element, index) {
            return InkWell(
              child: Card(
                  elevation: 8.0,
                  margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
                  child: isEdit ?
                  Container(
                    // color: Colors.grey,
                    padding: EdgeInsets.all(20.0),
                    child: Text(element['name']),
                    ) : Dismissible(
                    background:  stackBehindDismiss() ,
                    key: ObjectKey(_elements[index]),
                    child: Container(
                      padding: EdgeInsets.all(20.0),
                      child: Text(element['name']),
                    ),
                    onDismissed: (direction) {
                      var item = _elements.elementAt(index);
                      deleteItem(index, element['id']);
                       ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            action: SnackBarAction(
                                label: "UNDO",
                                onPressed: () {
                                  //To undo deletion
                                  undoDeletion(index, item, element['id']);
                                }),
                              content: Text("Item deleted")
                          )
                      ) ;
                    },
                  )
                ,
                  ) ,
              onTap: () {
                setState(() {
                  print( element['id']);
                });
              },
            );
          },
          // itemBuilder: (c, element) {
          //
          //
          //
          // },
        )

      ),
    );
  }

}