import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:moneymanager/core/services/moordatabase_service.dart';
import 'package:moneymanager/core/viewmodels/search_model.dart';
import 'package:moneymanager/ui/views/account_list_view.dart';
import 'package:moneymanager/ui/views/base_view.dart';
import 'package:moneymanager/ui/views/category_list_view.dart';

import '../../core/models/category_list_model.dart';

class SearchView extends StatefulWidget {
  const SearchView({Key key}) : super(key: key);

  @override
  _SearchViewState createState() => _SearchViewState();
}

class _SearchViewState extends State<SearchView> {
  SearchModel _searchModel;
  final _searchController = TextEditingController();
  final _minAmountController = TextEditingController();
  final _maxAmountController = TextEditingController();
  final _searchFocusNode = FocusNode();
  var _searchFocus = false;
  var _isSearchEmpty = true;
  var _popMenuLabel = 'Seluruhnya';
  var _accountList = <AccountList>[];
  var _incomingList = <IncomingList>[];
  var _expenseList = <ExpenseList>[];
  var _accountLabel = '';
  var _catagoryLabel = '';
  var _option = true;

  @override
  void initState() {
    super.initState();

    _searchFocusNode.addListener(() {
      _searchFocus = _searchFocusNode.hasFocus;
      setState(() {});
    });

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _searchModel.getAllTransactions();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _minAmountController.dispose();
    _maxAmountController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BaseView<SearchModel>(
      builder: (context, model, child) {
        _searchModel = model;

        return Scaffold(
          appBar: AppBar(
            title: Text('Pencarian'),
            actions: [_buildPopMenu()],
          ),
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              // child: Table(
              //   defaultColumnWidth: IntrinsicColumnWidth(),
              //   children: [
              //     TableRow(children: [
              //       Text('Account'),
              //       _buildAccountField(),
              //     ]),
              //     TableRow(children: [
              //       Text('Category'),
              //       _buildCategoryField(),
              //     ]),
              //     TableRow(
              //       children: [
              //       Text('Amount'),
              //       _buildAmountField(),
              //     ]),
              //   ],
              // ),
              child: Column(
                children: [
                  _buildSearchTextField(model),
                  _option
                      ? Column(
                          children: [
                            SizedBox(height: 16),
                            _buildAccountField(),
                            SizedBox(height: 8),
                            _buildCategoryField(),
                            SizedBox(height: 8),
                            _buildAmountField(model),
                          ],
                        )
                      : SizedBox(),
                  SizedBox(height: 8),
                  _buildToggleOption(),
                  _buildTransactionList(model),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildPopMenu() {
    return PopupMenuButton(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(_popMenuLabel),
        ),
      ),
      itemBuilder: (context) => [
        PopupMenuItem(child: Text('Seluruhnya'), value: 0),
        PopupMenuItem(child: Text('Mingguan'), value: 1),
        PopupMenuItem(child: Text('Bulanan'), value: 2),
        PopupMenuItem(child: Text('Tahunan'), value: 3),
        PopupMenuItem(child: Text('Periode'), value: 4),
      ],
      onSelected: (value) {
        if (value == 0) {
          _popMenuLabel = 'Seluruhnya';
        } else if (value == 1) {
          _popMenuLabel = 'Mingguan';
        } else if (value == 2) {
          _popMenuLabel = 'Bulanan';
        } else if (value == 3) {
          _popMenuLabel = 'Tahunan';
        } else if (value == 4) {
          _popMenuLabel = 'Periode';
        }
        setState(() {});
      },
    );
  }

  Widget _buildSearchTextField(SearchModel model) {
    return Row(
      children: [
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextField(
              autofocus: true,
              focusNode: _searchFocusNode,
              controller: _searchController,
              decoration: InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search),
                suffixIcon: _isSearchEmpty
                    ? SizedBox()
                    : IconButton(
                        icon: Icon(Icons.close),
                        onPressed: () {
                          _searchController.text = '';
                          _isSearchEmpty = true;
                          model.getTransaction(memo: '');
                          setState(() {});
                        },
                      ),
              ),
              onChanged: (value) {
                _isSearchEmpty = value.isEmpty;
                model.getTransaction(memo: value);
                setState(() {});
              },
            ),
          ),
        ),
        _searchFocus && (MediaQuery.of(context).viewInsets.bottom > 0)
            ? TextButton(
                child: Text('Cancel'),
                onPressed: () {
                  FocusScope.of(context).requestFocus(FocusNode());
                },
              )
            : SizedBox(),
      ],
    );
  }

  Widget _buildAccountField() {
    return InkWell(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Account'),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_accountLabel),
                Divider(),
              ],
            ),
          ),
        ],
      ),
      onTap: () async {
        final result = await Navigator.push(context, MaterialPageRoute(builder: (context) {
          return AccountListView();
        }));

        if (result is List<AccountList>) {
          var accountLabels = <String>{};

          _accountList = result;
          _accountList.forEach((element) {
            accountLabels.add(element.name.trim());
          });

          _accountLabel = accountLabels.join(', ');
          setState(() {});
        }
      },
    );
  }

  Widget _buildCategoryField() {
    return InkWell(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Catagory'),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_catagoryLabel),
                Divider(),
              ],
            ),
          ),
        ],
      ),
      onTap: () async {
        final result = await Navigator.push(context, MaterialPageRoute(builder: (context) {
          return CategoryListView();
        }));

        if (result is Map<String, dynamic>) {
          var categoryLabels = <String>{};

          _incomingList = result['incoming'] as List<IncomingList>;
          _incomingList.forEach((element) {
            categoryLabels.add(element.name.trim());
          });

          _expenseList = result['expense'] as List<ExpenseList>;
          _expenseList.forEach((element) {
            categoryLabels.add(element.name.trim());
          });

          _catagoryLabel = categoryLabels.join(', ');
          setState(() {});
        }
      },
    );
  }

  Widget _buildAmountField(SearchModel model) {
    return Row(
      children: [
        Text('Amount'),
        SizedBox(width: 16),
        Expanded(
          child: TextField(
            controller: _minAmountController,
            textAlign: TextAlign.center,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(12),
            ],
            decoration: InputDecoration(hintText: 'Min'),
            onChanged: (value) {
              model.getTransaction(min: value);
            },
          ),
        ),
        SizedBox(width: 8),
        Text('~'),
        SizedBox(width: 8),
        Expanded(
          child: TextField(
            controller: _maxAmountController,
            textAlign: TextAlign.center,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(12),
            ],
            decoration: InputDecoration(hintText: 'Max'),
            onChanged: (value) {
              model.getTransaction(max: value);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildToggleOption() {
    if (_option) {
      return IconButton(
        icon: Icon(Icons.keyboard_arrow_up),
        onPressed: () {
          _option = false;
          setState(() {});
        },
      );
    } else {
      return IconButton(
        icon: Icon(Icons.keyboard_arrow_down),
        onPressed: () {
          _option = true;
          setState(() {});
        },
      );
    }
  }

  Widget _buildTransactionList(SearchModel model) {
    return Expanded(
      child: ListView.separated(
        itemCount: model.transactions.length,
        separatorBuilder: (context, index) => Divider(),
        itemBuilder: (context, index) {
          final data = model.transactions[index];

          debugPrint(data.toJsonString());

          return Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${data.day}/${data.month}/${data.year}', style: TextStyle(color: Colors.grey)),
                  Text(data.category, style: TextStyle(color: Colors.grey)),
                ],
              ),
              SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(data.memo, style: TextStyle(fontSize: 16)),
                    Text(data.account, style: TextStyle(color: Colors.grey)),
                  ],
                ),
              ),
              SizedBox(width: 16),
              Text(data.amount.toString(), style: TextStyle(color: Colors.deepOrange)),
            ],
          );
        },
      ),
    );
  }

  void _showSnackbar() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Yay! A SnackBar!'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () {
            // Some code to undo the change.
          },
        ),
      ),
    );
  }
}
