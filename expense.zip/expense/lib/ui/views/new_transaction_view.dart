import 'dart:convert';
import 'dart:developer';

import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_simple_calculator/flutter_simple_calculator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/services/moordatabase_service.dart';
import 'package:moneymanager/core/viewmodels/new_transcation_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/ui/shared/ui_helpers.dart';
import 'package:moneymanager/ui/views/base_view.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/modal_sheet.dart';
import 'package:moneymanager/ui/widgets/new_transaction_view_widget/transaction_type_spinner.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import 'package:photo_view/photo_view.dart';
import 'dart:io';
/// This is the stateless widget that the main application instantiates.
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';

class NewTransactionView extends StatefulWidget {
  const NewTransactionView({Key key}) : super(key: key);

  @override
  State<NewTransactionView> createState() => _NewTransactionViewtState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _NewTransactionViewtState extends State<NewTransactionView> with SingleTickerProviderStateMixin {

// class NewTransactionView extends StatelessWidget {

  final _dateController = TextEditingController();
  final _accountController = TextEditingController();
  final _categoryController = TextEditingController();
  final _ammountController = TextEditingController();
  final _noteController = TextEditingController();
  final _pictureDescController = TextEditingController();
  final _fromController = TextEditingController();
  final _toController = TextEditingController();


  bool _validateDate = false;
  bool _validateAccount = false;
  bool _validateCategory = false;
  bool _validateAmmount= false;
  bool _validateFrom = false;
  bool _validateTo = false;


  int dataAcount = 0;
  String dataFrom = "0";
  String dataTo = "0";
  int dataCategory = 0;
  String imageLocalDir = "";
  String imageLocalDir2 = "";
  TabController _tabController;
  List DataAccount = [];
  List DataIncomingList = [];
  List DataExpenseList = [];
  String Tittle = "Income";
  FocusNode myFocusNodeAccount;
  bool _checkConfiguration() => true;
  final formatter = new NumberFormat("#,###");


  @override
  void initState() {
    super.initState();
    _tabController = TabController(vsync: this, length: 3);
    _tabController.addListener(_handleTabSelection);
    myFocusNodeAccount = FocusNode();

    functionCheckvalue();

  }


  @override
  void dispose() {
    _dateController.dispose();
    _accountController.dispose();
    _categoryController.dispose();
    _ammountController.dispose();
    _fromController.dispose();
    _toController.dispose();
    myFocusNodeAccount.dispose();
    super.dispose();

  }


  functionCheckvalue() async {
    await getDataList();
    if(_dateController.text == ""){
      DateTime now = DateTime.now();
      var datavalue = now.toString().split(" ");
      _dateController.text = datavalue[0];
    }

    if(_accountController.text == ""){
      myFocusNodeAccount.requestFocus();
      if (_checkConfiguration()) {
        Future.delayed(Duration.zero,() {
          _showModalAccount(context, "Account");
        });
      }
    }
  }


  getDataList () async{
    var db = DBHelper();
    DataAccount = await db.getAccountList("accountlist");
    DataIncomingList = await db.getIncomingList("incominglist");;
    DataExpenseList = await db.getExpenseList("expenselist");
  }

  _handleTabSelection() {
    setState(() {
      _categoryController.text = "";
      if(_tabController.index == 0){
        Tittle = "Income";
      }else if(_tabController.index == 1){
        Tittle = "Expense";
      }else{
        Tittle = "Transfer";
      }
      print( _tabController.index);
    });
  }
  _showModalCalendar(context) {
    _onSelectionChanged(DateRangePickerSelectionChangedArgs args) {

      var value = args.value.toString();

      var datavalue = value.split(" ");
      _dateController.text =  datavalue[0];
      Navigator.pop(context);
    }
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Column(
            children: [
              Container(
                height: 50,
                color: backgroundColor,
                child:Padding(
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child:  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Date", style: TextStyle(color: Colors.white),),
                      Row(
                        children: [
                         GestureDetector(
                           child:  Text("Today", style: TextStyle(color: Colors.white),),
                           onTap: () {
                             DateTime now = DateTime.now();
                             var datavalue = now.toString().split(" ");
                             _dateController.text = datavalue[0];
                             Navigator.pop(context);
                           },
                         ),

                          IconButton(
                            icon: Icon(
                              Icons.close,
                              color: Colors.white,
                            ),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                          ),
                        ],
                      )

                    ],
                  ),
                ),
              ),
              SfDateRangePicker(
                onSelectionChanged: _onSelectionChanged,
                selectionMode: DateRangePickerSelectionMode.single,
                // initialSelectedRange: PickerDateRange(
                //     DateTime.now().subtract(const Duration(days: 4)),
                //     DateTime.now().add(const Duration(days: 3))),
              ),
            ],

          ) ;
        });
  }



  _showModalAccount(context, data) {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Container(
            child: Column(
              children: [
                Container(
                  height: 50,
                  color: backgroundColor,
                  child:Padding(
                    padding: EdgeInsets.only(left: 10, right: 10),
                    child:  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(data, style: TextStyle(color: Colors.white),),
                        Row(
                          children: [
                            IconButton(
                              icon: Icon(
                                Icons.edit,
                                color: Colors.white,
                              ),
                              onPressed: () async {
                                SharedPreferences prefs = await SharedPreferences.getInstance();
                                prefs.setString("Tittle", Tittle);
                                Navigator.of(context).pushNamed("edit_account_view");
                                // Navigator.pop(context);
                              },
                            ),
                            IconButton(
                              icon: Icon(
                                Icons.close,
                                color: Colors.white,
                              ),
                              onPressed: () {

                                Navigator.pop(context);
                              },
                            ),
                          ],
                        )


                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: GridView.builder(
                      gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 120,
                          childAspectRatio: 3 / 1,
                          // crossAxisSpacing: 20,
                          // mainAxisSpacing: 20
                      ),
                      itemCount: DataAccount.length,
                      itemBuilder: (BuildContext ctx, index) {
                        return Card(
                            color: secondaryColor,
                            elevation: 3,
                            child: InkWell(
                              onTap: () {
                                setState(() {
                                  if(data == "From"){
                                    _fromController.text = DataAccount[index].name;
                                    dataFrom = DataAccount[index].id.toString();
                                  }else if(data == "To"){
                                    _toController.text = DataAccount[index].name;
                                     dataTo = DataAccount[index].id.toString();
                                  }else{
                                    _accountController.text = DataAccount[index].name;
                                    dataAcount = DataAccount[index].id;
                                  }

                                });
                                Navigator.pop(context);
                              },
                              child: Container(
                                padding: EdgeInsets.all(4),
                                child: Center(
                                  child: Text(DataAccount[index].name, style: TextStyle(color: Colors.white),),
                                ),
                              ),
                            ));
                      }),
                    // child: GridView.count(
                    //   crossAxisCount: 3,
                    //   childAspectRatio: 2.2,
                    //   children: model.loadCategoriesAcount().map((e) => Card(
                    //       color: secondaryColor,
                    //       elevation: 2,
                    //       child: InkWell(
                    //         onTap: () {
                    //         setState(() {
                    //           _accountController.text = e.name;
                    //           dataAcount = e.index;
                    //         });
                    //           Navigator.pop(context);
                    //
                    //           // Navigator.of(context).pushNamed("inserttransaction",
                    //           //     arguments: [e, model.selectedCategory]);
                    //         },
                    //         child: Container(
                    //           padding: EdgeInsets.all(4),
                    //           child: Center(
                    //             child: Text(e.name),
                    //           ),
                    //         ),
                    //       )))
                    //       .toList(),
                    // )
                )
              ],
            ),);;
        });
  }

  _showModalCategory(context, NewTransactionModel model, type) {
    print(type);

    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Container(
            // color: backgroundColor,
            child: Column(
              children: [
                Container(
                  height: 50,
                  color: backgroundColor,
                  child:Padding(
                    padding: EdgeInsets.only(left: 10, right: 10),
                    child:  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Category", style: TextStyle(color: Colors.white),),

                        Row(
                          children: [
                            IconButton(
                              icon: Icon(
                                Icons.edit,
                                color: Colors.white,
                              ),
                              onPressed: () async {
                                SharedPreferences prefs = await SharedPreferences.getInstance();
                                prefs.setString("Tittle", Tittle);
                                Navigator.of(context).pushNamed("edit_category_view");
                                // Navigator.pop(context);
                              },
                            ),
                            IconButton(
                              icon: Icon(
                                Icons.close,
                                color: Colors.white,
                              ),
                              onPressed: () {

                                Navigator.pop(context);
                              },
                            ),
                          ],
                        )

                      ],
                    ),
                  ),
                ),
                _tabController.index == 0 ?
                Expanded(
                    child: GridView.builder(
                        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 120,
                          childAspectRatio: 3 / 1,
                          // crossAxisSpacing: 20,
                          // mainAxisSpacing: 20
                        ),
                        itemCount: DataIncomingList.length,
                        itemBuilder: (BuildContext ctx, index) {
                          return Card(
                              color: secondaryColor,
                              elevation: 3,
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    _categoryController.text = DataIncomingList[index].name;
                                    dataCategory =DataIncomingList[index].id;
                                  });
                                  Navigator.pop(context);
                                },
                                child: Container(
                                  padding: EdgeInsets.all(4),
                                  child: Center(
                                    child: Text(DataIncomingList[index].name, style: TextStyle(color: Colors.white),),
                                  ),
                                ),
                              ));
                        })

                ) :
                    Expanded(
                        child: GridView.builder(
                            gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 120,
                              childAspectRatio: 3 / 1,
                              // crossAxisSpacing: 20,
                              // mainAxisSpacing: 20
                            ),
                            itemCount: DataExpenseList.length,
                            itemBuilder: (BuildContext ctx, index) {
                              return Card(
                                  color: secondaryColor,
                                  elevation: 3,
                                  child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        _categoryController.text = DataExpenseList[index].name;
                                        dataCategory =DataExpenseList[index].id;
                                      });
                                      Navigator.pop(context);
                                    },
                                    child: Container(
                                      padding: EdgeInsets.all(4),
                                      child: Center(
                                        child: Text(DataExpenseList[index].name, style: TextStyle(color: Colors.white),),
                                      ),
                                    ),
                                  ));
                            })
                    ) ,

              ],
            ),);;
        });
  }

  _showModalAmount(context) {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Column(
            children: [
              Container(
                height: 50,
                color: backgroundColor,
                child:Padding(
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child:  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Amount", style: TextStyle(color: Colors.white),),
                      Row(
                        children: [
                          // Text("Today", style: TextStyle(color: Colors.white),),
                          IconButton(
                            icon: Icon(
                              Icons.close,
                              color: Colors.white,
                            ),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                          ),
                        ],
                      )

                    ],
                  ),
                ),
              ),
              Expanded(child:
              SimpleCalculator(
                // onTappedDisplay: (data, TapDownDetails){
                //   print(data);
                //   print(TapDownDetails);
                // },
                value: 0,
                hideExpression: true,
                onChanged: (key, value, expression) {
                  var realValue = value.round();
                  _ammountController.text = formatter.format(realValue);
                  if(key.toString() == "OK"){
                    Navigator.pop(context);
                  }

                },
                theme:  CalculatorThemeData(
                  displayColor: secondaryColor,
                  displayStyle: const TextStyle(fontSize: 80, color: Colors.yellow),
                ),
              ))
            ],

          ) ;
        });
  }

  _showCameraOption(context) {
    showModalBottomSheet(
      backgroundColor: Colors.transparent,
        context: context,
        builder: (context) {
          return Container(
            height: 200,
            child: Column(
            children: [
              SizedBox(
                height: 10,
              ),
              ButtonTheme(
                minWidth: 300,
                child: MaterialButton(
                  color: secondaryColor,
                  onPressed: () {
                    getImage("camera", context);
                  },
                  child: Text('Camera', style: TextStyle(color: Colors.white),),
                ),
              ),
              ButtonTheme(
                minWidth: 300,
                child: MaterialButton(
                  color: secondaryColor,
                  onPressed: () {
                    getImage("gallery", context);
                  },
                  child: Text('Gallery', style: TextStyle(color: Colors.white),),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              ButtonTheme(
                minWidth: 300,
                child: MaterialButton(
                  color: Colors.red,
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Cancel', style: TextStyle(color: Colors.white),),
                ),
              ),
            ],

          ),) ;
        });
  }




  File _image;
  final picker = ImagePicker();
  File newImageLocal;
  Future getImage(source, context) async {
    final prefs = await SharedPreferences.getInstance();
    var pickedFile;
    if(source == "gallery"){
      pickedFile = await picker.getImage(source: ImageSource.gallery);
    }else{
      pickedFile = await picker.getImage(source: ImageSource.camera, maxWidth: 480, maxHeight: 600);
    }

    Directory tempDir = await getTemporaryDirectory();
    String tempPath = tempDir.path;
    DateTime now = DateTime.now();
    String formattedDate = DateFormat('yyyy-MM-dd–kk:mm:ss').format(now);
    String fileName = formattedDate+".png";
    print(fileName);
    final newImagetemp = File(pickedFile.path);
    final File newImage = await newImagetemp.copy('$tempPath/$fileName');

    setState(()  {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
        imageLocalDir = '$tempPath/$fileName';
        newImageLocal = _image;
        imageLocalDir2 = pickedFile.path.toString();
      } else {
        print('No image selected.');
      }


    });
  }



  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return BaseView<NewTransactionModel>(
      builder: (context, model, child) =>
      Scaffold(
        appBar: AppBar(
          leadingWidth: 120,
          leading: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                ),
                onPressed: () {
                  Navigator.of(context).pushNamed("home");
                  // _showOverlay(context);
                  // do something
                },
              ),
             Align(
                 child:  Text("Transaction", textAlign: TextAlign.left, style: TextStyle(fontSize: 12, ),))
            ],
          ),
          centerTitle: true,
          title: Text(Tittle),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: DefaultTabController(
              length: 3,
              child: Builder(builder: (BuildContext context) {

                return Column(
                  children: <Widget>[
                    Container(
                      width: width,
                      color: backgroundColor,
                      child:  ButtonsTabBar(
                        radius: 50,
                        // buttonMargin : EdgeInsets.only(right: 5, left: 5),
                        contentPadding:  EdgeInsets.only(right: 30, left: 30),
                        // center: true,
                        // physics: BouncingScrollPhysics(),
                        controller : _tabController,
                        decoration: BoxDecoration(
                          color: Colors.white,
                        ),
                        unselectedBorderColor: Colors.grey,
                        // backgroundColor: secondaryColor,
                        unselectedBackgroundColor: backgroundColor,
                        unselectedLabelStyle: TextStyle(color: Colors.white),
                        labelStyle: TextStyle(color: backgroundColor, fontWeight: FontWeight.bold),
                        tabs: [


                          Tab(
                            text: "Income",
                          ),
                          Tab(
                            text:  "Expense",
                          ),
                          Tab(
                            text: "transfer",
                          ),
                        ],
                      ),
                    ),
                    Card(
                      child: Container(
                        child: new Column(
                          children: <Widget>[
                            new ListTile(
                              leading: Container(
                                child: Text("Date"),
                                width: width / 4.5,
                              ),
                              title: new TextField(
                                controller: _dateController,
                                readOnly: true,
                                decoration: InputDecoration(
                                  errorText: _validateDate ? 'Please input this field' : null,
                                ),
                                onTap: (){
                                  _showModalCalendar(context);
                                },
                              ),
                            ),
                            Tittle == "Transfer" ?
                                Column(
                                  children: [
                                    ListTile(
                                      leading: Container(
                                        child: Text("From")  ,
                                        width: width / 4.5,
                                      ),
                                      title: new TextField(
                                        onChanged: (text){
                                          print(text);
                                        },
                                        // focusNode: myFocusNodeAccount,
                                        controller: _fromController,
                                        decoration: InputDecoration(
                                          errorText: _validateFrom ? 'Please input this field' : null,
                                        ),
                                        onTap: (){
                                          _showModalAccount(context, "From");
                                        },
                                        readOnly: true,
                                      ),
                                    ),
                                    ListTile(
                                      leading: Container(
                                        child: Text("To")  ,
                                        width: width / 4.5,
                                      ),
                                      title: new TextField(
                                        onChanged: (text){
                                          print(text);
                                        },
                                        // focusNode: myFocusNodeAccount,
                                        controller: _toController,
                                        decoration: InputDecoration(
                                          errorText: _validateTo ? 'Please input this field' : null,
                                        ),
                                        onTap: (){
                                          _showModalAccount(context, "To");
                                        },
                                        readOnly: true,
                                      ),
                                    )
                                  ],
                                )
                            :  ListTile(
                              leading: Container(
                                child: Text("Account")  ,
                                width: width / 4.5,
                              ),
                              title: new TextField(
                                onChanged: (text){
                                  print(text);
                                },
                                focusNode: myFocusNodeAccount,
                                controller: _accountController,
                                decoration: InputDecoration(
                                  errorText: _validateAccount ? 'Please input this field' : null,
                                ),
                                onTap: (){
                                  _showModalAccount(context, "Account");
                                },
                                readOnly: true,
                              ),
                            ),
                            Tittle == "Transfer" ? Container() : ListTile(
                              leading: Container(
                                child: Text("Category"),
                                width: width / 4.5,
                              ),
                              title: new TextField(
                                controller: _categoryController,
                                decoration: InputDecoration(
                                  errorText: _validateCategory ? 'Please input this field' : null,
                                ),
                                onTap: (){
                                  final index = DefaultTabController.of(context).index;
                                  _showModalCategory(context, model, index);
                                },
                                readOnly: true,
                              ),
                            ),
                            new ListTile(
                              leading: Container(
                                child: Text("Amount"),
                                width: width / 4.5,
                              ),
                              title: new TextField(
                                decoration: InputDecoration(
                                  errorText: _validateAmmount ? 'Please input this field' : null,
                                ),
                                controller: _ammountController,
                                readOnly: true,
                                onTap: (){
                                  _showModalAmount(context);
                                },
                              ),
                            ),
                            new ListTile(
                              leading: Container(
                                child: Text("Note"),
                                width: width / 4.5,
                              ),
                              title: new TextField(
                                controller: _noteController,
                              ),
                            ),

                          ],
                        ),
                      ),),
                    SizedBox(
                      height: 20,
                    ),
                    Card(
                      child: Container(
                        child: new Column(
                          children: <Widget>[
                            new ListTile(
                              title: new TextField(
                                controller: _pictureDescController,
                                decoration: InputDecoration(
                                  // border: OutlineInputBorder(),
                                    hintText: 'Description'
                                ),
                                onTap: (){
                                  // _showModalCalendar(context);
                                },
                              ),
                              leading: IconButton(
                                icon: Icon(
                                  Icons.camera_alt,
                                  color: Colors.grey,
                                ),
                                onPressed: (){
                                  // getImage("gallery", context);
                                  _showCameraOption(context);
                                },
                              ),
                            ),

                            _image != null ?
                            GestureDetector(
                              onTap: () async {
                                await showDialog(
                                    context: context,
                                    builder: (_) => ImageDialog( _image.path)
                                );
                              },
                              child:  Stack(
                                  children: [
                                    Container(
                                      width: MediaQuery.of(context).size.width,
                                      height: 150,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: FileImage(newImageLocal),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                        top:0.0,
                                        right: 0.0,
                                        child: Container(
                                          color:  Colors.black.withOpacity(0.5),
                                          child:  Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: new IconButton(
                                                icon: Icon(Icons.delete,color: Colors.white,),
                                                onPressed: () {
                                                  setState(() {
                                                    _image = null;
                                                  });
                                                }),
                                          ),
                                        )
                                    ),
                                  ]
                              ),

                            )  : Container(),
                            SizedBox(height: 30,),


                          ],
                        ),
                      ),
                    ),

                    Tittle == "Transfer" ?  Align(
                        alignment: Alignment.center,
                        child: Container(

                          width: width / 1.2,
                          child: RaisedButton(
                            child: Text(
                              'ADD',
                              style: TextStyle(fontSize: 16),
                            ),
                            color: secondaryColor,
                            textColor: Colors.white,
                            onPressed: () async {
                              setState(() {
                                _dateController.text.isEmpty ? _validateDate = true : _validateDate = false;
                                _accountController.text.isEmpty ? _validateAccount = true : _validateAccount = false;
                                _fromController.text.isEmpty ? _validateFrom = true : _validateFrom = false;
                                _toController.text.isEmpty ? _validateTo= true : _validateTo = false;
                                _ammountController.text.isEmpty ? _validateAmmount = true : _validateAmmount = false;
                              });
                              final index = DefaultTabController.of(context).index;
                              String type = "";
                              if(_tabController.index  == 0){
                                type = "income";
                              }else if(_tabController.index  == 1){
                                type = "expense";
                              }else{
                                type = "transfer";
                              }
                              if(_validateDate == false &&  _validateFrom == false && _validateTo == false &&_validateAmmount == false ){
                                print( _categoryController.text);
                                await model.addTransaction(context, type, _dateController.text, _noteController.text, imageLocalDir, imageLocalDir2, _pictureDescController.text, _ammountController.text, dataCategory, dataAcount, dataFrom ,dataTo );
                              }

                              //
                            },
                          ),
                        )
                    ):
                    Align(
                        alignment: Alignment.center,
                        child: Container(

                          width: width / 1.2,
                          child: RaisedButton(
                            child: Text(
                              'ADD',
                              style: TextStyle(fontSize: 16),
                            ),
                            color: secondaryColor,
                            textColor: Colors.white,
                            onPressed: () async {
                              setState(() {
                                _dateController.text.isEmpty ? _validateDate = true : _validateDate = false;
                                _accountController.text.isEmpty ? _validateAccount = true : _validateAccount = false;
                                _categoryController.text.isEmpty ? _validateCategory= true : _validateCategory = false;
                                _ammountController.text.isEmpty ? _validateAmmount = true : _validateAmmount = false;
                              });
                              final index = DefaultTabController.of(context).index;
                              String type = "";
                              if(_tabController.index  == 0){
                                type = "income";
                              }else if(_tabController.index  == 1){
                                type = "expense";
                              }else{
                                type = "transfer";
                              }
                              // print(_validateAccount.toString());
                              if(_validateDate == false && _validateAccount == false &&_validateCategory == false &&_validateAmmount == false ){
                                print(dataCategory);
                                await model.addTransaction(context, type, _dateController.text, _noteController.text, imageLocalDir, imageLocalDir2, _pictureDescController.text, _ammountController.text, dataCategory, dataAcount, dataFrom ,dataTo );
                              }

                              //
                            },
                          ),
                        )
                    )
                  ],
                );
              }),

            ),
          ),
        ),
      ),
    );
  }
}


class ImageDialog extends StatelessWidget {
  final path;
  ImageDialog( this.path);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Navigator.pop(context);
      },
      child:  Dialog(
        child: Container(
          // width: 200,
          // height: 500,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image:  FileImage(File(path)),
                  fit: BoxFit.cover
              )
          ),
        ),
      ),
    );
  }
}