import 'package:date_util/date_util.dart';
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:intl/intl.dart' show DateFormat, NumberFormat;
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/ui/views/base_view.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/transactions_listview_widget.dart';

import 'app_fab.dart';
import 'empty_transaction_widget.dart';

class CalendarPopup extends ModalRoute<void> {
  final String date;
  HomeModel model;
  CalendarPopup(this.date, this.model);
  // const CalendarPopup({Key key, this.model, this.title}) : super(key: key);


  // var newDate = new DateTime(int.parse(model.transactions[i].year), int.parse(model.transactions[i].month), int.parse(model.transactions[i].day) );
  @override
  Duration get transitionDuration => Duration(milliseconds: 500);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => Colors.black.withOpacity(0.5);

  @override
  String get barrierLabel => null;

  @override
  bool get maintainState => true;
  CarouselController buttonCarouselController = CarouselController();
  List months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei','Jun','Jul','Agt','Sep','Okt','nov','Des'];
  final formatCurrency = new NumberFormat.simpleCurrency(locale: 'id_ID');

  buildList(List<Transaction> transactions, HomeModel model) {

    return transactions.length == 0
        ? EmptyTransactionsDayWidget()
        : TransactionsListViewDay(transactions, model);
  }

  @override
  Widget buildPage(
      BuildContext context,
      Animation<double> animation,
      Animation<double> secondaryAnimation,
      ) {
    // This makes sure that text and other content follows the material style
    return Material(
        type: MaterialType.transparency,
        // make sure that the overlay content is not cut off
        child: _buildOverlayContent(context, model)
    );
  }

  int daysInMonth(DateTime date) {
    var firstDayThisMonth = new DateTime(date.year, date.month, date.day);
    var firstDayNextMonth = new DateTime(firstDayThisMonth.year, firstDayThisMonth.month + 1, firstDayThisMonth.day);
    return firstDayNextMonth.difference(firstDayThisMonth).inDays;

  }

  callbackFunction(dataHari,  model) async{
    var string = date;
    var dataDate = string.split(" ");
    var string1 = dataDate[0].toString();
    var dataDate1 = string1.split("-");

    var dateDay = DateTime(int.parse(dataDate1[0] ), int.parse(dataDate1[1], ), dataHari+1);
    print(dateDay.toString());
    await model.getPerDay(dateDay.toString());
    // print(date);
    // print(dateDay);


  }

  Widget _buildOverlayContent(BuildContext context, model) {

    var string = date;
    var dataDate = string.split(" ");
    var string1 = dataDate[0].toString();
    var dataDate1 = string1.split("-");
    var dataDayName = ( DateFormat('EEEE').format(DateTime(int.parse(dataDate1[0] ), int.parse(dataDate1[1], ), int.parse(dataDate1[2], ))));

    var dataDayNameReal = dataDayName; // 'artlang'


    var now = DateTime(int.parse(dataDate1[0]), int.parse(dataDate1[1]));
    var totalDays = daysInMonth(now);

    // Stroing all the dates till the last date
    // since we have found the last date using generate
    var listOfDates = new List<int>.generate(totalDays, (i) => i + 1);

    return Center(
      child: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          Padding(
            padding: EdgeInsets.only(bottom: 10),
            child: Center(
              child:  InkWell(
                child: Icon(Icons.close, color: Colors.white, size: 30, ),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ),

          Row(
            children: [
              // Padding(
              //   padding: EdgeInsets.only(left: 7),
              //   child:  InkWell(
              //     child: Icon(Icons.arrow_back_ios, color: Colors.white, size: 25, ),
              //     onTap: () {
              //       buttonCarouselController.previousPage( curve: Curves.linear);
              //     },
              //   ),
              // ),
              Expanded(child: Center(
                child: CarouselSlider(
                  carouselController: buttonCarouselController,
                  options: CarouselOptions(
                    height: 300,
                    aspectRatio: 16/9,
                    viewportFraction:1,
                    initialPage: int.parse(dataDate1[2]),
                    enableInfiniteScroll: true,
                    reverse: false,
                    autoPlay: false,
                    autoPlayInterval: Duration(seconds: 3),
                    autoPlayAnimationDuration: Duration(milliseconds: 800),
                    autoPlayCurve: Curves.fastOutSlowIn,
                    enlargeCenterPage: true,
                    onPageChanged: (value, carousel){
                      print(carousel.index);
                      print(value);
                      // callbackFunction(value, model);
                    },
                    scrollDirection: Axis.horizontal,
                  ),
                  items: listOfDates.map((i) {
                    return Builder(
                      builder: (BuildContext context) {
                        return Container(
                            width: MediaQuery.of(context).size.width,
                            margin: EdgeInsets.symmetric(horizontal: 5.0),
                            decoration: BoxDecoration(
                                color: Colors.white
                            ),
                            child:  Column(
                              children: [
                                Container(
                                  color: Colors.grey,
                                  child:  Padding(
                                    padding: EdgeInsets.only(left: 10,top: 10),
                                    child: Row(
                                      children: [
                                        Container(
                                          child: Row(
                                            children: [
                                              Text(dataDate1[2].toString(),style:
                                              TextStyle(
                                                  fontWeight: FontWeight.bold, color: Colors.white,
                                                  fontSize: 30 ),
                                              )
                                            ],
                                          ),
                                        ),
                                        SizedBox(width: 5,),
                                        Column(
                                          children: [
                                            Text(dataDate1[1]+"/"+dataDate1[0], style: TextStyle(color: Colors.white, fontSize: 9),),
                                            Container(
                                              color: Colors.grey,
                                              child:  Padding(
                                                padding: EdgeInsets.all(2),
                                                child:  Text( dataDayNameReal.substring(0, 3), style: TextStyle(color: Colors.white),),
                                              ),
                                            )
                                          ],
                                        ),
                                        SizedBox(width: 10,),
                                        Text(formatCurrency.format(model.incomeSumPerDay).toString(),
                                            style: TextStyle(fontSize: 9, color: backgroundColor)),
                                        SizedBox(width: 10,),
                                        Text(formatCurrency.format(model.expenseSumPerDay).toString(),
                                            style: TextStyle(fontSize: 9, color: Colors.red)),
                                        SizedBox(width: 10,),
                                        Text(formatCurrency.format(model.expenseSumPerDay).toString(),
                                            style: TextStyle(fontSize: 9, color: Colors.white))
                                      ],
                                    ),
                                  ),),
                                Expanded(
                                    child:   buildList(model.transactions, model)),
                                Align(
                                  alignment: AlignmentDirectional.bottomEnd,
                                  child:  AppFAB2(model.closeMonthPicker),

                                )
                              ],
                            )
                          // Text('text $i', style: TextStyle(fontSize: 16.0),)
                        );
                      },
                    );
                  }).toList(),
                ),
              )),
              // Padding(
              //   padding: EdgeInsets.only(right: 10),
              //   child:  InkWell(
              //     child: Icon(Icons.arrow_forward_ios, color: Colors.white, size: 25, ),
              //     onTap: () {
              //       buttonCarouselController.nextPage( curve: Curves.linear);
              //     },
              //   ),
              // ),
            ],
          )
        ],
      ),);
  }

  @override
  Widget buildTransitions(
      BuildContext context, Animation<double> animation, Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}