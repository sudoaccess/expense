import 'package:flutter/material.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/ui/shared/text_styles.dart';
import 'package:moneymanager/ui/shared/ui_helpers.dart';

class SummaryWidget extends StatelessWidget {
  final String income;
  final String expense;
  final String total;

  const SummaryWidget({this.income, this.expense, this.total});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: secondaryColor,
          border: Border.all(color: Colors.black.withOpacity(0.2))
      ),
      // color: secondaryColor,
      child: Padding(
        padding: EdgeInsets.only(top: 10, bottom: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Column(
              children: <Widget>[
                Text('Income', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white)),
                UIHelper.verticalSpaceSmall(),
                Text(income.toString(), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.blue))
              ],
            ),
            Column(
              children: <Widget>[
                Text(
                  'Expense',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white),
                ),
                UIHelper.verticalSpaceSmall(),
                Text(expense.toString(), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.red))
              ],
            ),
            Column(
              children: <Widget>[
                Text(
                  'Total',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,  color: Colors.white),
                ),
                UIHelper.verticalSpaceSmall(),
                Text(total, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white))
                // Text((income - expense).toString(),
                //     style: summaryNumberTextStyle)
              ],
            ),
          ],
        ),
      ),
    );
  }
}
