import 'package:flutter/material.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/table_calendar.dart';
import 'package:overlay_container/overlay_container.dart';
import '../../../../globals.dart' as globals;
import '../indonesia_format.dart';
import 'home.dart';

class PickMonthOverlay extends StatefulWidget {
  final HomeModel model;
  final BuildContext context;
  final bool showOrHide;
  final String newTitle;
  final Widget dataaBodyCalendar;

  const PickMonthOverlay({Key key, this.model, this.context, this.showOrHide, this.newTitle, this.dataaBodyCalendar})
      : super(key: key);

  @override
  State<PickMonthOverlay> createState() => _PickMonthOverlayState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _PickMonthOverlayState extends State<PickMonthOverlay>  with TickerProviderStateMixin {

  String newTitle = "";
  bool canSee = true;

  @override
  void initState() {
    var datatemp = widget.model.currentTimeModel.toString().split(" ");
    var datatemp2 = datatemp[0].split("-");

    newTitle = datatemp2[0].toString();
    // TODO: implement initState
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return OverlayContainer(
        show: globals.isShowing,
        // Let's position this overlay to the right of the button.
        position: OverlayContainerPosition(
          // Left position.
          0,
          // Bottom position.
          0,
        ),
        // The content inside the overlay.
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(8),
              width: MediaQuery.of(context).size.width,
              margin: const EdgeInsets.only(top: 5),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: Colors.grey[300],
                    blurRadius: 3,
                    spreadRadius: 10,
                  )
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    color: Colors.black,
                    iconSize: 40,
                    icon: const Icon(Icons.chevron_left),
                    onPressed: () async {
                      await widget.model.prevYear();
                      setState(() {
                        var datatemp = widget.model.currentTimeModel.toString().split(" ");
                        var datatemp2 = datatemp[0].split("-");

                        newTitle = datatemp2[0].toString();
                      });
                    },
                  ),
                  Container(
                      child: Center(
                        child: Text(newTitle, style: TextStyle(color: Colors.black)),
                      )
                  ),
                  IconButton(
                    color: Colors.black,
                    iconSize: 40,
                    icon: const Icon(Icons.chevron_right),
                    onPressed: () async {
                      await widget.model.nextYear();
                      setState(() {
                        var datatemp = widget.model.currentTimeModel.toString().split(" ");
                        var datatemp2 = datatemp[0].split("-");
                        newTitle = datatemp2[0].toString();
                      });
                      // setState(() {
                      //
                      // });
                    },
                  ),
                ],
              ),
            ),
            Container(
              height: 200,
              padding: EdgeInsets.all(8),
              width: MediaQuery.of(context).size.width,
              margin: const EdgeInsets.only(top: 5),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: Colors.grey[300],
                    blurRadius: 3,
                    spreadRadius: 10,
                  )
                ],
              ),
              child: buildGridView(widget.model),
            )
          ],
        )
    );
  }

  Widget buildGridView(HomeModel model) {
    return GridView.count(
      crossAxisCount: 6,
      children: model.months.map((month) {
        var index = model.months.indexOf(month);
        int dataSelected = model.months.indexOf(month);
        return InkWell(
          onTap: () async {

            String bulanReal = "";

            for (var i = 0; i < model.months.length; i++) {
              String bulan = "";
              if((i+1) < 10){
                bulan = "0"+(i+1).toString();
              }else{
                bulan = (i+1).toString();
              }
              if(bulanReal == ""){
                if (i == dataSelected){
                  bulanReal = bulan;
                }
              }
            }

            // print(bulanReal.toString());
            model.monthClicked(bulanReal.toString(), newTitle);
            setState(() {
              globals.isShowing = false;
              globals.dataBody = HomeBar(model.currentTimeModel, model, widget.dataaBodyCalendar);
              globals.initialSelectedDay = model.currentTimeModel;
              globals.Tittle = Waktu(widget.model.currentTimeModel).LLL() + " " +widget.model.currentTimeModel.year.toString();
              globals.dataBodyCalendar = TableCalendarWidgetView(model: widget.model,  currentTimeModel: widget.model.currentTimeModel);
              globals.calendarControllerNew.selectedDate = widget.model.currentTimeModel;
              // print("asdada");
            });


            // Navigator.pop(context);
          },
          child: Center(
            child: Text(
              month,
              style: TextStyle(
                color: model.getColor(index),
              ),
            ),
          ),
        );

      }).toList(),
    );
  }
}
