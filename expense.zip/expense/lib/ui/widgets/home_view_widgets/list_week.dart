

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:moneymanager/core/services/moordatabase_service.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/ui/shared/text_styles.dart';
import 'package:moneymanager/ui/shared/ui_helpers.dart';
import 'package:date_util/date_util.dart';
import 'package:moneymanager/ui/views/base_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';  //for date format
import '../../../locator.dart';

class Listweek extends StatelessWidget {
  final HomeModel model;
  final List listData;

  Listweek({Key key, this.model, this.listData}) : super(key: key);


  final MoorDatabaseService _moorDatabaseService =locator<MoorDatabaseService>();
  final formatter = new NumberFormat("#,###");

  int expenseSumPerWeek = 0;
  int incomeSumPerWeek = 0;
  int transferSumPerWeek = 0;

  List ListdataWeek = [];

 Future <List<int>> getdataPerweek(week, year) async {
     int incomeSumPerWeek2  = await _moorDatabaseService.getIncomeSumPerWeek(week.toString(), year.toString());
     int expenseSumPerWeek2  = await _moorDatabaseService.getExpenseSumPerWeek(week.toString(), year.toString());
     int transferSumPerWeek2  = await _moorDatabaseService.getTransferSumPerWeek(week.toString(), year.toString());
    // print(incomeSumPerWeek);
     return [incomeSumPerWeek2, expenseSumPerWeek2, transferSumPerWeek2];

  }
  @override
  Widget build(BuildContext context) {

    return  BaseView<HomeModel>(
      onModelReady: (model) async {
      await model.getdataPerweek(listData);

    },
    builder: (context, model, child) => Container(
      color: thirdColor,
      child: Padding(
        padding: EdgeInsets.only(top: 10, bottom: 10),
        child: ListView.separated(
          padding: const EdgeInsets.all(8),
          itemCount: listData.length,
          itemBuilder: (BuildContext context, int index) {
            return FutureBuilder(
                future: getdataPerweek(listData[index]["week"].toString(), listData[index]["year"].toString()),
                builder:(context, AsyncSnapshot snapshot) {

                  if (!snapshot.hasData) {
                    return Center(child: SpinKitWave(color: backgroundColor, type: SpinKitWaveType.center));
                  } else {
                    return  Container(
                      height: 50,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(' ${listData[index]["desc"]}'),
                          Padding(padding: EdgeInsets.only(right: 0),
                            child:  Text(formatter.format(snapshot.data[0]), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.blue)),
                          ),
                          Padding(padding: EdgeInsets.only(right: 30),
                            child:  Text(formatter.format(snapshot.data[1]), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.red)),
                          ),
                        ],
                      ),
                    );
                  }
                }
            );
            //
            // incomeSumPerWeek  = _moorDatabaseService.getIncomeSumPerWeek(listData[index]["week"].toString(), listData[index]["year"].toString());
            // print(incomeSumPerWeek);
           // var data =  ;
           // print(getdataPerweek(listData[index]["week"], ));

            //   for (var i = 0; i < model.ListdataWeek.length; i++) {
            //     print(model.ListdataWeek[i]);
            //   }
            //
            // print("length.ListdataWeek "+model.ListdataWeek.length.toString());
            // if(model.ListdataWeek.length != 0){
            //
            // }

            // print("length.listData "+listData.length.toString());
            // print("model.ListdataWeek "+model.ListdataWeek[index]["incomeSumPerWeek"].toString());
            // print(ListdataWeek[index]);
            // return Container(
            //   height: 50,
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //     children: [
            //       Text(' ${listData[index]["desc"]}'),
            //       Padding(padding: EdgeInsets.only(right: 0),
            //         child:  Text("Rp 0", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.blue)),
            //       ),
            //       Padding(padding: EdgeInsets.only(right: 30),
            //         child:  Text("Rp 0", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.red)),
            //       ),
            //     ],
            //   ),
            // );
          },
          separatorBuilder: (BuildContext context, int index) => const Divider(),
        ),
      ),
      )
    );
  }
}
