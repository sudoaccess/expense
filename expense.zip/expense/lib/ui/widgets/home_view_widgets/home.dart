import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/enums/viewstate.dart';
import 'package:moneymanager/core/models/category.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/core/services/sharedprefs_service.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/ui/views/search_view.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/pop_up.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/summary_widget.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/table_calendar.dart';
// import 'package:moneymanager/ui/widgets/home_view_widgets/table_calendar.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/transactions_listview_widget.dart';
import 'package:path_provider/path_provider.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import 'package:moneymanager/ui/widgets/indonesia_format.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../locator.dart';
import '../indonesia_format.dart';
import 'calendar_popup.dart';
import 'empty_transaction_widget.dart';
import 'list_month.dart';
import 'list_week.dart';
import 'month_year_picker_widget.dart';
import '../../../globals.dart' as globals;
import 'dart:io';
import 'package:path/path.dart';
import 'package:excel/excel.dart';

class HomeBar extends StatefulWidget {
  DateTime datetimenew;
  HomeModel model;
  Widget dataaBodyCalendar;

  HomeBar(
    this.datetimenew,
    this.model,
    this.dataaBodyCalendar
  );

  @override
  State<HomeBar> createState() => _HomeBarState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _HomeBarState extends State<HomeBar> with TickerProviderStateMixin {
  TabController _tabController, _tabControllerMenu;
  final SharedPrefrencesService _sharedPrefrencesService = locator<SharedPrefrencesService>();
  // TabController ;

  var waktu = Waktu();
  DateTime datetime = DateTime.now();

  final formatCurrency = new NumberFormat.simpleCurrency(locale: 'id_ID');
  int _moneyCounter;

  PageController _pageController;
  CalendarController _controller;
  Map<DateTime, List<dynamic>> _events;
  DateTime _rangeStart;
  DateTime _rangeEnd;
  int _tabControllerMenuIndex = 0;
  List listData = [];

  List listDataWeekday = [];

  String monthlyText, lastMonthText, annualytext, lastYearText;

  List months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'Mei',
    'Jun',
    'Jul',
    'Agt',
    'Sep',
    'Okt',
    'nov',
    'Des'
  ];
  List monthsAngka = [
    '01',
    '02',
    '03',
    '04',
    '05',
    '06',
    '07',
    '08',
    '09',
    '10',
    '11',
    '12'
  ];
  List monthsList = [];
  List<dynamic> _selectedEvents;
  int _selectedIndex = 0;

  final CategoryIconService _categoryIconService =
      locator<CategoryIconService>();
  var Listweek2;

  // var formatNumber = NumberFormat("#,###.00", "en_US");
  final formatter = new NumberFormat("#,###");

  @override
  void initState() {
    super.initState();
    _controller = CalendarController();
    _tabController = TabController(length: 3, vsync: this);
    globals.menu5Contrroler = TabController(length: 5, vsync: this);

    // print(widget.model.transactions.toString());
    // setState(() {
      // globals.dataBodyCalendar = TableCalendarWidget(model: widget.model,  currentTimeModel: widget.model.currentTimeModel);
      globals.Tittle = Waktu(widget.model.currentTimeModel).LLL() + " " + widget.model.currentTimeModel.year.toString();
      _events = {};
      _selectedEvents = [];
    // });
    inssertIncomingList();
    getdata(widget.datetimenew);
    getMothList();
    requestPermission();

  }








  int daysInMonth(DateTime date) {
    var firstDayThisMonth = new DateTime(date.year, date.month, date.day);
    var firstDayNextMonth = new DateTime(firstDayThisMonth.year, firstDayThisMonth.month + 1, firstDayThisMonth.day);
    return firstDayNextMonth.difference(firstDayThisMonth).inDays;

  }

  void getMothList() async {

    var now = new DateTime.now();
    var lastMonth = DateTime(now.year, now.month -1, now.day);
    var lastYear = DateTime(now.year -1 , 12, now.day);
    var current_mon = now.month;
    var totalmonthlyText = daysInMonth(now);
    var totalLastmonthText = daysInMonth(lastMonth);
    var totalAnnualyText = daysInMonth(DateTime(now.year, 12, now.day));
    var totalLastAnnualyText = daysInMonth(lastYear);

    print(lastMonth.toString());
    setState(() {
      var bulan = "";
      var bulanLast = "";

      if(now.month.toString().length == 1){
        bulan = "0"+now.month.toString();
      }

      if(lastMonth.month.toString().length == 1){
        bulanLast = "0"+lastMonth.month.toString();
      }
      monthlyText = "Monthly ("+now.year.toString()+"."+bulan+".01 ~ "+bulan+"."+totalmonthlyText.toString()+")";
      lastMonthText = "Last M ("+lastMonth.year.toString()+"."+bulanLast+".01 ~ "+bulanLast+"."+totalLastmonthText.toString()+")";
      annualytext = "Annualy ("+lastMonth.year.toString()+".01.01 ~ 12."+totalAnnualyText.toString()+")";
      lastYearText = "Last Y ("+lastYear.year.toString()+".01.01 ~ 12."+totalLastAnnualyText.toString()+")";
    });
    for (var i = 0; i < months.length; i++) {
      if (i < current_mon) {
        monthsList.add({"bulanVar": months[i], "bulanAngka": monthsAngka[i]});
      }
    }

    return;
  }

  Future<void> requestPermission() async {
    var status = await Permission.storage.request();
    await Permission.photos.request();
    await Permission.camera.request();
    if (status.toString() == "PermissionStatus.granted") {
      inssertIncomingList();
    }
    //

  }

  List<List<DateTime>> getWeeksForRange(DateTime start, DateTime end) {
    listData = [];
    var result = List<List<DateTime>>();

    var date = start;
    var week = List<DateTime>();
    while (date.difference(end).inDays <= 0) {
      if (date.weekday == 7 && week.length > 0) {
        var string =
            getDate(date.subtract(Duration(days: date.weekday))).toString();

        var datatemp = string.split(" ");
        var string2 = getDate(date
                .add(Duration(days: (DateTime.daysPerWeek - 1) - date.weekday)))
            .toString();
        var datatemp2 = string2.split(" ");
        var firstWeek = datatemp[0].toString().split("-");
        var LastWeek = datatemp2[0].toString().split("-");

        DateTime now2 =
            DateTime.parse(datatemp[0].toString()); //DateTime.now();
        final date2 = now2;
        final startOfYear = new DateTime(date2.year, 1, 1, 0, 0);
        final firstMonday = startOfYear.weekday;
        final daysInFirstWeek = 8 - firstMonday;
        final diff = date2.difference(startOfYear);
        var weeks = ((diff.inDays - daysInFirstWeek) / 7).ceil();
        if (daysInFirstWeek > 3) {
          weeks += 1;
        }
        listData.add({
          "desc": firstWeek[2].toString() +
              "/" +
              firstWeek[1].toString() +
              " ~ " +
              LastWeek[2].toString() +
              "/" +
              LastWeek[1].toString(),
          "week": weeks,
          "year": firstWeek[0].toString()
        });
        result.add(week);
        week = List<DateTime>();
      }
      week.add(date);
      date = date.add(const Duration(days: 1));
    }
    result.add(week);
    return result;
  }

  DateTime getDate(DateTime d) => DateTime(d.year, d.month, d.day);

  getdata(DateTime now) {
    int lastday = DateTime(now.year, now.month + 1, 0).day;
    String firsttday = (DateTime(now.year, now.month + 1, 1).day).toString();

    if (firsttday.length == 1) {
      firsttday = "0" + firsttday;
    }
    getWeeksForRange(DateTime.utc(now.year, now.month, int.parse(firsttday)),
        DateTime.utc(now.year, now.month, lastday));
  }

  inssertIncomingList() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var db = DBHelper();
    if (prefs.getString("insertIncoming") == null) {
      List<Category> s = _categoryIconService.incomeList.toList();
      for (var i = 0; i < s.length; i++) {
        var suggestion = IncomingList(s[i].name, s[i].icon, "0");
        await db.saveIncomingList("incominglist", suggestion);
      }

      List<Category> s2 = _categoryIconService.expenseList.toList();
      for (var i = 0; i < s2.length; i++) {
        var suggestion = ExpenseList(s2[i].name, s2[i].icon, "0");
        await db.saveExpenseList("expenselist", suggestion);
      }

      List<Category> s3 = _categoryIconService.accountlist.toList();
      for (var i = 0; i < s3.length; i++) {
        var suggestion =
            AccountList(s3[i].name, s3[i].icon, s3[i].name, "", "", "0");
        await db.saveAccountList("accountlist", suggestion);
      }

      print("inserted");
      prefs.setString("insertIncoming", "YES");
      return s;
    }
  }

  buildList(List<Transaction> transactions, HomeModel model) {
    log(jsonEncode(transactions.toString()));
    return transactions.length == 0
        ? EmptyTransactionsWidget()
        : TransactionsListView(transactions, model);
  }

  void _showOverlay(BuildContext context) {
    Navigator.of(context).push(TutorialOverlay());
  }

  void _showSearchView(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return SearchView();
        },
      ),
    );
  }

  void _showPopup(BuildContext context, date, model) {
    Navigator.of(context).push(CalendarPopup(date.toString(), model));
  }

  Color getColor(Set<MaterialState> states) {
    const Set<MaterialState> interactiveStates = <MaterialState>{
      MaterialState.pressed,
      MaterialState.hovered,
      MaterialState.focused,
    };
    if (states.any(interactiveStates.contains)) {
      return Colors.blue;
    }
    return Colors.white70;
  }
  Color getColorRed(Set<MaterialState> states) {
    const Set<MaterialState> interactiveStates = <MaterialState>{
      MaterialState.pressed,
      MaterialState.hovered,
      MaterialState.focused,
    };
    if (states.any(interactiveStates.contains)) {
      return Colors.blue;
    }
    return Colors.red;
  }

  _openList(context) {
    showModalBottomSheet(
        backgroundColor: Colors.transparent,
        context: context,
        builder: (context) {
          return Column(
            children: [
              Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(20))
                  ),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 300,
                  child: Column(
                    children: [
                      SizedBox(height: 10,),
                      Center(
                        child: Text("Export data to excel", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),),
                      ),
                      Expanded(child:
                      ListView(
                        children: ListTile.divideTiles( //          <-- ListTile.divideTiles
                            context: context,
                            tiles: [
                              ListTile(
                                onTap:() async {
                                  final prefs = await SharedPreferences.getInstance();
                                  prefs.setString("dataToExcel", "monthlyText");
                                  Navigator.of(context).pushNamed("export_excel");
                                  //
                                },
                                title: Text(monthlyText),
                              ),
                              ListTile(
                                onTap:() async {
                                  final prefs = await SharedPreferences.getInstance();
                                  prefs.setString("dataToExcel", "lastMonthText");
                                  Navigator.of(context).pushNamed("export_excel");
                                  //
                                },
                                title: Text(lastMonthText),
                              ),
                              ListTile(
                                onTap:() async {
                                  final prefs = await SharedPreferences.getInstance();
                                  prefs.setString("dataToExcel", "annualytext");
                                  Navigator.of(context).pushNamed("export_excel");
                                  //
                                },
                                title: Text(annualytext),
                              ),
                              ListTile(
                                onTap:() async {
                                  final prefs = await SharedPreferences.getInstance();
                                  prefs.setString("dataToExcel", "lastYearText");
                                  Navigator.of(context).pushNamed("export_excel");
                                  //
                                },
                                title: Text(lastYearText),
                              ),
                              ListTile(
                                onTap:() async {
                                  final prefs = await SharedPreferences.getInstance();
                                  prefs.setString("dataToExcel", "All");
                                  Navigator.of(context).pushNamed("export_excel");
                                  //
                                },
                                title: Text('All'),
                              ),
                            ]
                        ).toList(),
                      )
                      )
                    ],
                  )
              ),
              Container(
                  width: MediaQuery.of(context).size.width / 1.1,
                  child: OutlinedButton(
                      onPressed : (){
                        Navigator.of(context).pop();
                        },
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.resolveWith(getColorRed) ,
                        shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(30.0))),
                      ),
                      // minWidth: 300,
                      child: Text("Cancel", style: TextStyle(color: Colors.black),)
                  )

              ),

            ],
          );
        });
  }
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.search,
            color: Colors.white,
          ),
          onPressed: () {
            // _showOverlay(context);
            // do something
            _showSearchView(context);
          },
        ),
        centerTitle: true,
        title: Text('Transaction'),
        bottom: TabBar(
          onTap: (index) async {
            if (index == 0) {
              if (globals.isShowing) {
                setState(() {
                  globals.isShowing = false;
                });
              }
              await widget.model.prevMonth();
              setState(() {
                globals.Tittle  = Waktu(widget.model.currentTimeModel).LLL() + " " + widget.model.currentTimeModel.year.toString();
              });
              // prevMonth(model.currentTimeModel, context, model);

              await widget.model.update(widget.model.currentTimeModel.toString());
              globals.dataBody = HomeBar(widget.model.currentTimeModel, widget.model, widget.dataaBodyCalendar);
              if(globals.menu5Contrroler.index == 1){
                globals.calendarControllerNew.backward();
              }

            } else if (index == 1) {

              setState(() {
                if (globals.isShowing) {
                  globals.isShowing = false;
                } else {
                  globals.isShowing = true;
                }
                globals.dataBody = HomeBar(widget.model.currentTimeModel, widget.model, widget.dataaBodyCalendar);
              });

            } else {

              await widget.model.nextMonth();
              setState(() {
                globals.isShowing = false;
                globals.Tittle  = Waktu(widget.model.currentTimeModel).LLL() + " " +widget.model.currentTimeModel.year.toString();
              });

              // nextMonth(model.currentTimeModel, context, model);
              await widget.model.update(widget.model.currentTimeModel.toString());
              globals.dataBody = HomeBar(widget.model.currentTimeModel, widget.model, widget.dataaBodyCalendar);
              if(globals.menu5Contrroler.index == 1){
                globals.calendarControllerNew.forward();
              }

            }
          },
          indicatorColor: Colors.transparent,
          controller: _tabController,
          tabs: <Widget>[
            Tab(
              icon: Icon(Icons.chevron_left),
            ),
            Tab(
                child: Center(
                  child: Text(globals.Tittle),
                )),
            Tab(
              icon: Icon(Icons.chevron_right),
            )
          ],
        ),
      ),
      body: Column(
        children: <Widget>[
          Container(
            color: secondaryColor,
            child: TabBar(
              onTap: (index) async {
                // print(index);
                setState(() {
                  _tabControllerMenuIndex = index;
                });
              },
              controller: globals.menu5Contrroler,
              tabs: <Widget>[
                Tab(
                  icon: Text(
                    "Daily",
                    style: TextStyle(fontSize: 9),
                  ),
                ),
                Tab(
                  icon: Text(
                    "Calendar",
                    style: TextStyle(fontSize: 9),
                  ),
                ),
                Tab(
                  icon: Text(
                    "Weekly",
                    style: TextStyle(fontSize: 9),
                  ),
                ),
                Tab(
                  icon: Text(
                    "Monthly",
                    style: TextStyle(fontSize: 9),
                  ),
                ),
                Tab(
                  icon: Text(
                    "Summary",
                    style: TextStyle(fontSize: 9),
                  ),
                )
              ],
            ),
          ),
          // AppCalendar(),
          Expanded(
            child: TabBarView(
              controller: globals.menu5Contrroler,
              children: <Widget>[
                Center(
                  child: widget.model.state == ViewState.Busy
                      ? Center(child: CircularProgressIndicator())
                      : Stack(
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          SummaryWidget(
                            income: formatCurrency
                                .format(widget.model.incomeSum),
                            expense: formatCurrency
                                .format(widget.model.expenseSum),
                            total: formatCurrency.format(
                                widget.model.incomeSum -
                                    widget.model.expenseSum),
                          ),
                          buildList(
                              widget.model.transactions, widget.model),
                        ],
                      ),
                      globals.isShowing
                          ? PickMonthOverlay(
                          model: widget.model,
                          showOrHide: widget.model.isCollabsed,
                          dataaBodyCalendar: widget.dataaBodyCalendar,
                          context: context)
                          : Container(),
                    ],
                  ),
                ),
                Center(
                  child: Column(
                    children: [
                      // globals.isShowing
                      //     ? PickMonthOverlay(
                      //     model: widget.model,
                      //     showOrHide: widget.model.isCollabsed,
                      //     context: context)
                      //     : Container(),

                      SummaryWidget(
                        income: formatCurrency.format(widget.model.incomeSum),
                        expense: formatCurrency.format(widget.model.expenseSum),
                        total: formatCurrency.format(
                            widget.model.incomeSum - widget.model.expenseSum),
                      ),


                      Expanded(
                          child: globals.dataBodyCalendar
                      ),
                      // ValueListenableBuilder<DateTime>(
                      //   valueListenable: _focusedDay,
                      //   builder: (context, value, _) {
                      //     return Container();
                      //   },
                      // ),
                      // ,
                      const SizedBox(height: 8.0),
                    ],
                  ),
                ),
                Center(
                  child: Column(
                    children: [
                      SummaryWidget(
                        income: formatCurrency.format(widget.model.incomeSum),
                        expense: formatCurrency.format(widget.model.expenseSum),
                        total: formatCurrency.format(
                            widget.model.incomeSum - widget.model.expenseSum),
                      ),
                      Expanded(
                          child:
                          Listweek(listData: listData, model: widget.model)),
                    ],
                  ),
                ),
                //
                Center(
                  child: Column(
                    children: [
                      SummaryWidget(
                        income: formatCurrency.format(widget.model.incomeSum),
                        expense: formatCurrency.format(widget.model.expenseSum),
                        total: formatCurrency.format(widget.model.incomeSum - widget.model.expenseSum),
                      ),
                      Expanded(
                          child: ListMonth(
                              monthsList: monthsList,
                              currentTimeModel: widget.model.currentTimeModel,
                              model: widget.model,
                              dataaBodyCalendar: widget.dataaBodyCalendar,)),
                    ],
                  ),
                ),
                Center(
                  child:Center(
                    child: Column(
                      children: [
                        SummaryWidget(
                          income: formatCurrency.format(widget.model.incomeSum),
                          expense: formatCurrency.format(widget.model.expenseSum),
                          total: formatCurrency.format(
                              widget.model.incomeSum - widget.model.expenseSum),
                        ),
                        Container(
                          height: 100,
                          decoration: BoxDecoration(
                              color: backgroundColor,
                              border: Border.all(color: Colors.blueAccent)
                          ),
                          child: Column(
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                  padding: EdgeInsets.only(left:5, top:5),
                                  child: Row(
                                    children: [
                                      Icon(Icons.account_balance_wallet, color: Colors.white,),
                                      SizedBox(width: 10,),
                                      Text("Accounts", style: TextStyle(color: Colors.white),)
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 7.0, left: 20,right: 20),
                                child: Container(
                                  height: 50,
                                  decoration: BoxDecoration(
                                      color: backgroundColor,
                                      border: Border.all(color: Colors.white),
                                        borderRadius: BorderRadius.only(
                                        topRight: Radius.circular(10.0),
                                        bottomRight: Radius.circular(10.0),
                                        topLeft: Radius.circular(10.0),
                                        bottomLeft: Radius.circular(10.0)),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                     Padding(padding: EdgeInsets.only(left: 5),
                                     child:  Text("Expenses (Cash, accounts)", style: TextStyle(color: Colors.white),),),
                                      Padding(padding: EdgeInsets.only(right: 5),
                                        child:  Text("30.000", style: TextStyle(color: Colors.white)),)
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),

                        Padding(
                          padding: const EdgeInsets.only(top: 15.0, left: 10,right: 10),
                          child: SizedBox(
                              width: double.infinity,
                              child: RaisedButton.icon(
                                icon:  Image.asset(
                                  'assets/icons/excel.png',
                                  width: 20,
                                  height: 20,
                                ),
                                textColor: Colors.white,
                                color: Colors.orange,
                                label: const Text('Export data to Excel'),
                                onPressed: () {
                                  _openList(context);
                                },
                              )),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
    // );
  }
}
