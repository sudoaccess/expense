import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/enums/viewstate.dart';
import 'package:moneymanager/core/models/category.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/ui/views/base_view.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/pop_up.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/summary_widget.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/transactions_listview_widget.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';  //for date format
import 'package:moneymanager/ui/widgets/indonesia_format.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../../locator.dart';
import '../indonesia_format.dart';
import 'calendar_popup.dart';
import 'empty_transaction_widget.dart';
import 'list_month.dart';
import 'list_week.dart';
import 'month_year_picker_widget.dart';


class SettingBar extends StatefulWidget {
  const SettingBar({Key key}) : super(key: key);

  @override
  State<SettingBar> createState() => _SettingBarState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _SettingBarState extends State<SettingBar>  with TickerProviderStateMixin {



  @override
  void initState() {
    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    return  BaseView<HomeModel>(
        onModelReady: (model) async {
      await model.init();

    },
    builder: (context, model, child) =>
        Center(
          child: Text("SETTING BAR"),
        )
    );

  }
}
