

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/core/services/moordatabase_service.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';  //for date format
import 'package:moneymanager/ui/widgets/home_view_widgets/table_calendar.dart';
import '../../../locator.dart';
import '../../../globals.dart' as globals;
import '../indonesia_format.dart';
import 'home.dart';

class ListMonth extends StatelessWidget {

  final List monthsList;
  final DateTime currentTimeModel;
  final HomeModel model;
  Widget dataaBodyCalendar;

  ListMonth({this.monthsList, this.currentTimeModel, this.model, this.dataaBodyCalendar});

  final MoorDatabaseService _moorDatabaseService =locator<MoorDatabaseService>();
  final formatter = new NumberFormat("#,###");

  int expenseSumPerWeek = 0;
  int incomeSumPerWeek = 0;
  int transferSumPerWeek = 0;
  List ListdataWeek = [];
  Future <List<int>> getdataPerMonth(bulan) async {


    int incomeSum  = await  _moorDatabaseService.getIncomeSum(bulan, currentTimeModel.year.toString());
    int expenseSum  =  await _moorDatabaseService.getExpenseSum(bulan, currentTimeModel.year.toString());
    int transferSum  = await _moorDatabaseService.getTransferSum(bulan, currentTimeModel.year.toString());
    // print(incomeSumPerWeek);
    return [incomeSum, expenseSum, transferSum];

  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: thirdColor,
      child: Padding(
        padding: EdgeInsets.only(top: 10, bottom: 10),
        child: ListView.separated(
          padding: const EdgeInsets.all(8),
          itemCount: monthsList.length,
          itemBuilder: (BuildContext context, int index) {
            return FutureBuilder(
                future: getdataPerMonth(monthsList[index]["bulanAngka"]),
                builder:(context, AsyncSnapshot snapshot) {

                  if (!snapshot.hasData) {
                    return Center(child: SpinKitWave(color: backgroundColor, type: SpinKitWaveType.center));
                  } else {
                    return
                      InkWell(
                        onTap: () async {

                          DateTime now = DateTime(currentTimeModel.year, int.parse(monthsList[index]["bulanAngka"]), currentTimeModel.day);
                          print(now);
                          await model.update(now.toString());
                            globals.dataBody = HomeBar(model.currentTimeModel, model, dataaBodyCalendar);
                            globals.initialSelectedDay = model.currentTimeModel;
                            globals.Tittle = Waktu(model.currentTimeModel).LLL() + " " +model.currentTimeModel.year.toString();
                            globals.dataBodyCalendar = TableCalendarWidgetView(model: model,  currentTimeModel: model.currentTimeModel);
                            globals.calendarControllerNew.selectedDate = model.currentTimeModel;
                            globals.menu5Contrroler.animateTo(0);
                          // Navigator.of(context).pushNamed("home");
                        },
                        child:  Container(
                          height: 25,
                          child: GestureDetector(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(' ${monthsList[index]["bulanVar"]}'),
                                Padding(padding: EdgeInsets.only(right: 0),
                                  child:  Text(formatter.format(snapshot.data[0]), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.blue)),
                                ),
                                Padding(padding: EdgeInsets.only(right: 30),
                                  child:  Text(formatter.format(snapshot.data[1]), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.red)),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                  }
                }
            );


          },
          separatorBuilder: (BuildContext context, int index) => const Divider(),
        ),
      ),
    );
  }
}

//
//
// class Listweek extends StatefulWidget {
//
//    final DateTime datetime;
//
//     Listweek(this.datetime);
//
//    @override
//    State<Listweek> createState() => _ListweekState();
// }
//
// class _ListweekState extends State<Listweek> {
//
//
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//
//
//
//   }
//
//

//
//   @override
//   Widget build(BuildContext context) {
//     //test
//     return Container(
//       color: thirdColor,
//       child: Padding(
//         padding: EdgeInsets.only(top: 10, bottom: 10),
//         child: ListView.separated(
//           padding: const EdgeInsets.all(8),
//           itemCount: listData.length,
//           itemBuilder: (BuildContext context, int index) {
//             return Container(
//               height: 50,
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Text(' ${listData[index]}'),
//                   Padding(padding: EdgeInsets.only(right: 0),
//                     child:  Text("Rp 0", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.blue)),
//                   ),
//                  Padding(padding: EdgeInsets.only(right: 30),
//                  child:  Text("Rp 0", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.red)),
//                  ),
//                 ],
//               ),
//             );
//           },
//           separatorBuilder: (BuildContext context, int index) => const Divider(),
//         ),
//       ),
//     );
//   }
// }
