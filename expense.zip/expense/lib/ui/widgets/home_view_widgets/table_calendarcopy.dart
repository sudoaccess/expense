// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:moneymanager/core/viewmodels/home_model.dart';
// // import 'package:table_calendar/table_calendar.dart';
// import 'package:flutter/material.dart';
// import 'package:moneymanager/core/database/DBHelper.dart';
// import 'package:moneymanager/core/database/moor_database.dart';
// import 'package:moneymanager/core/enums/viewstate.dart';
// import 'package:moneymanager/core/models/category.dart';
// import 'package:moneymanager/core/models/category_list_model.dart';
// import 'package:moneymanager/core/services/category_icon_service.dart';
// import 'package:moneymanager/core/viewmodels/home_model.dart';
// import 'package:moneymanager/ui/shared/app_colors.dart';
// import 'package:moneymanager/ui/views/base_view.dart';
// import 'package:moneymanager/ui/widgets/home_view_widgets/pop_up.dart';
// import 'package:moneymanager/ui/widgets/home_view_widgets/summary_widget.dart';
// import 'package:moneymanager/ui/widgets/home_view_widgets/transactions_listview_widget.dart';
// import 'package:table_calendar/table_calendar.dart';
// import 'package:intl/intl.dart'; //for date format
// import 'package:moneymanager/ui/widgets/indonesia_format.dart';
// import 'package:table_calendar/table_calendar.dart';
// import 'package:permission_handler/permission_handler.dart';
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:table_calendar/table_calendar.dart';
// import '../../../locator.dart';
// import '../indonesia_format.dart';
// import 'calendar_popup.dart';
// import 'empty_transaction_widget.dart';
// import 'list_month.dart';
// import 'list_week.dart';
// import 'month_year_picker_widget.dart';
// import '../../../globals.dart' as globals;
//
// class TableCalendar extends StatelessWidget {
//   final HomeModel model;
//   final String title;
//   const TableCalendar({Key key, this.model, this.title}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return TableCalendar(
//       initialSelectedDay: widget.model.currentTimeModel,
//       availableGestures: AvailableGestures.none,
//       headerVisible: false,
//       // events: _events,
//       initialCalendarFormat: CalendarFormat.month,
//       startingDayOfWeek: StartingDayOfWeek.monday,
//       onDaySelected: (date, events, holidays) {
//         _showPopup(context, date, widget.model);
//         setState(() {
//           _selectedEvents = events;
//         });
//       },
//       builders: CalendarBuilders(dayBuilder: (context, date, events) {
//         var dayPrint = Container(
//           child: Column(
//             children: [
//               Align(
//                 alignment: Alignment.topRight,
//                 child: Padding(
//                   padding: EdgeInsets.only(right: 5, top: 5),
//                   child: Text(
//                     date.day.toString(),
//                     style: TextStyle(
//                         color: Colors.black, fontSize: 11),
//                   ),
//                 ),
//               )
//             ],
//           ),
//         );
//         for (var i = 0;i < widget.model.transactions.length; i++) {
//           String DayNow = date.day.toString();
//           if (date.day.toString().length == 1) {
//             DayNow = "0" + date.day.toString();
//           }
//           if (widget.model.transactions[i].day == DayNow) {
//             dayPrint = Container(
//               child: new Column(
//                 mainAxisAlignment:
//                 MainAxisAlignment.spaceBetween,
//                 children: [
//                   Align(
//                     alignment: Alignment.topRight,
//                     child: Padding(
//                       padding:
//                       EdgeInsets.only(right: 5, top: 5),
//                       child: Text(
//                         date.day.toString(),
//                         style: TextStyle(
//                             color: Colors.black, fontSize: 11),
//                       ),
//                     ),
//                   ),
//                   widget.model.transactions[i]
//                       .incomeSumPerDay !=
//                       0
//                       ? Align(
//                     alignment: Alignment.bottomCenter,
//                     child: Text(
//                       formatter
//                           .format(widget
//                           .model
//                           .transactions[i]
//                           .incomeSumPerDay)
//                           .toString(),
//                       style: TextStyle(
//                         color: Colors.blue,
//                         fontSize: 10,
//                       ),
//                     ),
//                   )
//                       : Container(),
//                   widget.model.transactions[i]
//                       .expenseSumPerDay !=
//                       0
//                       ? Align(
//                     alignment: Alignment.bottomCenter,
//                     child: Text(
//                       formatter
//                           .format(widget
//                           .model
//                           .transactions[i]
//                           .expenseSumPerDay)
//                           .toString(),
//                       style: TextStyle(
//                         color: Colors.red,
//                         fontSize: 10,
//                       ),
//                     ),
//                   )
//                       : Container(),
//                   widget.model.transactions[i]
//                       .transferSumPerDay !=
//                       0
//                       ? Align(
//                     alignment: Alignment.bottomCenter,
//                     child: Text(
//                       formatter
//                           .format(widget
//                           .model
//                           .transactions[i]
//                           .transferSumPerDay)
//                           .toString(),
//                       style: TextStyle(
//                         color: Colors.grey,
//                         fontSize: 10,
//                       ),
//                     ),
//                   )
//                       : Container()
//                 ],
//               ),
//             );
//           }
//         }
//
//         return new Container(
//             width: 64.0,
//             height: 64.0,
//             margin: const EdgeInsets.all(4.0),
//             alignment: Alignment.topRight,
//             decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.circular(10.0)),
//             child: dayPrint);
//       }, todayDayBuilder: (context, date, events) {
//         var dayPrint = Column(
//           children: [
//             Align(
//               alignment: Alignment.topRight,
//               child: Padding(
//                 padding: EdgeInsets.only(right: 5, top: 5),
//                 child: Text(
//                   date.day.toString(),
//                   style: TextStyle(
//                       color: Colors.white, fontSize: 11),
//                 ),
//               ),
//             )
//           ],
//         );
//         for (var i = 0;i < widget.model.transactions.length; i++) {
//           var newDate = new DateTime(
//               int.parse(widget.model.transactions[i].year),
//               int.parse(widget.model.transactions[i].month),
//               int.parse(widget.model.transactions[i].day));
//           String DayNow = date.day.toString();
//           if (date.day.toString().length == 1) {
//             DayNow = "0" + date.day.toString();
//           }
//           if (widget.model.transactions[i].day == DayNow) {
//             dayPrint = new Column(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Align(
//                   alignment: Alignment.topRight,
//                   child: Padding(
//                     padding: EdgeInsets.only(right: 5, top: 5),
//                     child: Text(
//                       date.day.toString(),
//                       style: TextStyle(
//                           color: Colors.white, fontSize: 11),
//                     ),
//                   ),
//                 ),
//                 widget.model.transactions[i].incomeSumPerDay != 0
//                     ? Align(
//                   alignment: Alignment.bottomCenter,
//                   child: Text(
//                     formatter
//                         .format(widget
//                         .model
//                         .transactions[i]
//                         .incomeSumPerDay)
//                         .toString(),
//                     style: TextStyle(
//                       color: Colors.blue,
//                       fontSize: 10,
//                     ),
//                   ),
//                 )
//                     : Container(),
//                 widget.model.transactions[i].expenseSumPerDay != 0
//                     ? Align(
//                   alignment: Alignment.bottomCenter,
//                   child: Text(
//                     formatter
//                         .format(widget
//                         .model
//                         .transactions[i]
//                         .expenseSumPerDay)
//                         .toString(),
//                     style: TextStyle(
//                       color: Colors.red,
//                       fontSize: 10,
//                     ),
//                   ),
//                 )
//                     : Container(),
//                 widget.model.transactions[i].transferSumPerDay != 0
//                     ? Align(
//                   alignment: Alignment.bottomCenter,
//                   child: Text(
//                     formatter
//                         .format(widget
//                         .model
//                         .transactions[i]
//                         .transferSumPerDay)
//                         .toString(),
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 10,
//                     ),
//                   ),
//                 )
//                     : Container()
//               ],
//             );
//           }
//           // children.add(new ListTile());
//         }
//         return Container(
//           margin: const EdgeInsets.all(4.0),
//           alignment: Alignment.center,
//           decoration: BoxDecoration(
//               color: backgroundColor,
//               borderRadius: BorderRadius.circular(10.0)),
//           child: dayPrint,
//         );
//       }),
//       calendarController: _controller,
//     );
//   }
// }
