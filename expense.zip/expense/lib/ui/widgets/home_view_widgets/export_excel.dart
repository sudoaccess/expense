import 'package:csv/csv.dart';
import 'package:ext_storage/ext_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/models/calendar_model.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'dart:io';

import 'package:moneymanager/core/services/moordatabase_service.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';  //for date format
import '../../../locator.dart';
import 'package:open_file/open_file.dart';

class ExportExcel extends StatefulWidget {
  final HomeModel model;
  final DateTime currentTimeModel;
  const ExportExcel({Key key, this.model, this.currentTimeModel}) : super(key: key);

  @override
  State<ExportExcel> createState() => _ExportExcelState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _ExportExcelState extends State<ExportExcel>  with TickerProviderStateMixin {
  final formatCurrency = new NumberFormat.simpleCurrency(locale: 'id_ID');
  final formatter = new NumberFormat("#,###");

  // CalendarController _calendarController = CalendarController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _generateCsvFile();
  }
  var db = DBHelper();
  final MoorDatabaseService _moorDatabaseService =locator<MoorDatabaseService>();
  List<Transaction> transactions = List<Transaction>();
  List<AccountList> accountgrouplist = [];
  bool buttonVew = false;
  String pathView = "";
  bool isEmpty = false;

  void _generateCsvFile() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.storage,
    ].request();

    final prefs = await SharedPreferences.getInstance();
     var dataSort  = prefs.getString("dataToExcel");

    var now = DateTime.now();
    var lastMonth = DateTime(now.year, now.month -1, now.day);
    var bulan = "";
    var bulanLast = "";

    if (now.month.toString().length == 1) {
      bulan = "0" + now.month.toString();
    }

    if (lastMonth.month.toString().length == 1) {
      bulanLast = "0" + lastMonth.month.toString();
    }

    if(dataSort == "monthlyText"){
       transactions = await _moorDatabaseService.getAllTransactions(bulan, now.year.toString());
     }else if(dataSort == "lastMonthText"){
      transactions = await _moorDatabaseService.getAllTransactions(bulanLast, now.year.toString());
    }else if(dataSort == "annualytext"){
      transactions = await _moorDatabaseService.getAllTransactionsForYear(now.year.toString());
    }else if(dataSort == "lastYearText"){
      transactions = await _moorDatabaseService.getAllTransactionsForYear((now.year-1).toString());
    }else{
      transactions = await _moorDatabaseService.getAllTransactionsForTime();
    }

   if(transactions.isNotEmpty){
    setState(() {
      isEmpty = true;
    });
     List<List<dynamic>> rows = [];

     List<dynamic> row = [];
     row.add("Period");
     row.add("Accounts");
     row.add("Category");
     row.add("Subcategory");
     row.add("Note");
     row.add("IDR");
     row.add("Income/Expense");
     row.add("Detail");
     row.add("Amount");
     row.add("Currency");
     row.add("Account");
     rows.add(row);
     for (int i = 0; i < transactions.length; i++) {

       var category = "";
       var Account = "";
       var accountgrouplist = await db.getAccountListByID("accountlist", transactions[i].accountindex);
       Account = accountgrouplist[0].name;

       if(transactions[0].type == "income"){
         var incominglist = await db.getIncomingListByID("incominglist", transactions[i].accountindex);
         category =  incominglist[0].name;
       }else if(transactions[0].type == "expense"){
         var expenselist = await db.getExpenseListByID("expenselist", transactions[i].accountindex);
         category =  expenselist[0].name;
       }




       List<dynamic> row = [];
       row.add(transactions[i].year+"-"+transactions[i].month+"-"+transactions[i].day);
       row.add(Account != "" ?  Account : "");
       row.add(category);
       row.add("sub category");
       row.add(transactions[i].memo);
       row.add(transactions[i].amount);
       row.add(transactions[i].type);
       row.add("");
       row.add(transactions[i].amount);
       row.add("IDR");
       row.add(transactions[i].amount);
       rows.add(row);
     }

     String csv = const ListToCsvConverter().convert(rows);

     String dir = await ExtStorage.getExternalStoragePublicDirectory(ExtStorage.DIRECTORY_DOWNLOADS);
     print("dir $dir");
     String file = "$dir";

     var nameFile = DateTime.now();
     final path = Directory(file + "/revenue_and_payment/"+nameFile.year.toString()+"_"+nameFile.month.toString()+"_"+nameFile.day.toString()+"/");
     await path.create(recursive: true);
     if ((await path.exists())){
       // TODO:
       File f = File(file + "/revenue_and_payment/"+nameFile.year.toString()+"_"+nameFile.month.toString()+"_"+nameFile.day.toString()+"/"+nameFile.year.toString()+"_"+nameFile.month.toString()+"_"+nameFile.day.toString()+".csv");

       f.writeAsString(csv);

       setState(() {

         pathView = file + "/revenue_and_payment/"+nameFile.year.toString()+"_"+nameFile.month.toString()+"_"+nameFile.day.toString() +"/"+nameFile.year.toString()+"_"+nameFile.month.toString()+"_"+nameFile.day.toString()+".csv";
         buttonVew = true;
       });
       //
       // print(message.toString());
     }else{
       // TODO:
       print("not exist");

     }
   }else{

   }

  }

  openFileData() async{
    final message = await OpenFile.open(pathView);
  }
  Color getColorRed(Set<MaterialState> states) {
    const Set<MaterialState> interactiveStates = <MaterialState>{
      MaterialState.pressed,
      MaterialState.hovered,
      MaterialState.focused,
    };
    if (states.any(interactiveStates.contains)) {
      return Colors.blue;
    }
    return Colors.green;
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // leadingWidth: 120,
        leading: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              icon: Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              ),
              onPressed: () {

                Navigator.of(context).pushNamed("home");
                // _showOverlay(context);
                // do something
              },
            ),
          ],
        ),
        centerTitle: true,
        title: Text("Export Data to Excel"),
      ),
      body: SafeArea(
        child: isEmpty ?

        buttonVew ? Column(
          children: [
            Container(
              padding: EdgeInsets.only(top: 30),
              child: Image.asset(
              'assets/icons/excel.png',
              width: 50,
              height: 50,
            ),),
           Padding(
               padding: EdgeInsets.only(top:20),
               child:  Center(
                 child: Text("Your file has been downloaded"),
               ),
           ),

            Padding(
              padding: EdgeInsets.only(top:20),
              child:  Container(
                width: 300,
                child: OutlinedButton(
                    onPressed : (){
                      openFileData();
                    },
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.resolveWith(getColorRed) ,
                      shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(30.0))),
                    ),
                    // minWidth: 300,
                    child: Text("View", style: TextStyle(color: Colors.black),)
                ),
              ),
            ),
          ],
        ) :
        Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top:20),
              child:  Center(
                child: Text("failed to generate data, please try again"),
              ),
            ),

            Padding(
              padding: EdgeInsets.only(top:20),
              child:  Center(
                child: OutlinedButton(
                    onPressed : (){
                      _generateCsvFile();
                    },
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.resolveWith(getColorRed) ,
                      shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(30.0))),
                    ),
                    // minWidth: 300,
                    child: Text("Try Again", style: TextStyle(color: Colors.black),)
                ),
              ),
            ),
          ],
          ) : Padding(
                padding: EdgeInsets.only(top: 20),
                child: Center(
                  child: Text("No Data found"),
                ),
              ),
      ),
    );
  }
}
