import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:moneymanager/core/models/calendar_model.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
// import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import '../indonesia_format.dart';
import 'calendar_popup.dart'; //for date format
import '../../../globals.dart' as globals;
import 'home.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/core/services/moordatabase_service.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';  //for date format
import '../../../locator.dart';


class TableCalendarWidgetView extends StatefulWidget {
  final HomeModel model;
  final DateTime currentTimeModel;
  const TableCalendarWidgetView({Key key, this.model, this.currentTimeModel}) : super(key: key);

  @override
  State<TableCalendarWidgetView> createState() => _TableCalendarWidgetState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _TableCalendarWidgetState extends State<TableCalendarWidgetView>  with TickerProviderStateMixin {
  


  final formatCurrency = new NumberFormat.simpleCurrency(locale: 'id_ID');
  final formatter = new NumberFormat("#,###");

  // CalendarController _calendarController = CalendarController();

  @override
  void initState() {
    // TODO: implement initState
    // globals.calendarControllerNew.selectedDate = DateTime(2020, 04, 10);
    globals.calendarControllerNew.displayDate = widget.currentTimeModel;
    // globals.controller = CalendarController();
    // setState(() {
    //   globals.initialSelectedDay = DateTime.now();
    //   globals.calendarControllerNew.selectedDate = DateTime(2020, 04, 10);
    // });

    super.initState();
  }
  final MoorDatabaseService _moorDatabaseService =locator<MoorDatabaseService>();


  HomeModel model2;
  // List<Meeting> _getDataSource() {
  //   final List<Meeting> meetings = <Meeting>[];
  //   final DateTime today = DateTime.now();
  //   final DateTime startTime = DateTime(today.year, today.month, today.day, 9, 0, 0);
  //   final DateTime endTime = startTime.add(const Duration(hours: 2));
  //   meetings.add(Meeting(
  //       'Conference', startTime, endTime, const Color(0xFF0F8644), false));
  //   return meetings;
  // }



  Future <List<String>> getdataPerDay(date) async {
    int expenseSumPerDay = 0;
    int incomeSumPerDay  = 0;
    int transferSumPerDay  = 0;
    bool dataSet = false;
    for (var i = 0;i < widget.model.transactions.length; i++) {
      String DayNow = date.day.toString();
      String DayNowMonth = date.day.toString();
      if (date.day.toString().length == 1) {
        DayNow = "0" + date.day.toString();
      }
      if (date.month.toString().length == 1) {
        DayNowMonth = "0" + date.month.toString();
      }

      if (widget.model.transactions[i].day == DayNow && widget.model.transactions[i].month == DayNowMonth && widget.model.transactions[i].year == date.year.toString()) {
         var newDate = date.month ;

        String bulan = "";
        if(newDate < 10){
          bulan = "0"+newDate.toString();
        }else{
          bulan = newDate.toString();
        }

        var newDate2 = date.day ;
        String dayString = "";
        if(newDate2 < 10){
          dayString = "0"+newDate2.toString();
        }else{
          dayString = newDate2.toString();
        }
        // setState(() async {
        int expenseSumPerDay = await _moorDatabaseService.getExpenseSumPerDay(bulan.toString(), date.year.toString(), dayString.toString());
        int incomeSumPerDay  = await _moorDatabaseService.getIncomeSumPerDay(bulan.toString(), date.year.toString(), dayString.toString());
        int  transferSumPerDay  = await _moorDatabaseService.getTransferSumPerDay(bulan.toString(), date.year.toString(), dayString.toString());
        dataSet = true;

        return [expenseSumPerDay.toString(), incomeSumPerDay.toString(), transferSumPerDay.toString(), dataSet.toString()];
      }else{
        dataSet = false;
        return [expenseSumPerDay.toString(), incomeSumPerDay.toString(), transferSumPerDay.toString(), dataSet.toString()];
      }
    }
    return [expenseSumPerDay.toString(), incomeSumPerDay.toString(), transferSumPerDay.toString(), dataSet.toString()];

  }

  void refreshData(dates, dataSelected) async{
    if(dataSelected == 10){
      globals.calendarControllerNew.displayDate = dates;
      var datatemp = dates.toString().split(" ");
      var datatemp2 = datatemp[0].toString().split("-");

      await widget.model.monthClicked(datatemp2[1].toString(), datatemp2[0].toString());

      // setState(() {
      //   globals.Tittle = Waktu(widget.model.currentTimeModel).LLL() + " " + widget.model.currentTimeModel.year.toString();
      // });

      setState(() {
        globals.isShowing = false;
        globals.dataBody = HomeBar(widget.model.currentTimeModel, widget.model, globals.dataBodyCalendar);
        globals.initialSelectedDay = widget.model.currentTimeModel;
        globals.Tittle = Waktu(widget.model.currentTimeModel).LLL() + " " +widget.model.currentTimeModel.year.toString();
        globals.dataBodyCalendar = TableCalendarWidgetView(model: widget.model,  currentTimeModel: widget.model.currentTimeModel);
        globals.calendarControllerNew.selectedDate = widget.model.currentTimeModel;

      });

    }

    // setState(() {
    //   //
    // });
  }
  void _showPopup(BuildContext context, date, model) async {
  await model.getPerDay(date.toString());
  await model.setCurrentdate(date);

    Navigator.of(context).push(CalendarPopup(date.toString(), model));
  }
  bool canSee = false;

  @override
  Widget build(BuildContext context) {

    return SfCalendar(
      onSelectionChanged: (CalendarSelectionDetails details){
        DateTime date = details.date;

        DateTime dateNow = DateTime.now();
        print((date.year.toString() +"!="+ dateNow.year.toString()  +"&&"+ date.month.toString()  +"!="+ dateNow.month.toString()  +"&&"+ date.day.toString()  +"!="+ dateNow.day.toString()).toString());
        if(date.day != dateNow.day ){
          setState(() {

          });
          _showPopup(context, date, widget.model);
        }

      },
      // onTap: (CalendarTapDetails details){
      //   DateTime date = details.date;
      //   // print(date);
      //   _showPopup(context, date, widget.model);
      // },
      selectionDecoration: BoxDecoration(
        color: Colors.transparent,
        border:
        Border.all(color: const Color.fromARGB(255, 68, 140, 255),
            width: 2),
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        shape: BoxShape.rectangle,
      ),
      showDatePickerButton: true,
      initialDisplayDate: widget.currentTimeModel ,
      view: CalendarView.month,
      cellBorderColor: Colors.red,
      controller: globals.calendarControllerNew,
      onViewChanged: (ViewChangedDetails details) async {
        List  dates = details.visibleDates;
        int dataSelected = dates.indexOf(dates[10]);
        refreshData(dates[10], dataSelected);
      },
        // appointmentBuilder : ,
      monthCellBuilder: (BuildContext buildContext, MonthCellDetails details) {
          // print(details.date);
          // print(DateTime.now());
        return  FutureBuilder(
        future: getdataPerDay(details.date),
        builder:(context, AsyncSnapshot snapshot) {
              if (!snapshot.hasData) {
              return Center(child: Container());
              } else {
                return snapshot.data[3].toString() == "true" ?
                Container(
                  decoration:  BoxDecoration(
                    color: Colors.transparent,
                    border:
                    Border.all(color:  Colors.grey, width: 0.5),
                    // borderRadius: const BorderRadius.all(Radius.circular(4)),
                    shape: BoxShape.rectangle,
                  ),
                  padding: EdgeInsets.only(top: 4,right: 4,left: 4),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                            details.date.day.toString(),  style: TextStyle(fontSize: 10, color: Colors.black)
                        ),
                      ),

                      SizedBox(height: 3,),
                      snapshot.data[1].toString() != "0"?
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Text(
                          formatter.format(int.parse(snapshot.data[1])).toString(), style: TextStyle(fontSize: 8, color: Colors.blue),
                        ),
                      ) : Container(),


                      snapshot.data[0].toString() != "0"?
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Text(
                          formatter.format(int.parse(snapshot.data[0])).toString(), style: TextStyle(fontSize: 8, color: Colors.red),
                        ),
                      )  : Container(),

                      snapshot.data[2].toString() != "0"?
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Text(
                          formatter.format(int.parse(snapshot.data[2])).toString(), style: TextStyle(fontSize: 8, color: Colors.grey),
                        ),
                      )  : Container(),


                    ],
                  ),
                ) :
                Container(
                        decoration: BoxDecoration(
                          color: Colors.transparent,
                          border: Border.all(color: Colors.grey, width: 0.5),
                          // borderRadius:const BorderRadius.all(Radius.circular(4)),
                          shape: BoxShape.rectangle,
                        ),
                        padding: EdgeInsets.only(top: 4, right: 4, left: 4),
                        child: Column(
                          children: [
                            details.date.day == DateTime.now().day &&
                                    details.date.month ==
                                        DateTime.now().month &&
                                    details.date.year == DateTime.now().year
                                ? Container(
                                    height: 15,
                                    decoration: BoxDecoration(
                                      color: Colors.orange,
                                      border: Border.all(
                                          color: Colors.grey, width: 0.5),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(4)),
                                      shape: BoxShape.rectangle,
                                    ),
                                    child: Align(
                                      // alignment: Alignment.topLeft,
                                      child: Text(details.date.day.toString(),
                                          style: TextStyle(
                                              fontSize: 10,
                                              color: Colors.white)),
                                    ),
                                  )
                                : Align(
                                    alignment: Alignment.topLeft,
                                    child: Text(details.date.day.toString(),
                                        style: TextStyle(
                                            fontSize: 10, color: Colors.black)),
                                  ),
                          ],
                        ));
              }
            });

      },
      monthViewSettings: const MonthViewSettings(
          appointmentDisplayMode: MonthAppointmentDisplayMode.appointment),
    );

  }
}
