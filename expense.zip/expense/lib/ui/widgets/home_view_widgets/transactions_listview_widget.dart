import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:intl/intl.dart';  //for date format
class TransactionsListView extends StatefulWidget {
  final List<Transaction> transactions;
  final HomeModel model;

  const TransactionsListView(
    this.transactions,
    this.model,
  );

  @override
  _TransactionsListViewState createState() => _TransactionsListViewState();
}

class _TransactionsListViewState extends State<TransactionsListView> {
  final formatCurrency = new NumberFormat.simpleCurrency(locale: 'id_ID');

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: ListView(
        controller: widget.model.scrollController,
        // padding: EdgeInsets.all(8),
        children: widget.transactions.map((transaction) {
          // print(transaction);
          return Card(
            child: InkWell(
              onTap: () {
                Navigator.pushNamed(context, "details", arguments: transaction)
                    .then((value) => {
                          if (value != null)
                            {
                              if (value) {widget.model.init()}
                            }
                        });
              },
              child: Container(
                color: backgroundColor,
                child: Column(
                  children: <Widget>[
                     Container(
                       padding: EdgeInsets.all(8),
                       color: secondaryColor,
                       height: 30,
                       child: Row(
                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                         children: <Widget>[
                           Text(
                             transaction.day + ', ' + transaction.month,
                             style: TextStyle(fontWeight: FontWeight.w700,  color: Colors.white),
                           ),
                           Text(
                             transaction.type +
                                 " : " +  formatCurrency.format( transaction.amount).toString(),
                             style: TextStyle(fontWeight: FontWeight.w700,  color: Colors.white),
                           )
                         ],
                       ),
                     ),
                    // Divider(
                    //   thickness: 1,
                    //   color: Colors.white,
                    // ),
                    Divider(
                      color: Colors.white,
                    ),
                    Row(
                      mainAxisAlignment:MainAxisAlignment.spaceBetween ,
                      children: [
                       Container(
                         padding: EdgeInsets.only(left: 10, bottom: 10),
                         child:  Text(transaction.memo, style: TextStyle(fontSize: 20, color: Colors.white)),
                       ),
                        Container(
                          padding: EdgeInsets.only(right: 10,  bottom: 10),
                          child:    transaction.type == 'expense'
                              ? Text('- ' + formatCurrency.format( transaction.amount).toString(),
                              style: TextStyle(fontSize: 20, color: Colors.white))
                              : Text(formatCurrency.format( transaction.amount).toString().toString(),
                              style: TextStyle(fontSize: 20, color: Colors.white))
                        ),


                      ],
                    ),
                    // ListTile(
                    //   // leading: CircleAvatar(
                    //   //   radius: 25,
                    //   //   backgroundColor: Colors.blue.withOpacity(.1),
                    //   //   child: widget.model.getIconForCategory(transaction.categoryindex, transaction.type),
                    //   // ),
                    //   title: Text(transaction.memo, style: TextStyle(fontSize: 20, color: Colors.white)),
                    //   trailing: transaction.type == 'expense'
                    //       ? Text('- ' + formatCurrency.format( transaction.amount).toString(),
                    //           style: TextStyle(fontSize: 20, color: Colors.white))
                    //       : Text(formatCurrency.format( transaction.amount).toString().toString(),
                    //           style: TextStyle(fontSize: 20, color: Colors.white)),
                    // )
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class TransactionsListViewDay extends StatefulWidget {
  final List<Transaction> transactions;
  final HomeModel model;

  const TransactionsListViewDay(
      this.transactions,
      this.model,
      );

  @override
  _TransactionsListViewDayState createState() => _TransactionsListViewDayState();
}

class _TransactionsListViewDayState extends State<TransactionsListViewDay> {

  final formatCurrency = new NumberFormat.simpleCurrency(locale: 'id_ID');

  @override
  Widget build(BuildContext context) {

    return ListView(
      controller: widget.model.scrollController,
      // padding: EdgeInsets.all(8),
      children: widget.transactions.map((transaction) {
        // print("transaction "+transaction.toString());
        return Card(
          child: InkWell(
            onTap: () {
              Navigator.pushNamed(context, "details", arguments: transaction)
                  .then((value) => {
                if (value != null)
                  {
                    if (value) {widget.model.init()}
                  }
              });
            },
            child: Container(
              color: backgroundColor,
              child: Column(
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.all(8),
                    color: secondaryColor,
                    height: 30,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          transaction.day + ', ' + transaction.month,
                          style: TextStyle(fontWeight: FontWeight.w700,  color: Colors.white),
                        ),
                        Text(
                          transaction.type +
                              ": " +  formatCurrency.format( transaction.amount).toString(),
                          style: TextStyle(fontWeight: FontWeight.w700,  color: Colors.white),
                        )
                      ],
                    ),
                  ),
                  // Divider(
                  //   thickness: 1,
                  //   color: Colors.white,
                  // ),
                  Container(
                    padding: EdgeInsets.only(right: 5, left: 5),
                    height: 30,
                    child: Row(
                        mainAxisAlignment:  MainAxisAlignment.spaceBetween,
                      // Ax: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(transaction.memo, style: TextStyle(fontSize: 12, color: Colors.white)),
                        transaction.type == 'expense'
                              ? Text('- ' + formatCurrency.format( transaction.amount).toString(),
                              style: TextStyle(fontSize: 12, color: Colors.white))
                              : Text(formatCurrency.format( transaction.amount).toString().toString(),
                              style: TextStyle(fontSize: 12, color: Colors.white))
                      ],
                    ),
                    // child: ListTile(
                    //   leading: CircleAvatar(
                    //     radius: 25,
                    //     backgroundColor: Colors.blue.withOpacity(.1),
                    //     child: widget.model.getIconForCategory(transaction.categoryindex, transaction.type),
                    //   ),
                    //   title: Text(transaction.memo, style: TextStyle(fontSize: 12, color: Colors.white)),
                    //   trailing: transaction.type == 'expense'
                    //       ? Text('- ' + formatCurrency.format( transaction.amount).toString(),
                    //       style: TextStyle(fontSize: 12, color: Colors.white))
                    //       : Text(formatCurrency.format( transaction.amount).toString().toString(),
                    //       style: TextStyle(fontSize: 12, color: Colors.white)),
                    // ),
                  )
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
