import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


class LineChartMonth extends StatefulWidget {
  final List<FlSpot> FlSpotdata;
  final double dataMax;
  final List<int> showIndexes;
  LineChartMonth(this.FlSpotdata, this.dataMax, this.showIndexes);
  @override
  _LineChartSample2State createState() => _LineChartSample2State();
}

class _LineChartSample2State extends State<LineChartMonth> {
  List<Color> gradientColors = [
    const Color(0xff23b6e6),
    const Color(0xff02d39a),
  ];
  // final List<int> showIndexes = const [1, 3, 5];
  bool showAvg = true;






  @override
  Widget build(BuildContext context) {



    // print();
    return Stack(
      children: <Widget>[

       Container(
         height: 200,
         child:  ListView(
           // This next line does the trick.
           scrollDirection: Axis.horizontal,
           children: <Widget>[
             AspectRatio(
               aspectRatio: 2.70,
               child: Container(
                 decoration: const BoxDecoration(
                   // borderRadius: BorderRadius.all(
                   //   Radius.circular(18),
                   // ),
                     color: Color(0xff232d37)),
                 child: Padding(
                   padding: const EdgeInsets.only(right: 0.0, left: 0.0, top: 50, bottom: 0),
                   child:  LineChart(
                     mainData(),
                   ),
                 ),
               ),
             ),
           ],
         ),
       ),

        // SizedBox(
        //   width: 60,
        //   height: 34,
        //   child: TextButton(
        //     onPressed: () {
        //       setState(() {
        //         showAvg = !showAvg;
        //       });
        //     },
        //     child: Text(
        //       'avg',
        //       style: TextStyle(
        //           fontSize: 12, color: showAvg ? Colors.white.withOpacity(0.5) : Colors.white),
        //     ),
        //   ),
        // ),
      ],
    );
  }

  LineChartData mainData() {
    final formatter = new NumberFormat("#,###");
    DateTime datenow = DateTime.now();
    final lineBarsData = [
      LineChartBarData(
        spots: widget.FlSpotdata,
        isCurved: false,
        colors: gradientColors,
        barWidth: 5,
        isStrokeCapRound: false,
        dotData: FlDotData(
          show: true,
        ),
        belowBarData: BarAreaData(
          show: true,
          colors: gradientColors.map((color) => color.withOpacity(0.3)).toList(),
        ),
      ),
    ];

    final tooltipsOnBar = lineBarsData[0];
    return LineChartData(
      extraLinesData:ExtraLinesData(

      ),
      lineTouchData: LineTouchData(
        enabled: false,
        getTouchedSpotIndicator: (LineChartBarData barData, List<int> spotIndexes) {
          return spotIndexes.map((index) {
            return TouchedSpotIndicatorData(
              FlLine(
                color: Colors.pink,
              ),
              FlDotData(
                show: true,
                getDotPainter: (spot, percent, barData, index) => FlDotCirclePainter(
                  radius: 2,
                  color: const Color(0xff37434d),
                  strokeWidth: 2,
                  strokeColor: Colors.white,
                ),
              ),
            );
          }).toList();
        },
        touchTooltipData: LineTouchTooltipData(
          tooltipBgColor: Colors.transparent,
          tooltipRoundedRadius: 8,
          getTooltipItems: (List<LineBarSpot> lineBarsSpot) {
            return lineBarsSpot.map((lineBarSpot) {
              // print(lineBarSpot.y.toString());
              return lineBarSpot.y.toString() != "0.0"?
               LineTooltipItem(
                   (formatter.format(lineBarSpot.y.round() *100)).toString(),
                const TextStyle(color: Colors.white, ),
              ) : null;
            }).toList();
          },
        ),
      ),
      showingTooltipIndicators: widget.showIndexes.map((index) {
        // print("index "+index.toString());
        return ShowingTooltipIndicators([
          LineBarSpot(
              tooltipsOnBar, lineBarsData.indexOf(tooltipsOnBar), tooltipsOnBar.spots[index]),
        ]);
      }).toList(),
      gridData: FlGridData(
        show: true,
        drawVerticalLine: true,
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xff37434d),
            strokeWidth: 1,
          );
        },
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xff37434d),
            strokeWidth: 1,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: SideTitles(
          showTitles: true,
          reservedSize: 22,
          getTextStyles: (value) {
            if(value.toInt() == datenow.month-1){
              return  const TextStyle(
                color: Colors.red,
                fontWeight: FontWeight.bold,
                fontSize: 10,
              );
            }else{
              return  const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 10,
              );
            }
            print("value "+value.toString());
            // datenow.month
            // switch (value.toInt()) {
            //   case 6:
            //     return  const TextStyle(
            //       color: Colors.red,
            //       fontWeight: FontWeight.bold,
            //       fontSize: 10,
            //     );
            // // case 3:
            // //   return '30k';
            // // case 5:
            // //   return '50k';
            // }
            return null;
          },
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return 'JAN';
              case 1:
                return 'FEB';
              case 2:
                return 'MAR';
              case 3:
                return 'APR';
              case 4:
                return 'MEI';
              case 5:
                return 'JUL';
              case 6:
                return 'JUN';
              case 7:
                return 'AUG';
              case 8:
                return 'SEP';
              case 9:
                return 'OCT';
              case 10:
                return 'NOV';
              case 11:
                return 'DEC';
            }
            return '';
          },
          margin: 8,
        ),
        leftTitles: SideTitles(
          showTitles: true,
          getTextStyles: (value) => const TextStyle(
            color: Color(0xff67727d),
            fontWeight: FontWeight.bold,
            fontSize: 15,
          ),
          getTitles: (value) {
            // switch (value.toInt()) {
            //   case 1:
            //     return '10k';
            //   case 3:
            //     return '30k';
            //   case 5:
            //     return '50k';
            // }
            return '';
          },
          reservedSize: 28,
          margin: 12,
        ),
      ),
      borderData:  FlBorderData(show: true, border: Border.all(color: const Color(0xff37434d), width: 1)),
      minX: 0,
      maxX: 11,
      minY: 0,
      // maxY: int.parse((widget.dataMax.round().toString() +"0")).toDouble(),
      maxY: widget.dataMax,
      lineBarsData: [
        LineChartBarData(
          showingIndicators: widget.showIndexes,
          spots: widget.FlSpotdata,
          isCurved: false,
          colors: gradientColors,
          barWidth: 5,
          isStrokeCapRound: false,
          // showingIndicators:[
          //   10,
          //   100
          // ],
          dotData: FlDotData(
            show: true,
              // getDotPainter: (spot, percent, barData, index) {
              // print(barData);
              // return FlDotCirclePainter(color: Colors.white);
              // },

            // getDotPainter: (FlSpot, double, LineChartBarData, int){
            // print(FlSpot);
            // return null;
            // }
          ),
          belowBarData: BarAreaData(
            show: true,
            colors: gradientColors.map((color) => color.withOpacity(0.3)).toList(),
          ),
        ),
      ],

    );
  }

}