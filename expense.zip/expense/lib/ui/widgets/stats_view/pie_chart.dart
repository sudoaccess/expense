import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/services/moordatabase_service.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:pie_chart/pie_chart.dart';
import '../../../globals.dart' as globals;
import '../../../locator.dart';
import 'package:random_color/random_color.dart';

// enum LegendShape { Circle, Rectangle }

class PieChartView extends StatelessWidget  {
  final String dataStats;
  final HomeModel model;
  final int dataType;
  final DateTime dataDate;
  final Map dataMap;
  final  List<Color> colorList;
//
  PieChartView(this.dataStats, this.model, this.dataType, this.dataDate,  this.dataMap,  this.colorList);
//   @override
//   State<PieChartView>  createState() => _PieChartState();
// }
//
// class _PieChartState extends State<PieChartView>   with TickerProviderStateMixin {


  var db = DBHelper();
  final MoorDatabaseService _moorDatabaseService =locator<MoorDatabaseService>();
  List<Transaction> transactions = List<Transaction>();
  RandomColor _randomColor = RandomColor();


  // var dataMapIncome = new Map<String, double>();
  // var dataMapExpense = new Map<String, double>();


  // List<Color> colorList = [
  //   Colors.red,
  //   Colors.green,
  //   Colors.blue,
  //   Colors.yellow,
  //   Colors.orange,
  //   Colors.cyanAccent,
  //   Colors.teal,
  //   Colors.deepPurple,
  // ];

  ChartType _chartType = ChartType.disc;
  bool _showCenterText = true;
  double _ringStrokeWidth = 32;
  double _chartLegendSpacing = 32;

  bool _showLegendsInRow = false;
  bool _showLegends = true;

  bool _showChartValueBackground = true;
  bool _showChartValues = false;
  bool _showChartValuesInPercentage = false;
  bool _showChartValuesOutside = false;

  // LegendShape _legendShape = LegendShape.Circle;
  LegendPosition _legendPosition = LegendPosition.right;

  // int key = 0;
  // bool isLoading = true;
  // @override
  // void initState() {
  //   // TODO: implement initState
  //
  //   getdata();
  //   globals.isShowingStats = false;
  //   print("initState "+widget.dataDate.toString());
  //   super.initState();
  // }



  @override
  Widget build(BuildContext context) {

    Color _color = _randomColor.randomColor();

    return globals.isShowingStats  != true ?
    // isLoading ?
    // Center(
    //   child: SpinKitWave(color: Colors.white, type: SpinKitWaveType.center)) :
    new PieChart(
      key: ValueKey(key),
      dataMap: dataMap,
      animationDuration: Duration(milliseconds: 800),
      chartLegendSpacing: _chartLegendSpacing,
      chartRadius: MediaQuery.of(context).size.width / 3.2 > 300? 300: MediaQuery.of(context).size.width / 3.2,
      colorList: colorList,
      initialAngleInDegree: 0,
      chartType: _chartType,
      // centerText: _showCenterText ? "HYBRID" : null,
      legendOptions: LegendOptions(
        showLegendsInRow: _showLegendsInRow,
        legendPosition: _legendPosition,
        showLegends: _showLegends,
        legendShape: BoxShape.circle,
        legendTextStyle: TextStyle(
          color: midnightBlue,
          fontWeight: FontWeight.bold,
        ),
      ),
      chartValuesOptions: ChartValuesOptions(
        showChartValueBackground: _showChartValueBackground,
        showChartValues: _showChartValues,
        showChartValuesInPercentage: _showChartValuesInPercentage,
        showChartValuesOutside: _showChartValuesOutside,
      ),
      ringStrokeWidth: _ringStrokeWidth,
      emptyColor: Colors.grey,
    )  :  Center(child: Text("No data available", style: TextStyle(color: Colors.white),));
  }
}