import 'dart:developer';

import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/enums/viewstate.dart';
import 'package:moneymanager/core/models/category.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/core/services/moordatabase_service.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/ui/views/base_view.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/pop_up.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/summary_widget.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/transactions_listview_widget.dart';
import 'package:moneymanager/ui/widgets/stats_view/pie_chart.dart';
import 'package:random_color/random_color.dart';
// import 'package:month_picker_dialog/month_picker_dialog.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';  //for date format
import 'package:moneymanager/ui/widgets/indonesia_format.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../../locator.dart';
import '../indonesia_format.dart';
import '../../../globals.dart' as globals;
import 'detail_stats.dart';
import 'package:fl_chart/fl_chart.dart';



class StatsBar extends StatefulWidget {
  final HomeModel model;

  StatsBar(this.model);

  @override
  State<StatsBar> createState() => _StatsBarState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _StatsBarState extends State<StatsBar>  with TickerProviderStateMixin {
  List listData = [];
  TabController _tabController, _tabControllerMenu, _tabControllerMenuIndex;
  DateTime selectedDate;
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  List months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei','Jun','Jul','Agt','Sep','Okt','nov','Des'];
  List monthsAngka = ['01', '02', '03', '04', '05','06','07','08','09','10','11','12'];
  List dropDwon = ['W', 'M', 'Y', 'L', 'T'];
  List dropDwonText = ['Weekly', 'Monthly', 'Annualy', 'List', 'Trend'];
  int dropDwonInt = 1;
  String tittle = "";
  List <int> showIndexes = [];
  var waktu = Waktu();
  DateTime datetime = DateTime.now();
  String dropdownValue = 'M';
  final formatCurrency = new NumberFormat.simpleCurrency(locale: 'id_ID');
  // Widget globals.dataBodyPie = Container();
  var dataStats = "";
  var db = DBHelper();
  final MoorDatabaseService _moorDatabaseService =locator<MoorDatabaseService>();
  List<Transaction> transactions = List<Transaction>();
  RandomColor _randomColor = RandomColor();
  int percentage = 0;
  List<FlSpot> FlSpotdata = [];

  var dataMapIncome = new Map<String, double>();
  var dataMapExpense = new Map<String, double>();
  var dataMap = new Map<String, double>();
  var dataMapSend = new Map<String, double>();
  var dataMapIncomeSend = new Map<String, double>();
  var dataMapExpenseSend = new Map<String, double>();
  List DataCategory = [];
  double dataMax;
  List<Color> colorList = [];
  

  @override
  void initState() {

    // tittle = waktu.LLL() +" "+datetime.year.toString() ;
    _tabController = TabController(length: 3, vsync: this);
    _tabController.index = 0;
    dropDwon[dropDwonInt];
    _tabControllerMenu = TabController(length: 2, vsync: this);
    globals.currentDate = widget.model.currentTimeModel;
    globals.incomeTotal = widget.model.incomeSum;
    globals.expeseTotal = widget.model.expenseSum;
    dataStats = "month";

    _tabController.addListener(() {
      getdata(DateTime.now());
    });
    getdata(DateTime.now());
    super.initState();
  }





  void  getdata(date) async {

    SharedPreferences prefs = await SharedPreferences.getInstance();
    final date2 = date;
    final startOfYear = new DateTime(date2.year, 1, 1, 0, 0);
    final firstMonday = startOfYear.weekday;
    final daysInFirstWeek = 8 - firstMonday;
    final diff = date2.difference(startOfYear);
    var weeks = ((diff.inDays - daysInFirstWeek) / 7).ceil();
    if(daysInFirstWeek > 3) {
      weeks += 1;
    }


    percentage = 0;
    DataCategory = [];
    FlSpotdata = [];
    dataMap = Map<String, double>();
    dataMapIncome = new Map<String, double>();
    dataMapExpense = new Map<String, double>();
    dataMapSend = new Map<String, double>();
    dataMapIncomeSend = new Map<String, double>();
    dataMapExpenseSend = new Map<String, double>();

    var now = date;
    var lastMonth = DateTime(now.year, now.month -1, now.day);
    var bulan = "";
    var bulanLast = "";

    if (now.month.toString().length == 1) {
      bulan = "0" + now.month.toString();
    }

    if (lastMonth.month.toString().length == 1) {
      bulanLast = "0" + lastMonth.month.toString();
    }



    if(dataStats == "month"){

      transactions = await _moorDatabaseService.getAllTransactions(bulan, now.year.toString());

      setState(() {
        globals.Tittle = Waktu(date).LLL() + " " +date.year.toString();
      });
    }else if(dataStats == "week"){

      // get week
      var now = date;
      var startFrom = now.subtract(Duration(days: now.weekday));
      var list = List.generate(7, (i) => '${startFrom.add(Duration(days: i)).day}');

      setState(() {
        globals.Tittle =  list[0].toString() +
            "/" +
            bulan.toString() +
            " ~ " +
            list[6].toString() +
            "/" +
            bulan.toString();
      });
      // transactions = await _moorDatabaseService.getAllTransactions(bulan, now.year.toString());
      transactions = await _moorDatabaseService.getAllTransactionsPerWeek(weeks.toString(), bulan, now.year.toString());
    }
    log("bulan"+transactions.toString());
    print("transactions.length"+transactions.length.toString());
    if(transactions.isNotEmpty){
      var countCategory = 0.0;
      for (int i = 0; i < transactions.length; i++) {
        var category = "";
        var Account = "";
        var accountgrouplist = await db.getAccountListByID("accountlist", transactions[i].accountindex);
        Account = accountgrouplist[0].name;

        if(_tabControllerMenu.index == 0){
          if(transactions[i].type == "income"){
            var incominglist = await db.getIncomingListByID("incominglist", transactions[i].categoryindex);
            countCategory = await _moorDatabaseService.getCountTransactionBycategory(incominglist[0].id.toString(), "income");
            category =  incominglist[0].name;
            dataMapIncome[""+category+","+transactions[i].amount.toString()+""] = countCategory;
            dataMapIncomeSend[""+category+""] = countCategory;
            DataCategory.add(dataMapIncome);
            percentage += countCategory.round();
            Color _color = _randomColor.randomColor();
            if(prefs.getInt('getNameIncome$i') != _color.value && prefs.getInt('getNameIncome$i').toString() != "null"){
              Color color = Color(prefs.getInt('getNameIncome$i'));
              colorList.add(color);
            }else{
              prefs.setInt('getNameIncome$i', _color.value);
              colorList.add(_color);
            }

          }
          dataMapSend = dataMapIncomeSend;
          dataMap = dataMapIncome;
          log("dataMapIncome "+dataMapIncome.toString());
        }

        if(_tabControllerMenu.index == 1){
          if(transactions[i].type == "expense"){
            // getCountcategory(table_name, categoryindex)
            var expenselist = await db.getIncomingListByID("expenselist", transactions[i].categoryindex);
            countCategory = await _moorDatabaseService.getCountTransactionBycategory(expenselist[0].id.toString(), "expense");
            category =  expenselist[0].name;
            dataMapExpense[""+category+","+transactions[i].amount.toString()+""] = countCategory;
            dataMapExpenseSend[""+category+""] = countCategory;
            DataCategory.add(dataMapExpense);
            percentage += countCategory.round();
            Color _color = _randomColor.randomColor();

            if(prefs.getInt('getNameExpense$i') != _color.value && prefs.getInt('getNameExpense$i').toString() != "null"){
              Color color = Color(prefs.getInt('getNameExpense$i'));
              colorList.add(color);
            }else{
              prefs.setInt('getNameExpense$i', _color.value);
              colorList.add(_color);
            }
          }
          dataMapSend = dataMapExpenseSend;
          dataMap = dataMapExpense;
        }


      }


    }else{

    }
    setState(() {
      if(_tabController.index == 0){
        if(dataMap.isNotEmpty){
          globals.dataBodyPie = PieChartView(dataStats, widget.model, _tabControllerMenu.index, globals.currentDate, dataMapSend, colorList);
        }else{
          globals.dataBodyPie = Container();
        }

      }else{
        globals.dataBodyPie = Container();
      }

    });

    for (var i = 0; i < monthsAngka.length; i++) {

      var bulan = "";

      if (monthsAngka[i].toString().length == 1) {
        bulan = "0" + monthsAngka[i].toString();
      }else{
        bulan = monthsAngka[i].toString();
      }

      if(_tabControllerMenu.index == 0){
        int incomeSum = await _moorDatabaseService.getIncomeSum(bulan, widget.model.currentTimeModel.year.toString());
        FlSpotdata.add(FlSpot(i.toDouble(), (incomeSum /100 ).toDouble()));
        showIndexes.add(i);
      }else{
        showIndexes.add(i);
        int expenseSum = await _moorDatabaseService.getExpenseSum(bulan, widget.model.currentTimeModel.year.toString());
        FlSpotdata.add(FlSpot(i.toDouble(), (expenseSum /100 ).toDouble()));
      }

      // print(_tabControllerMenu.index);
      // if (incomeSum.toString() != null && incomeSum.toString().length >= 5) {
      //   // incomeSum = int.parse(incomeSum.toString().substring(0, incomeSum.toString().length - 2));
      // }


    }

    if (FlSpotdata != null && FlSpotdata.isNotEmpty) {
      dynamic max = FlSpotdata.first;
      FlSpotdata.forEach((e) {
        if (e.y > max.y) max = e;
      });
      // print(max.y.round() +10);
      dataMax = (max.y.round() +10).toDouble();
      // dataMax = int.parse(max.y.round() +10).toDouble();
    }
    // FlSpotdata.sort((a, b) => a.y.compareTo(b.y));

    // List weightData = getKeysFromMap.entries.map( (entry) => (entry.key, entry.value)).toList();
    // print("TR "+dataMax.toString());
    // print("TR "+FlSpotdata.toString());
  }


  getKey(data){
    var datatemp = data.split(",");
    return datatemp[0].toString();
  }
  getAmmount(data){
    var datatemp = data.split(",");

    return formatCurrency.format(int.parse(datatemp[1])).toString();
  }

  @override
  Widget build(BuildContext context) {
    return  BaseView<HomeModel>(
        onModelReady: (model) async {
          await model.init();
          // print(model.transactions.toString());
    },
    builder: (context, model, child) =>
        Scaffold(
          key: _scaffoldKey,
          body: Container(
            height: MediaQuery.of(context).size.height,
            child: Column(
              children: <Widget>[
                Container(
                  color: backgroundColor,
                  width: MediaQuery.of(context).size.width,
                  // height: 500.0,
                  child: Column(
                    children: [
                      SizedBox(height: 30,),
                     Row(
                       children: [
                         Expanded(child:
                         ButtonsTabBar(
                           radius: 50,
                           // buttonMargin : EdgeInsets.only(right: 5, left: 5),
                           contentPadding:  EdgeInsets.only(right: 22, left: 22),
                           // center: true,
                           // physics: BouncingScrollPhysics(),
                           controller : _tabController,
                           decoration: BoxDecoration(
                             color: Colors.white,
                           ),
                           unselectedBorderColor: Colors.grey,
                           // backgroundColor: secondaryColor,
                           unselectedBackgroundColor: backgroundColor,
                           unselectedLabelStyle: TextStyle(color: Colors.white),
                           labelStyle: TextStyle(color: backgroundColor, fontWeight: FontWeight.bold),
                           tabs: [
                             Tab(
                               text: "Stats",
                             ),
                             Tab(
                               text:  "Budget",
                             ),
                             Tab(
                               text: "Note",
                             ),
                           ],
                         )),
                       SizedBox(width: 5,),
                       dropDwonList(model)

                     ],
                     ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            color: Colors.white,
                            iconSize: 40,
                            icon: const Icon(Icons.chevron_left),
                            onPressed: () async{
                              if( dataStats == "month"){
                                var tempdateNow = model.currentTimeModel;
                                DateTime dateNow = DateTime(tempdateNow.year, tempdateNow.month -1, tempdateNow.day);
                                await model.update(dateNow.toString());

                                setState(() {
                                  print(model.expenseSum);
                                  globals.incomeTotal = model.incomeSum;
                                  globals.expeseTotal = model.expenseSum;
                                });
                                getdata(dateNow);
                              }else{
                                var tempdateNow = model.currentTimeModel;
                                DateTime dateNow = DateTime(tempdateNow.year, tempdateNow.month , tempdateNow.day - 7);
                                await model.update(dateNow.toString());

                                setState(() {
                                  print(model.incomeSumPerWeek);
                                  globals.incomeTotal = model.incomeSumPerWeek;
                                  globals.expeseTotal = model.expenseSumPerWeek;
                                });
                                getdata(dateNow);
                              }

                              // setState(()  {
                              //
                              //   globals.currentDate = model.currentTimeModel;
                              //   if(_tabController.index == 0){
                              //     globals.dataBodyPie = PieChartView(dataStats, widget.model, _tabControllerMenu.index, globals.currentDate, dataMap);
                              //   }else if(_tabController.index == 1){
                              //     globals.dataBodyPie = Container();
                              //   }else{
                              //     globals.dataBodyPie = Container();
                              //   }
                              // });
                               if( _tabController.index == 0){

                                 setState(() {
                                   if(model.transactions.isEmpty){
                                     globals.isShowingStats = true;
                                   }else{
                                     globals.isShowingStats = false;
                                   }

                                 });
                               }

                            },
                          ),
                          Container(
                              child: Center(
                                child: Text(globals.Tittle, style: TextStyle(color: Colors.white)),
                              )
                          ),
                          IconButton(
                            color: Colors.white,
                            iconSize: 40,
                            icon: const Icon(Icons.chevron_right),
                            onPressed: () async {
                             if( dataStats == "month"){
                               var tempdateNow = model.currentTimeModel;
                               DateTime dateNow = DateTime(tempdateNow.year, tempdateNow.month +1, tempdateNow.day);
                               await model.update(dateNow.toString());

                               setState(() {
                                 globals.incomeTotal = model.incomeSum;
                                 globals.expeseTotal = model.expenseSum;
                               });

                               getdata(dateNow);
                             }else{
                               var tempdateNow = model.currentTimeModel;
                               DateTime dateNow = DateTime(tempdateNow.year, tempdateNow.month , tempdateNow.day + 7);
                               await model.update(dateNow.toString());

                               setState(() {
                                 globals.incomeTotal = model.incomeSumPerWeek;
                                 globals.expeseTotal = model.expenseSumPerWeek ;
                               });

                               getdata(dateNow);
                             }



                              // setState(()  {
                              //
                              //   globals.currentDate = model.currentTimeModel;
                              //   if(_tabController.index == 0){
                              //     globals.dataBodyPie = PieChartView(dataStats, widget.model, _tabControllerMenu.index, globals.currentDate, dataMap);
                              //   }else if(_tabController.index == 1){
                              //     globals.dataBodyPie = Container();
                              //   }else{
                              //     globals.dataBodyPie = Container();
                              //   }
                              // });
                             if( _tabController.index == 0){
                               setState(() {
                                 if(model.transactions.isEmpty){
                                   globals.isShowingStats = true;
                                 }else{
                                   globals.isShowingStats = false;
                                 }


                               });
                             }
                             // globals.Tittle = Waktu(model.currentTimeModel).LLL() + " " +model.currentTimeModel.year.toString();
                            },
                          ),
                        ],
                      ),
                      Container(
                        color: secondaryColor,
                        child: TabBar(
                          onTap: (index2) async {
                            getdata(model.currentTimeModel);
                          },
                          controller: _tabControllerMenu,
                          tabs:  <Widget>[
                            Tab(
                              icon: Text("Income "+ formatCurrency.format(globals.incomeTotal).toString(),
                                // style: TextStyle(fontSize: 9),
                              ),
                            ),
                            Tab(
                              icon: Text("Expense "+ formatCurrency.format(globals.expeseTotal).toString()
                                // style: TextStyle(fontSize: 9),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  )
                ),
                Column(
                  children: [
                    new Container(
                      color: greenYellow,
                      child: globals.dataBodyPie,
                    ),


                  ],
                ),

                dataMap.isNotEmpty ?
                Expanded(child:
                SingleChildScrollView(
                  child: Column(
                      children: dataMap.entries.toList().map((data) => Container(
                        height: 50,
                        color: greenYellow,
                        child: InkWell(
                          onTap: (){
                            // print(getKey(data.key));
                            var datatemp = data.key.split(",");
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => DetailStats(model, datatemp[0].toString(), FlSpotdata, dataMax, showIndexes, _tabControllerMenu.index),
                              ),
                            );
                            // Navigator.of(context).pushNamed("detail_stats");
                          },
                          child:  Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(left: 10),
                                child: Row(
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: backgroundColor,
                                        boxShadow: [
                                          BoxShadow(color: Colors.grey, spreadRadius: 1),
                                        ],
                                      ),
                                      child:  Padding(
                                        padding: EdgeInsets.all(3),
                                        child: Text((( data.value.round() / percentage) * 100).round().toString() +" %", style: TextStyle(color: midnightBlue),),
                                      ),
                                    ),
                                    Padding(padding: EdgeInsets.only(left: 10),
                                        child: Text( getKey(data.key), style: TextStyle(color: midnightBlue) ,))
                                  ],
                                ),
                              ),

                              Padding(padding: EdgeInsets.only( right: 10),
                                // child: Text((percentage.toString() +" %")),
                                child:  Text(getAmmount(data.key), style: TextStyle(color: midnightBlue) ) ,

                              ),
                              // Text(data.value.round().toString())
                            ],
                          ),
                        ),
                      ),

                      ).toList()
                  ),
                )) : Container()

              ],
            ),
          ),
        )
    );

  }

  Color getColor(Set<MaterialState> states) {
    const Set<MaterialState> interactiveStates = <MaterialState>{
      MaterialState.pressed,
      MaterialState.hovered,
      MaterialState.focused,
    };
    if (states.any(interactiveStates.contains)) {
      return Colors.blue;
    }
    return Colors.white70;
  }

  Color getColorRed(Set<MaterialState> states) {
    const Set<MaterialState> interactiveStates = <MaterialState>{
      MaterialState.pressed,
      MaterialState.hovered,
      MaterialState.focused,
    };
    if (states.any(interactiveStates.contains)) {
      return Colors.blue;
    }
    return Colors.red;
  }

  _openList(context, model) {
    showModalBottomSheet(
        backgroundColor: Colors.transparent,
        context: context,
        builder: (context) {
          return Column(
            children: [
              Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(20))
                  ),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 300,
                  child: ListView.separated(
                      padding: const EdgeInsets.all(2),
                      itemCount: dropDwon.length,
                      separatorBuilder: (context, index) {
                        return Divider();
                      },
                      itemBuilder: (BuildContext context, int index) {
                        return   ListTile(
                          title: Text(dropDwonText[index].toString()),
                          trailing: dropDwonInt == index ? Icon(Icons.check, color: backgroundColor,) : Icon(Icons.check, color: Colors.white,) ,
                          onTap: () {
                            setState(() {
                              if(index== 0){
                                dataStats = "week";
                              } else if(index== 1){
                                dataStats = "month";
                              }
                              getdata(globals.currentDate);

                              // if(_tabController.index == 0){
                              //
                              //   globals.dataBodyPie = PieChartView(dataStats, widget.model, _tabControllerMenu.index, globals.currentDate, dataMap);
                              // }else if(_tabController.index == 1){
                              //   globals.dataBodyPie = Container();
                              // }else{
                              //   globals.dataBodyPie = Container();
                              // }
                              dropDwonInt = index;
                            });
                            Navigator.pop(context);
                          },
                        );
                        // return OutlinedButton(
                        //   onPressed: (){

                        //   },
                        //   style: ButtonStyle(
                        //     backgroundColor: MaterialStateProperty.resolveWith(getColor) ,
                        //     shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(30.0))),
                        //   ),
                        //   child: Text(dropDwonText[index].toString(), style: TextStyle(color: Colors.black),)
                        // );
                      }
                  )
              ),
              Container(
                  width: MediaQuery.of(context).size.width / 1.1,
                  child: OutlinedButton(
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.resolveWith(getColorRed) ,
                        shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(30.0))),
                      ),
                      // minWidth: 300,
                      child: Text("Cancel", style: TextStyle(color: Colors.black),)
                  )

              ),

            ],
          );
        });
  }

  dropDwonList(model){
    return Container(
      height: 30,
      // margin: const EdgeInsets.all(2.0),
      padding: const EdgeInsets.all(5.0),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30.0),
          border: Border.all(color: Colors.white)
      ),
      child: InkWell(
        onTap: (){
          _openList(context, model);
        },
        child:  Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(padding: EdgeInsets.only(left:10),
              child: Text( dropDwon[dropDwonInt].toString(), style: TextStyle(color: Colors.white),),
            ),
            Padding(
              padding: EdgeInsets.only(left:10),
              child:  Icon(
                Icons.arrow_drop_down,
                color: Colors.white,
                size: 24.0,
                semanticLabel: 'Text to announce in accessibility modes',
              ),
            )

            // Text(dropDwon[1].toString(), style: TextStyle(color: Colors.white),),
          ],
        ),
      ),
    );


  }
}
