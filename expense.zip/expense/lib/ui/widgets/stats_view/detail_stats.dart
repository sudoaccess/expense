import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/enums/viewstate.dart';
import 'package:moneymanager/core/models/category.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/core/services/moordatabase_service.dart';
import 'package:moneymanager/core/viewmodels/home_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/ui/views/base_view.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/pop_up.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/summary_widget.dart';
import 'package:moneymanager/ui/widgets/home_view_widgets/transactions_listview_widget.dart';
import 'package:moneymanager/ui/widgets/stats_view/pie_chart.dart';
import 'package:moneymanager/ui/widgets/stats_view/stats.dart';
import 'package:random_color/random_color.dart';
// import 'package:month_picker_dialog/month_picker_dialog.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';  //for date format
import 'package:moneymanager/ui/widgets/indonesia_format.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../../locator.dart';
import '../indonesia_format.dart';
import '../../../globals.dart' as globals;
import 'line_chart.dart';


class DetailStats extends StatefulWidget {
  final HomeModel model;
  final String title;
  final List<FlSpot> FlSpotdata;
  final double dataMax;

  final List<int> showIndexes;
  final int dataType;
  DetailStats(this.model, this.title, this.FlSpotdata, this.dataMax, this.showIndexes, this.dataType);

  @override
  State<DetailStats> createState() => _DetailStatsState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _DetailStatsState extends State<DetailStats>  with TickerProviderStateMixin {
  List listData = [];
  TabController _tabController, _tabControllerMenu, _tabControllerMenuIndex;
  // DateTime selectedDate;
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  // List listData = [];
  // TabController _tabController, _tabControllerMenu, _tabControllerMenuIndex;
  // DateTime selectedDate;
  // GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  List months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei','Jun','Jul','Agt','Sep','Okt','nov','Des'];
  List monthsAngka = ['01', '02', '03', '04', '05','06','07','08','09','10','11','12'];
  List dropDwon = ['W', 'M', 'Y', 'L', 'T'];
  List dropDwonText = ['Weekly', 'Monthly', 'Annualy', 'List', 'Trend'];
  int dropDwonInt = 1;
  String tittle = "";
  List <int> showIndexes = [];
  var waktu = Waktu();
  DateTime datetime = DateTime.now();
  String dropdownValue = 'M';
  final formatCurrency = new NumberFormat.simpleCurrency(locale: 'id_ID');
  // Widget globals.dataBodyPie = Container();
  var dataStats = "";
  var db = DBHelper();
  final MoorDatabaseService _moorDatabaseService =locator<MoorDatabaseService>();
  List<Transaction> transactions = List<Transaction>();
  RandomColor _randomColor = RandomColor();
  int percentage = 0;
  List<FlSpot> FlSpotdata = [];

  var dataMapIncome = new Map<String, double>();
  var dataMapExpense = new Map<String, double>();
  var dataMap = new Map<String, double>();
  var dataMapSend = new Map<String, double>();
  var dataMapIncomeSend = new Map<String, double>();
  var dataMapExpenseSend = new Map<String, double>();
  List DataCategory = [];
  double dataMax;
  List<Color> colorList = [];

  @override
  void initState() {
    _tabController = TabController(length: 3, vsync: this);
    super.initState();
  }

  void  getdata(date) async {
    percentage = 0;
    DataCategory = [];
    FlSpotdata = [];
    showIndexes = [];
    dataMap = Map<String, double>();
    for (var i = 0; i < monthsAngka.length; i++) {
      var bulan = "";

      if (monthsAngka[i].toString().length == 1) {
        bulan = "0" + monthsAngka[i].toString();
      }else{
        bulan = monthsAngka[i].toString();
      }

      if(widget.dataType == 0){
        int incomeSum = await _moorDatabaseService.getIncomeSum(bulan, date.year.toString());
        // print("incomeSum "+incomeSum.toString());
        FlSpotdata.add(FlSpot(i.toDouble(), (incomeSum /100 ).toDouble()));
        showIndexes.add(i);
      }else{
        showIndexes.add(i);
        int expenseSum = await _moorDatabaseService.getExpenseSum(bulan, date.year.toString());
        FlSpotdata.add(FlSpot(i.toDouble(), (expenseSum /100 ).toDouble()));
      }

    }

    if (FlSpotdata != null && FlSpotdata.isNotEmpty) {
      dynamic max = FlSpotdata.first;
      FlSpotdata.forEach((e) {
        if (e.y > max.y) max = e;
      });
      print(max.y.round() +10);
      dataMax = (max.y.round() +10).toDouble();
      print(dataMax);
      // dataMax = int.parse(max.y.round() +10).toDouble();
    }

    setState(() {
      globals.dataBodylineChart = LineChartMonth(FlSpotdata, dataMax, showIndexes);
    });
  }

  @override
  Widget build(BuildContext context) {
    return  BaseView<HomeModel>(
        onModelReady: (model) async {
          await model.init();
          getdata(model.currentTimeModel);
          globals.dataBodylineChart = LineChartMonth(widget.FlSpotdata, widget.dataMax, widget.showIndexes);
        },
        builder: (context, model, child) =>
            Scaffold(
              key: _scaffoldKey,
              appBar: AppBar(
                leading: IconButton(
                  icon: Icon(
                    Icons.arrow_back_ios,
                    color: Colors.white,
                  ),
                  onPressed: () {
                    // setState(() {
                    //   globals.selectedIndexBottomNav = 1;
                    // });
                    Navigator.of(context).pop();
                    // Navigator.of(context).pushNamed("home");
                    // do something
                  },
                ),
                centerTitle: true,
                title: Text(widget.title),
              ),
              body: Column(
                children: [
                 Container(
                   color: backgroundColor,
                   child:  Row(
                     mainAxisAlignment: MainAxisAlignment.spaceAround,
                     children: [
                       IconButton(
                         color: Colors.white,
                         iconSize: 40,
                         icon: const Icon(Icons.chevron_left),
                         onPressed: () async{
                         var tempdateNow = model.currentTimeModel;
                         DateTime dateNow = DateTime(tempdateNow.year - 1, tempdateNow.month , tempdateNow.day);
                         await model.update(dateNow.toString());
                         getdata(dateNow);
                         setState(() {
                           globals.Tittle = Waktu(model.currentTimeModel).LLL() + " " +model.currentTimeModel.year.toString();

                         });


                         },
                       ),
                       Container(
                           child: Center(
                             child: Text(globals.Tittle, style: TextStyle(color: Colors.white)),
                           )
                       ),
                       IconButton(
                         color: Colors.white,
                         iconSize: 40,
                         icon: const Icon(Icons.chevron_right),
                         onPressed: () async {
                           var tempdateNow = model.currentTimeModel;
                           DateTime dateNow = DateTime(tempdateNow.year + 1, tempdateNow.month , tempdateNow.day);
                           await model.update(dateNow.toString());
                           getdata(dateNow);
                           // await StatsBar().ge;
                           setState(() {
                             globals.Tittle = Waktu(model.currentTimeModel).LLL() + " " +model.currentTimeModel.year.toString();

                           });
                         },
                       ),
                     ],
                   ),
                 ),
                  Container(
                    child: globals.dataBodylineChart ,
                  ),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        // boxShadow: [
                        //   BoxShadow(color: Colors.green, spreadRadius: 3),
                        // ],
                      ),
                      // color: Colors.white,
                      child: ListView(
                        // padding: const EdgeInsets.all(8),
                        children: <Widget>[
                          Container(
                            height: 50,
                            decoration: BoxDecoration(
                              // borderRadius: BorderRadius.circular(10),
                              color: greenYellow,
                              boxShadow: [
                                BoxShadow(color: Colors.grey, spreadRadius: 3),
                              ],
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: 10, right: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    // mainAxisAlignment: MainAxisAlignment.spaceAround,
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(right: 30),
                                        child:Text("06 tue" ,style: TextStyle(color: midnightBlue),),),
                                      Text("Rp.0",style: TextStyle(color: midnightBlue))
                                    ],
                                  ),
                                  // Padding(padding: EdgeInsets.only(right: 30),
                                  // child:,),
                                  Text("Rp.1000",style: TextStyle(color: midnightBlue))
                                ],
                              ),
                            ),
                          ),
                          // Divider(color: Colors.black,),
                          Container(
                              height: 50,
                              decoration: BoxDecoration(
                                // borderRadius: BorderRadius.circular(10),
                                color: greenYellow,
                                boxShadow: [
                                  BoxShadow(color: Colors.grey, spreadRadius: 3),
                                ],
                              ),
                              child: Padding(
                                padding: EdgeInsets.only(left: 10, right: 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [

                                    Row(
                                      // mainAxisAlignment: MainAxisAlignment.spaceAround,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(right: 30),
                                          child: Text("Food",style: TextStyle(color: midnightBlue)),),
                                        Column(
                                          children: [
                                            Text("Test",style: TextStyle(color: midnightBlue)),
                                            Text("Cash",style: TextStyle(color: midnightBlue))
                                          ],
                                        ),
                                      ],
                                    ),
                                    Text("Rp.1000",style: TextStyle(color: midnightBlue))
                                  ],
                                ),
                              )
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
            )
    );

  }

}
