import 'dart:io';

import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:intl/intl.dart';
import 'package:moneymanager/core/viewmodels/details_model.dart';

class DetailsTable extends StatelessWidget {
  const DetailsTable({
    Key key,
    @required this.transaction,
    @required this.model,
  }) : super(key: key);

  final DetailsModel model;
  final Transaction transaction;


  @override
  Widget build(BuildContext context) {
    final formatCurrency = new NumberFormat.simpleCurrency(locale: 'id_ID');
    double width = MediaQuery.of(context).size.width;
    return   Container(
      child: new Column(
        children: <Widget>[
          new ListTile(
            leading: Container(
              child: Text("Date"),
              width: width / 4.5,
            ),
            title: new TextFormField(
              initialValue :transaction.day+"-"+transaction.month+"-"+transaction.year,
              // controller: _dateController,
              readOnly: true,
              decoration: InputDecoration(
                // errorText: _validateDate ? 'Please input this field' : null,
              ),
              onTap: (){
                // _showModalCalendar(context);
              },
            ),
          ),
          new ListTile(

            leading: Container(
              child: Text("Account"),
              width: width / 4.5,
            ),
            title:  new TextFormField(
              initialValue : model.getAccountIconName( transaction.categoryindex, transaction.type),

              // controller: _accountController,
              decoration: InputDecoration(
                // errorText: _validateAccount ? 'Please input this field' : null,
              ),
              onTap: (){
                // _showModalAccount(context, model);
              },
              readOnly: true,
            ),
          ),
          new ListTile(
            leading: Container(
              child: Text("Category"),
              width: width / 4.5,
            ),
            title: new TextFormField(
              initialValue : model.getCategoryIconName(
                  transaction.categoryindex, transaction.type),
              // controller: _categoryController,
              decoration: InputDecoration(
                // errorText: _validateCategory ? 'Please input this field' : null,
              ),
              onTap: (){
                final index = DefaultTabController.of(context).index;
                print(index);
                // _showModalCategory(context, model, index);
              },
              readOnly: true,
            ),
          ),
          new ListTile(
            leading: Container(
              child: Text("Amount"),
              width: width / 4.5,
            ),
            title: new TextFormField(
              initialValue : formatCurrency.format(transaction.amount).toString(),
              decoration: InputDecoration(
                // errorText: _validateAmmount ? 'Please input this field' : null,
              ),
              // controller: _ammountController,
              readOnly: true,
              onTap: (){
                // _showModalAmount(context);
              },
            ),
          ),
          new ListTile(
            leading: Container(
              child: Text("Note"),
              width: width / 4.5,
            ),
            title:  new TextFormField(
           initialValue : transaction.memo,
              // controller: _noteController,
            ),
          ),

          transaction.picture != "" ?
           Column(
             children: [
               GestureDetector(
                 onTap: () async {
                   await showDialog(
                       context: context,
                       builder: (_) => ImageDialog( transaction.picture)
                   );
                 },
                 child: Container(
                   width: MediaQuery.of(context).size.width,
                   height: 150,
                   decoration: BoxDecoration(
                     image: DecorationImage(
                       fit: BoxFit.cover,
                       image: FileImage(File(transaction.picture)),
                     ),
                   ),
                 ),
               ),
              Align(
               alignment: Alignment.centerLeft,
                 child: Padding(
                   padding: EdgeInsets.only(left: 12,top: 12),
                   child: Text(transaction.picturedesc),
                 ),
               )
             ],
           ) : Container()

        ],
      ),
    );
    //   Table(
    //   columnWidths: {1: FixedColumnWidth(100)},
    //   children: [
    //     TableRow(
    //       children: [
    //         Text(
    //           "Category",
    //           style: TextStyle(
    //             fontWeight: FontWeight.w300,
    //             fontSize: 18,
    //           ),
    //         ),
    //         Text(
    //           transaction.type,
    //           textAlign: TextAlign.justify,
    //           style: TextStyle(
    //             fontWeight: FontWeight.w400,
    //             fontSize: 20,
    //           ),
    //         ),
    //       ],
    //     ),
    //     TableRow(
    //       children: [
    //         Text(
    //           "Ammount",
    //           style: TextStyle(
    //             fontWeight: FontWeight.w300,
    //             fontSize: 18,
    //           ),
    //         ),
    //         Text(
    //           formatCurrency.format(transaction.amount).toString(),
    //           textAlign: TextAlign.justify,
    //           style: TextStyle(
    //             fontWeight: FontWeight.w400,
    //             fontSize: 20,
    //           ),
    //         ),
    //       ],
    //     ),
    //     TableRow(
    //       children: [
    //         Text(
    //           "Date",
    //           style: TextStyle(
    //             fontWeight: FontWeight.w300,
    //             fontSize: 18,
    //           ),
    //         ),
    //         Text(
    //           transaction.day + ", " + transaction.month,
    //           textAlign: TextAlign.justify,
    //           style: TextStyle(
    //             fontWeight: FontWeight.w400,
    //             fontSize: 20,
    //           ),
    //         ),
    //       ],
    //     ),
    //     TableRow(
    //       children: [
    //         Text(
    //           "Memo",
    //           style: TextStyle(
    //             fontWeight: FontWeight.w300,
    //             fontSize: 18,
    //           ),
    //         ),
    //         Text(
    //           transaction.memo,
    //           style: TextStyle(
    //             fontWeight: FontWeight.w400,
    //             fontSize: 20,
    //           ),
    //         ),
    //       ],
    //     ),
    //     // TableRow(
    //     //   children: [
    //     //     Text(
    //     //       "Image",
    //     //       style: TextStyle(
    //     //         fontWeight: FontWeight.w300,
    //     //         fontSize: 18,
    //     //       ),
    //     //     ),
    //     //     Container(
    //     //       width: MediaQuery.of(context).size.width,
    //     //       height: 150,
    //     //       decoration: BoxDecoration(
    //     //         image: DecorationImage(
    //     //           fit: BoxFit.cover,
    //     //           image: FileImage(File(transaction.picture)),
    //     //         ),
    //     //       ),
    //     //     ),
    //     //   ],
    //     // )
    //   ],
    // );
  }
}


class ImageDialog extends StatelessWidget {
  final path;
  ImageDialog( this.path);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Navigator.pop(context);
      },
      child:  Dialog(
        child: Container(
          // width: 200,
          // height: 500,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image:  FileImage(File(path)),
                  fit: BoxFit.cover
              )
          ),
        ),
      ),
    );
  }
}