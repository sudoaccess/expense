import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/viewmodels/details_model.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
import 'package:moneymanager/ui/shared/ui_helpers.dart';
import 'package:moneymanager/ui/widgets/details_view_widgets/details_table.dart';

class DetailsCard extends StatelessWidget {
  final Transaction transaction;
  final DetailsModel model;
  DetailsCard({this.transaction, this.model});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      child: Card(
        elevation: 4,
        child: Padding(
          padding: const EdgeInsets.all(1.0),
          child: Column(
            children: <Widget>[
              Container(
                color: secondaryColor,
                child: ListTile(
                  leading: CircleAvatar(
                      radius: 25,
                      backgroundColor: Colors.white.withOpacity(.1),
                      child: model.getIconForCategory(
                          transaction.categoryindex, transaction.type)),
                  title: Text(
                    "\t\t\t" +
                        model.getCategoryIconName(
                            transaction.categoryindex, transaction.type),
                    style: TextStyle(fontSize: 30, color: Colors.white),
                  ),
                ),
              ),
              Divider(
                thickness: 1,
              ),
              UIHelper.verticalSpaceSmall(),
              DetailsTable(transaction: transaction, model: model),
            ],
          ),
        ),
      ),
    );
  }
}
