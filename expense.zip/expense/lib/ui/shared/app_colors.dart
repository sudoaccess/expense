import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

Color backgroundColor = HexColor("#2514a6");
Color secondaryColor = HexColor("#2514a6");
Color thirdColor = HexColor("#FFFFFF");
Color commentColor = Color.fromARGB(255, 255, 246, 196);

Color greenYellow = HexColor("#104172");
Color midnightBlue = HexColor("#e3e37c");
