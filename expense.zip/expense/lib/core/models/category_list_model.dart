class IncomingList {
  int id;
  String name;
  String icon;
  String status;

  bool isChecked = false;

  IncomingList(this.name, this.icon, this.status);

  IncomingList.map(dynamic obj){
    this.name = obj["name"];
    this.icon = obj["icon"];
    this.status = obj["status"];
  }

  String get _name => name;

  String get _icon => icon;


  Map<String, dynamic> toMap() {
    var map = Map<String, dynamic>();
    map["name"] = name;
    map["icon"] = icon;
    map["status"] = status;

    return map;
  }

  void setIncomingListId(int id) {
    this.id = id;
  }

  bool toggle() {
    isChecked = !isChecked;
    return isChecked;
  }
}

class ExpenseList {
  int id;
  String name;
  String icon;
  String status;

  bool isChecked = false;

  ExpenseList(this.name, this.icon, this.status);

  ExpenseList.map(dynamic obj){
    this.name = obj["name"];
    this.icon = obj["icon"];
    this.status = obj["status"];
  }

  String get _name => name;

  String get _icon => icon;


  Map<String, dynamic> toMap() {
    var map = Map<String, dynamic>();
    map["name"] = name;
    map["icon"] = icon;
    map["status"] = status;

    return map;
  }

  void setExpenseListListId(int id) {
    this.id = id;
  }
  
  bool toggle() {
    isChecked = !isChecked;
    return isChecked;
  }
}

class AccountList {
  int id;
  String name;
  String icon;
  String accountgroup;
  String ammount;
  String note;
  String status;

  bool isChecked = false;

  AccountList(this.name, this.icon, this.accountgroup, this.ammount, this.note, this.status);

  AccountList.map(dynamic obj){
    this.name = obj["name"];
    this.icon = obj["icon"];
    this.accountgroup = obj["accountgroup"];
    this.ammount = obj["ammount"];
    this.note = obj["note"];
    this.status = obj["status"];
  }

  String get _name => name;

  String get _icon => icon;


  Map<String, dynamic> toMap() {
    var map = Map<String, dynamic>();
    map["name"] = name;
    map["icon"] = icon;
    map["accountgroup"] = accountgroup;
    map["ammount"] = ammount;
    map["note"] = note;
    map["status"] = status;

    return map;
  }

  void setAccountListId(int id) {
    this.id = id;
  }
  
  bool toggle() {
    isChecked = !isChecked;
    return isChecked;
  }
}