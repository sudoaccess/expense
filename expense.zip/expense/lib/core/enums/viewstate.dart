enum ViewState { Idle, Busy }
