import 'package:flutter/material.dart';
import 'package:moneymanager/core/database/DBHelper.dart';
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:moneymanager/ui/views/category_list_view.dart';

import '../../locator.dart';
import '../database/moor_database.dart';
import '../services/moordatabase_service.dart';
import 'base_model.dart';

class SearchModel extends BaseModel {
  final MoorDatabaseService _moorDatabaseService = locator<MoorDatabaseService>();
  var allTransactions = <Transaction>[];
  var transactions = <Transaction>[];
  var _accountList = <AccountList>[];
  var _incomingList = <IncomingList>[];
  var _expenseList = <ExpenseList>[];
  var memo = '';
  var min = 0;
  var max = 0;

  SearchModel() {
    _onInit();
  }

  void _onInit() async {
    final db = DBHelper();
    _accountList = await db.getAccountList("accountlist");
    _incomingList = await db.getIncomingList("incominglist");
    _expenseList = await db.getExpenseList("expenselist");
  }

  void getAllTransactions() async {
    final queries = <Future<List<Transaction>>>[];

    for (var i = 2021; i <= 2022; i++) {
      for (var j = 1; j <= 12; j++) {
        final month = j.toString().length == 1 ? '0$j' : '$j';
        queries.add(_moorDatabaseService.getAllTransactions(month, '$i'));
      }
    }

    final result = await Future.wait(queries);

    allTransactions = result.expand((element) => element).toList();
  }

  void getTransaction({String memo, String min, String max}) {
    if (memo != null) {
      this.memo = memo;
    }

    if (min != null) {
      this.min = int.parse(min.isNotEmpty ? min : '0');
    }

    if (max != null) {
      this.max = int.parse(max.isNotEmpty ? max : '0');
    }

    transactions = allTransactions.where((element) {
      var memoValidate = false;
      var minValidate = false;
      var maxValidate = false;

      if (this.memo.isNotEmpty) {
        memoValidate = this.memo.trim() == element.memo.trim();
      }

      if (this.min != 0) {
        minValidate = this.min >= element.amount;
      }

      if (this.max != 0) {
        maxValidate = this.max <= element.amount;
      }

      return memoValidate || minValidate || maxValidate;
    }).toList();

    transactions = transactions.map((e) {
      e.account =
          _accountList.firstWhere((element) => e.accountindex == element.id)?.name ?? 'account:${e.accountindex}';

      if (e.type == 'expense') {
        e.category =
            _expenseList.firstWhere((element) => e.categoryindex == element.id)?.name ?? 'expense:${e.categoryindex}';
      } else {
        e.category = _incomingList.firstWhere((element) => e.categoryindex == element.id)?.name ??
            'incoming:${e.categoryindex}';
      }

      return e;
    }).toList();

    notifyListeners();
  }
}
