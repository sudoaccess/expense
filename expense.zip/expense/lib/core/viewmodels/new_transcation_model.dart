
import 'package:flutter/cupertino.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/models/category.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/core/services/moordatabase_service.dart';
import 'package:moneymanager/core/viewmodels/base_model.dart';
import 'package:moneymanager/locator.dart';
import 'dart:io';
/// This is the stateless widget that the main application instantiates.
import 'dart:async';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:toast/toast.dart';

class NewTransactionModel extends BaseModel {
  final CategoryIconService _categoryIconService = locator<CategoryIconService>();
  final MoorDatabaseService _moorDatabaseService = locator<
      MoorDatabaseService>();
  int selectedCategory = 2; // 1=>income,2=>expense


  List months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];

  void changeSelectedItem(int newItemIndex) {
    selectedCategory = newItemIndex;

    notifyListeners();
  }

  List<Category> loadCategoriesIcons() {
    if (selectedCategory == 1) {
      // load income
      List<Category> s = _categoryIconService.incomeList.toList();
      return s;
    } else {
      // load expense
      List<Category> s = _categoryIconService.expenseList.toList();
      return s;
    }
  }

  List<Category> loadCategoriesIncome() {
    List<Category> s = _categoryIconService.incomeList.toList();
    return s;
  }

  List<Category> loadCategoriesExpense() {
    List<Category> s = _categoryIconService.expenseList.toList();
    return s;
  }

  List<Category> loadCategoriesAcount() {
    List<Category> s = _categoryIconService.accountlist.toList();
    return s;
  }

  File _image;

  addTransaction(context, type, date, memo, picture, pictureUrl, picturedesc, amount, categoryindex, accountindex, from, to) async {

    var newAmmount = amount.replaceAll(",","");
    Directory tempDir = await getTemporaryDirectory();
    String tempPath = tempDir.path;
    DateTime now = DateTime.now();
    String formattedDate = DateFormat('yyyy-MM-dd–kk:mm:ss').format(now);
    String fileName = formattedDate+".png";

    DateTime now2 = DateTime.parse(date); //DateTime.now();

    final date2 = now2;
    final startOfYear = new DateTime(date2.year, 1, 1, 0, 0);
    final firstMonday = startOfYear.weekday;
    final daysInFirstWeek = 8 - firstMonday;
    final diff = date2.difference(startOfYear);
    var weeks = ((diff.inDays - daysInFirstWeek) / 7).ceil();
    if(daysInFirstWeek > 3) {
      weeks += 1;
    }


    // print("categoryindex "+categoryindex.toString());
    var dataImageSend = "";
    if(pictureUrl != ""){
      final newImagetemp = File(pictureUrl);
      final File newImage = await newImagetemp.copy('$tempPath/$fileName');
       dataImageSend= '$tempPath/$fileName';
    }
    var string = date;
    var dateSelect = string.split("-");
    Transaction newTransaction = new Transaction(
        type: type,
        day: dateSelect[2].toString(),
        month: dateSelect[1].toString(),
        year: dateSelect[0].toString(),
        week: weeks.toString(),
        memo: memo,
        picture: dataImageSend,
        picturedesc: picturedesc,
        amount: int.parse(newAmmount),
        categoryindex: categoryindex,
        accountindex: accountindex,
        from: from,
        to: to,
        status: "0");
    // insert it!
    await _moorDatabaseService.insertTransaction(newTransaction);
    //
    // Toast.show("Added successfully!", context,
    //     duration: Toast.LENGTH_SHORT, gravity: Toast.BOTTOM);
    // // // return to the home
    Navigator.of(context).pushNamedAndRemoveUntil('home', (Route<dynamic> route) => false);
  }
}
