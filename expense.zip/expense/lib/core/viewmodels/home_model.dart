import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:moneymanager/core/database/moor_database.dart';
import 'package:moneymanager/core/enums/viewstate.dart';
import 'package:moneymanager/core/services/category_icon_service.dart';
import 'package:moneymanager/core/services/moordatabase_service.dart';
import 'package:moneymanager/core/viewmodels/base_model.dart';

import '../../locator.dart';

class HomeModel extends BaseModel {
  final MoorDatabaseService _moorDatabaseService =locator<MoorDatabaseService>();

  final CategoryIconService _categoryIconService =
      locator<CategoryIconService>();

  ScrollController scrollController =
      new ScrollController(); // set controller on scrolling
  bool show = true;
  List dataTemp = [];
  List months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];
  List monthsID = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei','Jun','Jul','Agt','Sep','Okt','nov','Des'];

  List<Transaction> transactions = List<Transaction>();
  bool isCollabsed = false;
  String appBarTitle; // selected month
  String selectedYear;
  int selectedMonthIndex; // from month list above

  DateTime currentTimeModel = DateTime.now();
  int expenseSum = 0;
  int incomeSum = 0;
  int transferSum = 0;

  int expenseSumPerDay = 0;
  int incomeSumPerDay = 0;
  int transferSumPerDay = 0;

  int expenseSumPerWeek = 0;
  int incomeSumPerWeek = 0;
  int transferSumPerWeek = 0;

  int expenseSumPerDayTemp = 0;
  int incomeSumPerDayTemp = 0;
  int transferSumPerDayTemp = 0;
  List ListdataWeek = [];

  monthClicked(String clickedMonth, String tahun) async {

    // int dataSelected = months.indexOf(clickedMonth);
    String whereQuery = clickedMonth.toString() ;
    // String bulanReal = "";
    //
    // for (var i = 0; i < months.length; i++) {
    //   String bulan = "";
    //   if((i+1) < 10){
    //     bulan = "0"+(i+1).toString();
    //   }else{
    //     bulan = (i+1).toString();
    //   }
    //   if(bulanReal == ""){
    //     if (i == dataSelected){
    //       bulanReal = bulan;
    //     }
    //   }
    // }

    DateTime newData =  DateTime.utc(int.parse(tahun) , int.parse(clickedMonth), DateTime.now().day );

    currentTimeModel = newData;
    // print(newData.toString());
    selectedMonthIndex = months.indexOf(clickedMonth);
    appBarTitle = clickedMonth;
    // print("currentTimeModel "+currentTimeModel.toString());
    expenseSum = await _moorDatabaseService.getExpenseSum(whereQuery, currentTimeModel.year.toString());
    incomeSum = await _moorDatabaseService.getIncomeSum(whereQuery, currentTimeModel.year.toString());
    transferSum = await _moorDatabaseService.getTransferSum(whereQuery, currentTimeModel.year.toString());
    transactions = await _moorDatabaseService.getAllTransactions(whereQuery, currentTimeModel.year.toString());
    titleClicked();
    notifyListeners();
    // setState(ViewState.Busy);
  }

  titleClicked() {
    isCollabsed = !isCollabsed;
    notifyListeners();
  }

  getColor(month) {

    var datatemp = currentTimeModel.toString().split(" ");
    var datatemp2 = datatemp[0].split("-");
    int dataMonth = int.parse(datatemp2[1]) - 1;

    int monthIndex = dataMonth;
    if (monthIndex == month) {
      return Colors.orange;
    } else {
      return Colors.black;
    }
  }

  void closeMonthPicker() {
    isCollabsed = false;
    notifyListeners();
  }

  void prevMonth(){
    var date =  currentTimeModel;
    var newDate = new DateTime(date.year, date.month - 1, date.day);
    DateTime datetime2 = DateTime.parse(newDate.toString());
    currentTimeModel = datetime2;
    notifyListeners();
  }

  void nextMonth(){
    var date =  currentTimeModel;
    var newDate = new DateTime(date.year, date.month +1, date.day);
    DateTime datetime2 = DateTime.parse(newDate.toString());
    currentTimeModel = datetime2;
    notifyListeners();
  }

  void prevYear(){
    var date =  currentTimeModel;
    var newDate = new DateTime(date.year - 1, date.month, date.day);
    DateTime datetime2 = DateTime.parse(newDate.toString());
    currentTimeModel = datetime2;
    notifyListeners();
  }

  void nextYear(){
    var date =  currentTimeModel;
    var newDate = new DateTime(date.year +1, date.month, date.day);
    DateTime datetime2 = DateTime.parse(newDate.toString());
    currentTimeModel = datetime2;
    notifyListeners();
  }

  init( ) async {
    handleScroll();
    selectedMonthIndex = DateTime.now().month ;
    appBarTitle = months[selectedMonthIndex];
    setState(ViewState.Busy);
    notifyListeners();

    String bulan = "";
    if((selectedMonthIndex) < 10){
      bulan = "0"+(selectedMonthIndex).toString();
    }else{
      bulan = (selectedMonthIndex).toString();
    }
    currentTimeModel = currentTimeModel;
    expenseSum = await _moorDatabaseService.getExpenseSum(bulan, currentTimeModel.year.toString());
    incomeSum = await _moorDatabaseService.getIncomeSum(bulan, currentTimeModel.year.toString());
    transferSum = await _moorDatabaseService.getTransferSum(bulan, currentTimeModel.year.toString());
    transactions = await _moorDatabaseService.getAllTransactions(bulan, currentTimeModel.year.toString());



    for (var i = 0; i < transactions.length; i++) {
      expenseSumPerDay = await _moorDatabaseService.getExpenseSumPerDay(bulan, transactions[i].year.toString(), transactions[i].day.toString());
      incomeSumPerDay  = await _moorDatabaseService.getIncomeSumPerDay(bulan, transactions[i].year.toString(), transactions[i].day.toString());
      transferSumPerDay  = await _moorDatabaseService.getTransferSumPerDay(bulan, transactions[i].year.toString(), transactions[i].day.toString());
      transactions[i].incomeSumPerDay = incomeSumPerDay;
      transactions[i].expenseSumPerDay = expenseSumPerDay;
      transactions[i].transferSumPerDay = transferSumPerDay;

    }



    setState(ViewState.Idle);
    notifyListeners();
  }

  update(datetime) async {


    handleScroll();
    var date =  DateTime.parse(datetime);
    var newDate = date.month ;
    selectedMonthIndex = DateTime.now().month;
    appBarTitle = months[selectedMonthIndex];
    setState(ViewState.Busy);
    notifyListeners();
    String bulan = "";
    if(newDate < 10){
      bulan = "0"+newDate.toString();
    }else{
      bulan = newDate.toString();
    }

    final date2 = date;
    final startOfYear = new DateTime(date2.year, 1, 1, 0, 0);
    final firstMonday = startOfYear.weekday;
    final daysInFirstWeek = 8 - firstMonday;
    final diff = date2.difference(startOfYear);
    var weeks = ((diff.inDays - daysInFirstWeek) / 7).ceil();
    if(daysInFirstWeek > 3) {
      weeks += 1;
    }


    currentTimeModel = date;
    expenseSum = await _moorDatabaseService.getExpenseSum(bulan, currentTimeModel.year.toString());
    incomeSum = await _moorDatabaseService.getIncomeSum(bulan, currentTimeModel.year.toString());
    transferSum = await _moorDatabaseService.getTransferSum(bulan, currentTimeModel.year.toString());

    expenseSumPerWeek = await _moorDatabaseService.getExpenseSumPerWeek(weeks.toString(), currentTimeModel.year.toString());
    incomeSumPerWeek  = await _moorDatabaseService.getIncomeSumPerWeek(weeks.toString(), currentTimeModel.year.toString());
    transferSumPerWeek  = await _moorDatabaseService.getTransferSumPerWeek(weeks.toString(), currentTimeModel.year.toString());

    transactions = await _moorDatabaseService.getAllTransactions(bulan, currentTimeModel.year.toString());

    for (var i = 0; i < transactions.length; i++) {
      expenseSumPerDay = await _moorDatabaseService.getExpenseSumPerDay(bulan, transactions[i].year.toString(), transactions[i].day.toString());
      incomeSumPerDay  = await _moorDatabaseService.getIncomeSumPerDay(bulan, transactions[i].year.toString(), transactions[i].day.toString());
      transferSumPerDay  = await _moorDatabaseService.getTransferSumPerDay(bulan, transactions[i].year.toString(), transactions[i].day.toString());
      transactions[i].incomeSumPerDay = incomeSumPerDay;
      transactions[i].expenseSumPerDay = expenseSumPerDay;
      transactions[i].transferSumPerDay = transferSumPerDay;
    }
    setState(ViewState.Idle);
    notifyListeners();
  }


  getdataPerweek(listData) async {


    handleScroll();

      List dataTemp =[];

    for (var i = 0; i < listData.length; i++) {


        expenseSumPerWeek = await _moorDatabaseService.getExpenseSumPerWeek(listData[i]["week"].toString(), listData[i]["year"].toString());
        incomeSumPerWeek  = await _moorDatabaseService.getIncomeSumPerWeek(listData[i]["week"].toString(), listData[i]["year"].toString());
        transferSumPerWeek  = await _moorDatabaseService.getTransferSumPerWeek(listData[i]["week"].toString(), listData[i]["year"].toString());

        dataTemp.add({"incomeSumPerWeek" : incomeSumPerWeek, "expenseSumPerWeek" : expenseSumPerWeek, "transferSumPerWeek" : transferSumPerWeek});
    }

    ListdataWeek = await dataTemp;
    // print("ListdataWeek "+ListdataWeek.toString());



    setState(ViewState.Idle);
    notifyListeners();
  }

  getPerDay(datetime) async {

    handleScroll();

    selectedMonthIndex = DateTime.now().month;
    appBarTitle = months[selectedMonthIndex];
    setState(ViewState.Busy);
    notifyListeners();
    var date =  DateTime.parse(datetime);
    var newDate = date.month ;
    String bulan = "";
    if(newDate < 10){
      bulan = "0"+newDate.toString();
    }else{
      bulan = newDate.toString();
    }


    var newDateDay = date.day ;
    String hari = "";
    if(newDateDay < 10){
      hari = "0"+newDateDay.toString();
    }else{
      hari = newDateDay.toString();
    }

    expenseSumPerDay = await _moorDatabaseService.getExpenseSumPerDay(bulan, date.year.toString(), hari);
    incomeSumPerDay  = await _moorDatabaseService.getIncomeSumPerDay(bulan, date.year.toString(), hari.toString());
    transferSumPerDay  = await _moorDatabaseService.getTransferSumPerDay(bulan, date.year.toString(), hari.toString());

// print(bulan.toString() + hari.toString());
    transactions = await _moorDatabaseService.getTransactionsPerDay(bulan, date.year.toString(), hari);

    setState(ViewState.Idle);
    notifyListeners();
  }

  Future<Map<String, dynamic>> getPerDay2(datetime) async {
    var date =  DateTime.parse(datetime);

    var newDate = date.month ;
    selectedMonthIndex = DateTime.now().month;
    String bulan = "";
    if(newDate < 10){
      bulan = "0"+newDate.toString();
    }else{
      bulan = newDate.toString();
    }
    expenseSumPerDay = await _moorDatabaseService.getExpenseSumPerDay(bulan, date.year.toString(), date.day.toString());
    incomeSumPerDay  = await _moorDatabaseService.getIncomeSumPerDay(bulan, date.year.toString(), date.day.toString());
    transferSumPerDay  = await _moorDatabaseService.getTransferSumPerDay(bulan, date.year.toString(), date.day.toString());
    transactions = await _moorDatabaseService.getTransactionsPerDay(bulan, date.year.toString(), date.day.toString());
    // return ;
  }


  void handleScroll() async {
    scrollController.addListener(() {
      if (scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        hideFloationButton();
      }
      if (scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        showFloationButton();
      }
    });
  }


  void setCurrentdate(date) async {
    print("date date  "+date.toString());
    currentTimeModel = date;
    notifyListeners();
  }
  void showFloationButton() {
    show = true;
    notifyListeners();
  }

  void hideFloationButton() {
    show = false;
    notifyListeners();
  }

  Icon getIconForCategory(int index, String type) {
    if (type == 'income') {
      final categoryIcon = _categoryIconService.incomeList.elementAt(index);

      // return Icon(
      //   categoryIcon.icon,
      //   color: categoryIcon.color,
      // );
    } else {
      final categoryIcon = _categoryIconService.expenseList.elementAt(index);

      // return Icon(
      //   categoryIcon.icon,
      //   color: categoryIcon.color,
      // );
    }
  }
}
