import 'package:moneymanager/core/database/moor_database.dart';

class MoorDatabaseService {
  final AppDatabase _database = AppDatabase();

  getAllTransactions(String month, String year) async {
    List<Transaction> allTrans = List<Transaction>();

    TransactionDao transactionDao = _database.transactionDao;

    allTrans = await transactionDao.getTransactionForMonth(month, year).get();
    return allTrans;
  }

  getAllTransactionsForYear(String year) async {
    List<Transaction> allTrans = List<Transaction>();

    TransactionDao transactionDao = _database.transactionDao;

    allTrans = await transactionDao.getTransactionForYear( year).get();
    return allTrans;
  }

  getAllTransactionsForTime() async {
    List<Transaction> allTrans = List<Transaction>();

    TransactionDao transactionDao = _database.transactionDao;

    allTrans = await transactionDao.getTransactionForTime().get();
    return allTrans;
  }

  getTransactionsPerDay(String month, String year,  String day) async {
    List<Transaction> allTrans = List<Transaction>();

    TransactionDao transactionDao = _database.transactionDao;

    allTrans = await transactionDao.getTransactionForDay(month, year, day).get();
    return allTrans;
  }

  getIncomeSum(String month, String year) async {
    List<int> list = await _database.transactionDao
        .sumTheMoneyForMonth(month, year,  "income")
        .get();

    int sumOfIncome = 0;

    if (list == null && list.length == 0) {
      return 0;
    }

    list.forEach((element) {
      if (element == null) {
        return;
      }
      sumOfIncome += element;
    });

    return sumOfIncome;
  }

  getTransferSum(String month, String year) async {
    List<int> list = await _database.transactionDao
        .sumTheMoneyForMonth(month, year, "transfer")
        .get();

    int sumOfIncome = 0;

    if (list == null && list.length == 0) {
      return 0;
    }

    list.forEach((element) {
      if (element == null) {
        return;
      }
      sumOfIncome += element;
    });

    return sumOfIncome;
  }

  getIncomeSumPerDay(String month, String year, String day) async {
    List<int> list = await _database.transactionDao
        .sumTheMoneyForDay(month, year, "income", day)
        .get();

    int sumOfIncome = 0;

    if (list == null && list.length == 0) {
      return 0;
    }

    list.forEach((element) {
      if (element == null) {
        return;
      }
      sumOfIncome += element;
    });

    return sumOfIncome;
  }

  getIncomeSumPerWeek(String week, String year) async {
    List<int> list = await _database.transactionDao
        .sumTheMoneyForWeek(week, "income", year)
        .get();

    int sumOfIncome = 0;

    if (list == null && list.length == 0) {
      return 0;
    }

    list.forEach((element) {
      if (element == null) {
        return;
      }
      sumOfIncome += element;
    });

    return sumOfIncome;
  }

  getTransferSumPerDay(String month,  String year, String day) async {
    // print(day);
    List<int> list = await _database.transactionDao.sumTheMoneyForDay(month, year, "transfer", day).get();

    int sumOfIncome = 0;

    if (list == null && list.length == 0) {
      return 0;
    }

    list.forEach((element) {
      if (element == null) {
        return;
      }
      sumOfIncome += element;
    });

    return sumOfIncome;
  }

  getTransferSumPerWeek(String week, String year) async {
    // print(day);
    List<int> list = await _database.transactionDao.sumTheMoneyForWeek(week, "transfer", year).get();

    int sumOfIncome = 0;

    if (list == null && list.length == 0) {
      return 0;
    }

    list.forEach((element) {
      if (element == null) {
        return;
      }
      sumOfIncome += element;
    });

    return sumOfIncome;
  }

  getExpenseSum(String month, String year) async {
    List<int> list = await _database.transactionDao
        .sumTheMoneyForMonth(month, year, "expense")
        .get();

    int sumOfExpense = 0;

    if (list == null && list.length == 0) {
      return 0;
    }

    list.forEach((element) {
      if (element == null) {
        return;
      }
      sumOfExpense += element;
    });

    return sumOfExpense;
  }

  getExpenseSumPerDay(String month, String year, String day) async {
    List<int> list = await _database.transactionDao
        .sumTheMoneyForDay(month, year, "expense", day)
        .get();

    int sumOfExpense = 0;

    if (list == null && list.length == 0) {
      return 0;
    }

    list.forEach((element) {
      if (element == null) {
        return;
      }
      sumOfExpense += element;
    });

    return sumOfExpense;
  }

  getExpenseSumPerWeek(String week, String year) async {
    List<int> list = await _database.transactionDao
        .sumTheMoneyForWeek(week, "expense", year)
        .get();

    int sumOfExpense = 0;

    if (list == null && list.length == 0) {
      return 0;
    }

    list.forEach((element) {
      if (element == null) {
        return;
      }
      sumOfExpense += element;
    });

    return sumOfExpense;
  }

  Future deleteTransaction(Transaction transaction) async {
    return await _database.transactionDao.deleteTransaction(transaction);
  }

  Future insertTransaction(Transaction transaction) async {
    return await _database.transactionDao.insertTransaction(transaction);
  }

  Future updateTransaction(Transaction transaction) async {
    return await _database.transactionDao.updateTransaction(transaction);
  }

  getAllTransactionsForType(String month, String year, String type) async {
    return await _database.transactionDao
        .getAllTransactionsForType(month, year, type)
        .get();
  }

  getAllTransactionsPerWeek(String week, String month, String year) async {
    return await _database.transactionDao
        .getAllTransactionsPerWeek(week, month, year )
        .get();
  }

  Future getCountTransactionBycategory(String category, String type) async {
    double data = await _database.transactionDao.getCountTransactionBycategory(category, type);
     return data;
  }
}
