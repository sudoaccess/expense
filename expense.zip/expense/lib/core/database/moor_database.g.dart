// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moor_database.dart';

// **************************************************************************
// MoorGenerator
// **************************************************************************

// ignore_for_file: unnecessary_brace_in_string_interps, unnecessary_this
class Transaction extends DataClass implements Insertable<Transaction> {
  final String type;
  final String day;
  final String month;
  final String year;
  final String week;
  final String memo;
  final String picture;
  final String picturedesc;
  int incomeSumPerDay;
  int expenseSumPerDay;
  int transferSumPerDay;
  int incomeSumPerWeek;
  int expenseSumPerWeek;
  int transferSumPerWeek;
  final int id;
  final int amount;
  final int categoryindex;
  final int accountindex;
  final String from;
  final String to;
  final String status;

  String account;
  String category;

  Transaction(
      {@required this.type,
      @required this.day,
      @required this.month,
      @required this.year,
      @required this.week,
      @required this.memo,
      @required this.picture,
      @required this.picturedesc,
      @required this.incomeSumPerDay,
      @required this.expenseSumPerDay,
      @required this.transferSumPerDay,
      @required this.incomeSumPerWeek,
      @required this.expenseSumPerWeek,
      @required this.transferSumPerWeek,
      this.id,
      @required this.amount,
      @required this.categoryindex,
      @required this.accountindex,
      @required this.from,
      @required this.to,
      @required this.status
      });
  factory Transaction.fromData(Map<String, dynamic> data, GeneratedDatabase db,
      {String prefix}) {
    final effectivePrefix = prefix ?? '';
    final stringType = db.typeSystem.forDartType<String>();
    final intType = db.typeSystem.forDartType<int>();
    return Transaction(
      type: stringType.mapFromDatabaseResponse(data['${effectivePrefix}type']),
      day: stringType.mapFromDatabaseResponse(data['${effectivePrefix}day']),
      month: stringType.mapFromDatabaseResponse(data['${effectivePrefix}month']),
      year: stringType.mapFromDatabaseResponse(data['${effectivePrefix}year']),
      week: stringType.mapFromDatabaseResponse(data['${effectivePrefix}week']),
      memo: stringType.mapFromDatabaseResponse(data['${effectivePrefix}memo']),
      picture: stringType.mapFromDatabaseResponse(data['${effectivePrefix}picture']), // stringType.mapFromDatabaseResponse(data['${effectivePrefix}picture']),
      picturedesc: stringType.mapFromDatabaseResponse(data['${effectivePrefix}picturedesc']),
      incomeSumPerDay: 0,
      expenseSumPerDay: 0,
      transferSumPerDay: 0,
      incomeSumPerWeek: 0,
      expenseSumPerWeek: 0,
      transferSumPerWeek: 0,
      id: intType.mapFromDatabaseResponse(data['${effectivePrefix}id']),
      amount: intType.mapFromDatabaseResponse(data['${effectivePrefix}amount']),
      categoryindex: intType.mapFromDatabaseResponse(data['${effectivePrefix}categoryindex']),
      accountindex: intType.mapFromDatabaseResponse(data['${effectivePrefix}accountindex']),
      from: stringType.mapFromDatabaseResponse(data['${effectivePrefix}from']),
      to: stringType.mapFromDatabaseResponse(data['${effectivePrefix}to']),
      status: stringType.mapFromDatabaseResponse(data['${effectivePrefix}status']),
    );
  }




  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || type != null) {
      map['type'] = Variable<String>(type);
    }
    if (!nullToAbsent || day != null) {
      map['day'] = Variable<String>(day);
    }
    if (!nullToAbsent || month != null) {
      map['month'] = Variable<String>(month);
    }
    if (!nullToAbsent || year != null) {
      map['year'] = Variable<String>(year);
    }
    if (!nullToAbsent || week != null) {
      map['week'] = Variable<String>(week);
    }
    if (!nullToAbsent || memo != null) {
      map['memo'] = Variable<String>(memo);
    }
    if (!nullToAbsent || picture != null) {
      map['picture'] = Variable<String>(picture);
    }
    if (!nullToAbsent || picturedesc != null) {
      map['picturedesc'] = Variable<String>(picturedesc);
    }
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || amount != null) {
      map['amount'] = Variable<int>(amount);
    }
    if (!nullToAbsent || categoryindex != null) {
      map['categoryindex'] = Variable<int>(categoryindex);
    }
    if (!nullToAbsent || accountindex != null) {
      map['accountindex'] = Variable<int>(accountindex);
    }
    if (!nullToAbsent || from != null) {
      map['from'] = Variable<String>(from);
    }
    if (!nullToAbsent || to != null) {
      map['to'] = Variable<String>(to);
    }
    if (!nullToAbsent || status != null) {
      map['status'] = Variable<String>(status);
    }
    return map;
  }

  TransactionsCompanion toCompanion(bool nullToAbsent) {
    return TransactionsCompanion(
      type: type == null && nullToAbsent ? const Value.absent() : Value(type),
      day: day == null && nullToAbsent ? const Value.absent() : Value(day),
      month:month == null && nullToAbsent ? const Value.absent() : Value(month),
      year:year == null && nullToAbsent ? const Value.absent() : Value(year),
      week:week == null && nullToAbsent ? const Value.absent() : Value(week),
      memo: memo == null && nullToAbsent ? const Value.absent() : Value(memo),
      picture: picture == null && nullToAbsent ? const Value.absent() : Value(picture),
      picturedesc: picturedesc == null && nullToAbsent ? const Value.absent() : Value(picturedesc),
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      amount: amount == null && nullToAbsent ? const Value.absent() : Value(amount),
      categoryindex: categoryindex == null && nullToAbsent ? const Value.absent() : Value(categoryindex),
      accountindex: accountindex == null && nullToAbsent ? const Value.absent() : Value(accountindex),
      from: from == null && nullToAbsent ? const Value.absent() : Value(from),
      to: to == null && nullToAbsent ? const Value.absent() : Value(to),
      status: status == null && nullToAbsent ? const Value.absent() : Value(status),
    );
  }

  factory Transaction.fromJson(Map<String, dynamic> json,
      {ValueSerializer serializer}) {
    serializer ??= moorRuntimeOptions.defaultSerializer;
    return Transaction(
      type: serializer.fromJson<String>(json['type']),
      day: serializer.fromJson<String>(json['day']),
      month: serializer.fromJson<String>(json['month']),
      year: serializer.fromJson<String>(json['year']),
      week: serializer.fromJson<String>(json['week']),
      memo: serializer.fromJson<String>(json['memo']),
      picture: serializer.fromJson<String>(json['picture']),
      picturedesc: serializer.fromJson<String>(json['picturedesc']),
      id: serializer.fromJson<int>(json['id']),
      amount: serializer.fromJson<int>(json['amount']),
      categoryindex: serializer.fromJson<int>(json['categoryindex']),
      accountindex: serializer.fromJson<int>(json['accountindex']),
      from: serializer.fromJson<String>(json['from']),
      to: serializer.fromJson<String>(json['to']),
      status: serializer.fromJson<String>(json['status']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer serializer}) {
    serializer ??= moorRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'type': serializer.toJson<String>(type),
      'day': serializer.toJson<String>(day),
      'month': serializer.toJson<String>(month),
      'year': serializer.toJson<String>(year),
      'week': serializer.toJson<String>(week),
      'memo': serializer.toJson<String>(memo),
      'picture': serializer.toJson<String>(picture),
      'picturedesc': serializer.toJson<String>(picturedesc),
      'id': serializer.toJson<int>(id),
      'amount': serializer.toJson<int>(amount),
      'categoryindex': serializer.toJson<int>(categoryindex),
      'accountindex': serializer.toJson<int>(accountindex),
      'from': serializer.toJson<String>(from),
      'to': serializer.toJson<String>(to),
      'status': serializer.toJson<String>(status),
    };
  }

  Transaction copyWith(
          {String type,
          String day,
          String month,
          String year,
          String week,
          String memo,
          String picture,
          String picturedesc,
          int id,
          int amount,
          int categoryindex,
          int accountindex,
          String from,
          String to,
          String status
          }) =>
      Transaction(
        type: type ?? this.type,
        day: day ?? this.day,
        month: month ?? this.month,
        year: year ?? this.year,
        week: week ?? this.week,
        memo: memo ?? this.memo,
        picture: picture ?? this.picture,
        picturedesc: picturedesc ?? this.picturedesc,
        id: id ?? this.id,
        amount: amount ?? this.amount,
        categoryindex: categoryindex ?? this.categoryindex,
        accountindex: accountindex ?? this.accountindex,
        from: from ?? this.from,
        to: to ?? this.to,
        status: status ?? this.status,
      );
  @override
  String toString() {
    return (StringBuffer('Transaction(')
          ..write('type: $type, ')
          ..write('day: $day, ')
          ..write('month: $month, ')
          ..write('year: $year, ')
          ..write('week: $week, ')
          ..write('memo: $memo, ')
          ..write('picture: $picture, ')
          ..write('picturedesc: $picturedesc, ')
          ..write('id: $id, ')
          ..write('amount: $amount, ')
          ..write('categoryindex: $categoryindex, ')
          ..write('accountindex: $accountindex, ')
          ..write('from: $from, ')
          ..write('to: $to, ')
          ..write('status: $status')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => $mrjf(
      $mrjc(type.hashCode,
      $mrjc(day.hashCode,
      $mrjc(month.hashCode,
      $mrjc(year.hashCode,
      $mrjc(week.hashCode,
      $mrjc(memo.hashCode,
      $mrjc(picture.hashCode,
      $mrjc(picturedesc.hashCode,
      $mrjc(id.hashCode,
      $mrjc(amount.hashCode,
      $mrjc(categoryindex.hashCode,
      $mrjc(accountindex.hashCode,
      $mrjc(from.hashCode,
      $mrjc(to.hashCode,
      status.hashCode
      )))))))))))))));
  @override
  bool operator ==(dynamic other) =>
      identical(this, other) ||
      (other is Transaction &&
          other.type == this.type &&
          other.day == this.day &&
          other.month == this.month &&
          other.year == this.year &&
          other.week == this.week &&
          other.memo == this.memo &&
          other.picture == this.picture &&
          other.picturedesc == this.picturedesc &&
          other.id == this.id &&
          other.amount == this.amount &&
          other.categoryindex == this.categoryindex &&
          other.accountindex == this.accountindex &&
          other.from == this.from &&
          other.to == this.to &&
          other.status == this.status
      );
}

class TransactionsCompanion extends UpdateCompanion<Transaction> {
  final Value<String> type;
  final Value<String> day;
  final Value<String> month;
  final Value<String> year;
  final Value<String> week;
  final Value<String> memo;
  final Value<String> picture;
  final Value<String> picturedesc;
  final Value<int> id;
  final Value<int> amount;
  final Value<int> categoryindex;
  final Value<int> accountindex;
  final Value<String> from;
  final Value<String> to;
  final Value<String> status;

  const TransactionsCompanion({
    this.type = const Value.absent(),
    this.day = const Value.absent(),
    this.month = const Value.absent(),
    this.year = const Value.absent(),
    this.week = const Value.absent(),
    this.memo = const Value.absent(),
    this.picture = const Value.absent(),
    this.picturedesc = const Value.absent(),
    this.id = const Value.absent(),
    this.amount = const Value.absent(),
    this.categoryindex = const Value.absent(),
    this.accountindex = const Value.absent(),
    this.from = const Value.absent(),
    this.to = const Value.absent(),
    this.status = const Value.absent(),
  });
  TransactionsCompanion.insert({
    @required String type,
    @required String day,
    @required String month,
    @required String year,
    @required String week,
    @required String memo,
    @required String picture,
    @required String picturedesc,
    this.id = const Value.absent(),
    @required int amount,
    @required int categoryindex,
    @required int accountindex,
    @required String from,
    @required String to,
    @required String status,
  })  : type = Value(type),
        day = Value(day),
        month = Value(month),
        year = Value(year),
        week = Value(week),
        memo = Value(memo),
        picture = Value(picture),
        picturedesc = Value(picturedesc),
        amount = Value(amount),
        categoryindex = Value(categoryindex),
        accountindex = Value(accountindex),
        from = Value(from),
        to = Value(to),
        status = Value(status);
  static Insertable<Transaction> custom({
    Expression<String> type,
    Expression<String> day,
    Expression<String> month,
    Expression<String> year,
    Expression<String> week,
    Expression<String> memo,
    Expression<String> picture,
    Expression<String> picturedesc,
    Expression<int> id,
    Expression<int> amount,
    Expression<int> categoryindex,
    Expression<int> accountindex,
    Expression<String> from,
    Expression<String> to,
    Expression<String> status,
  }) {
    return RawValuesInsertable({
      if (type != null) 'type': type,
      if (day != null) 'day': day,
      if (month != null) 'month': month,
      if (year != null) 'year': year,
      if (week != null) 'week': week,
      if (memo != null) 'memo': memo,
      if (picture != null) 'picture': picture,
      if (picturedesc != null) 'picturedesc': picturedesc,
      if (id != null) 'id': id,
      if (amount != null) 'amount': amount,
      if (categoryindex != null) 'categoryindex': categoryindex,
      if (accountindex != null) 'accountindex': accountindex,
      if (from != null) 'from': from,
      if (to != null) 'to': to,
      if (status != null) 'status': status,
    });
  }

  TransactionsCompanion copyWith(
      {Value<String> type,
      Value<String> day,
      Value<String> month,
      Value<String> year,
      Value<String> week,
      Value<String> memo,
      Value<String> picture,
      Value<String> picturedesc,
      Value<int> id,
      Value<int> amount,
      Value<int> categoryindex,
      Value<int> accountindex,
      Value<String> from,
      Value<String> to,
      Value<String> status
      }) {
    return TransactionsCompanion(
      type: type ?? this.type,
      day: day ?? this.day,
      month: month ?? this.month,
      year: year ?? this.year,
      week: year ?? this.week,
      memo: memo ?? this.memo,
      picture: picture ?? this.picture,
      picturedesc: picturedesc ?? this.picturedesc,
      id: id ?? this.id,
      amount: amount ?? this.amount,
      categoryindex: categoryindex ?? this.categoryindex,
      accountindex: accountindex ?? this.accountindex,
      from: from ?? this.from,
      to: to ?? this.to,
      status: status ?? this.status,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (day.present) {
      map['day'] = Variable<String>(day.value);
    }
    if (month.present) {
      map['month'] = Variable<String>(month.value);
    }
    if (year.present) {
      map['year'] = Variable<String>(year.value);
    }
    if (week.present) {
      map['week'] = Variable<String>(week.value);
    }
    if (memo.present) {
      map['memo'] = Variable<String>(memo.value);
    }
    if (picture.present) {
      map['picture'] = Variable<String>(picture.value);
    }
    if (picturedesc.present) {
      map['picturedesc'] = Variable<String>(picturedesc.value);
    }
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (amount.present) {
      map['amount'] = Variable<int>(amount.value);
    }
    if (categoryindex.present) {
      map['categoryindex'] = Variable<int>(categoryindex.value);
    }
    if (accountindex.present) {
      map['accountindex'] = Variable<int>(accountindex.value);
    }
    if (from.present) {
      map['from'] = Variable<String>(from.value);
    }
    if (to.present) {
      map['to'] = Variable<String>(to.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TransactionsCompanion(')
          ..write('type: $type, ')
          ..write('day: $day, ')
          ..write('month: $month, ')
          ..write('year: $year, ')
          ..write('week: $week, ')
          ..write('memo: $memo, ')
          ..write('picture: $picture, ')
          ..write('picturedesc: $picturedesc, ')
          ..write('id: $id, ')
          ..write('amount: $amount, ')
          ..write('categoryindex: $categoryindex, ')
          ..write('accountindex: $accountindex, ')
          ..write('from: $from, ')
          ..write('to: $to, ')
          ..write('status: $status')
          ..write(')'))
        .toString();
  }
}

class $TransactionsTable extends Transactions
    with TableInfo<$TransactionsTable, Transaction> {
  final GeneratedDatabase _db;
  final String _alias;
  $TransactionsTable(this._db, [this._alias]);

  final VerificationMeta _typeMeta = const VerificationMeta('type');
  GeneratedTextColumn _type;
  @override
  GeneratedTextColumn get type => _type ??= _constructType();
  GeneratedTextColumn _constructType() {
    return GeneratedTextColumn(
      'type',
      $tableName,
      false,
    );
  }

  final VerificationMeta _dayMeta = const VerificationMeta('day');
  GeneratedTextColumn _day;
  @override
  GeneratedTextColumn get day => _day ??= _constructDay();
  GeneratedTextColumn _constructDay() {
    return GeneratedTextColumn(
      'day',
      $tableName,
      false,
    );
  }

  final VerificationMeta _monthMeta = const VerificationMeta('month');
  GeneratedTextColumn _month;
  @override
  GeneratedTextColumn get month => _month ??= _constructMonth();
  GeneratedTextColumn _constructMonth() {
    return GeneratedTextColumn(
      'month',
      $tableName,
      false,
    );
  }

  final VerificationMeta _yearMeta = const VerificationMeta('year');
  GeneratedTextColumn _year;
  @override
  GeneratedTextColumn get year => _year ??= _constructYear();
  GeneratedTextColumn _constructYear() {
    return GeneratedTextColumn(
      'year',
      $tableName,
      false,
    );
  }

  final VerificationMeta _weekMeta = const VerificationMeta('week');
  GeneratedTextColumn _week;
  @override
  GeneratedTextColumn get week => _week ??= _constructWeek();
  GeneratedTextColumn _constructWeek() {
    return GeneratedTextColumn(
      'week',
      $tableName,
      false,
    );
  }

  final VerificationMeta _memoMeta = const VerificationMeta('memo');
  GeneratedTextColumn _memo;
  @override
  GeneratedTextColumn get memo => _memo ??= _constructMemo();
  GeneratedTextColumn _constructMemo() {
    return GeneratedTextColumn(
      'memo',
      $tableName,
      false,
    );
  }

  final VerificationMeta _memoPicture = const VerificationMeta('picture');
  GeneratedTextColumn _picture;
  @override
  GeneratedTextColumn get picture => _picture ??= _constructpicture();
  GeneratedTextColumn _constructpicture() {
    return GeneratedTextColumn(
      'picture',
      $tableName,
      false,
    );
  }

  final VerificationMeta _memoPictureDesc = const VerificationMeta('picturedesc');
  GeneratedTextColumn _picturedesc;
  @override
  GeneratedTextColumn get picturedesc => _picturedesc ??= _constructpicturedesc();
  GeneratedTextColumn _constructpicturedesc() {
    return GeneratedTextColumn(
      'picturedesc',
      $tableName,
      false,
    );
  }

  final VerificationMeta _idMeta = const VerificationMeta('id');
  GeneratedIntColumn _id;
  @override
  GeneratedIntColumn get id => _id ??= _constructId();
  GeneratedIntColumn _constructId() {
    return GeneratedIntColumn('id', $tableName, false,
        hasAutoIncrement: true, declaredAsPrimaryKey: true);
  }

  final VerificationMeta _amountMeta = const VerificationMeta('amount');
  GeneratedIntColumn _amount;
  @override
  GeneratedIntColumn get amount => _amount ??= _constructAmount();
  GeneratedIntColumn _constructAmount() {
    return GeneratedIntColumn(
      'amount',
      $tableName,
      false,
    );
  }

  final VerificationMeta _categoryindexMeta = const VerificationMeta('categoryindex');
  GeneratedIntColumn _categoryindex;
  @override
  GeneratedIntColumn get categoryindex => _categoryindex ??= _constructCategoryindex();
  GeneratedIntColumn _constructCategoryindex() {
    return GeneratedIntColumn(
      'categoryindex',
      $tableName,
      false,
    );
  }

  final VerificationMeta _accountindexMeta = const VerificationMeta('accountindex');
  GeneratedIntColumn _accountindex;
  @override
  GeneratedIntColumn get accountindex => _accountindex ??= _constructAccountindex();
  GeneratedIntColumn _constructAccountindex() {
    return GeneratedIntColumn(
      'accountindex',
      $tableName,
      false,
    );
  }

  final VerificationMeta _fromMeta = const VerificationMeta('from');
  GeneratedTextColumn _from;
  @override
  GeneratedTextColumn get from => _from ??= _constructFrom();
  GeneratedTextColumn _constructFrom() {
    return GeneratedTextColumn(
      'from',
      $tableName,
      false,
    );
  }

  final VerificationMeta _toMeta = const VerificationMeta('to');
  GeneratedTextColumn _to;
  @override
  GeneratedTextColumn get to => _to ??= _constructTo();
  GeneratedTextColumn _constructTo() {
    return GeneratedTextColumn(
      'to',
      $tableName,
      false,
    );
  }

  final VerificationMeta _statusMeta = const VerificationMeta('status');
  GeneratedTextColumn _status;
  @override
  GeneratedTextColumn get status => _status ??= _constructStatus();
  GeneratedTextColumn _constructStatus() {
    return GeneratedTextColumn(
      'status',
      $tableName,
      false,
    );
  }

  @override
  List<GeneratedColumn> get $columns =>
      [type, day, month, year,  week,  memo, picture, picturedesc, id, amount, categoryindex, accountindex, from, to, status];
  @override
  $TransactionsTable get asDslTable => this;
  @override
  String get $tableName => _alias ?? 'transactions';
  @override
  final String actualTableName = 'transactions';
  @override
  VerificationContext validateIntegrity(Insertable<Transaction> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('type')) {
      context.handle(
          _typeMeta, type.isAcceptableOrUnknown(data['type'], _typeMeta));
    } else if (isInserting) {
      context.missing(_typeMeta);
    }
    if (data.containsKey('day')) {
      context.handle(
          _dayMeta, day.isAcceptableOrUnknown(data['day'], _dayMeta));
    } else if (isInserting) {
      context.missing(_dayMeta);
    }
    if (data.containsKey('month')) {
      context.handle(
          _monthMeta, month.isAcceptableOrUnknown(data['month'], _monthMeta));
    } else if (isInserting) {
      context.missing(_monthMeta);
    }
    if (data.containsKey('year')) {
      context.handle(
          _yearMeta, year.isAcceptableOrUnknown(data['year'], _yearMeta));
    } else if (isInserting) {
      context.missing(_yearMeta);
    }

    if (data.containsKey('week')) {
      context.handle(
          _weekMeta, week.isAcceptableOrUnknown(data['week'], _weekMeta));
    } else if (isInserting) {
      context.missing(_weekMeta);
    }
    if (data.containsKey('memo')) {
      context.handle(
          _memoMeta, memo.isAcceptableOrUnknown(data['memo'], _memoMeta));
    } else if (isInserting) {
      context.missing(_memoMeta);
    }
    if (data.containsKey('picture')) {
      context.handle(
          _memoPicture, picture.isAcceptableOrUnknown(data['picture'], _memoPicture));
    } else if (isInserting) {
      context.missing(_memoPicture);
    }

    if (data.containsKey('picturedesc')) {
      context.handle(
          _memoPictureDesc, picturedesc.isAcceptableOrUnknown(data['picturedesc'], _memoPictureDesc));
    } else if (isInserting) {
      context.missing(_memoPictureDesc);
    }

    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id'], _idMeta));
    }
    if (data.containsKey('amount')) {
      context.handle(_amountMeta,
          amount.isAcceptableOrUnknown(data['amount'], _amountMeta));
    } else if (isInserting) {
      context.missing(_amountMeta);
    }
    if (data.containsKey('categoryindex')) {
      context.handle(  _categoryindexMeta, categoryindex.isAcceptableOrUnknown(  data['categoryindex'], _categoryindexMeta));
    } else if (isInserting) {
      context.missing(_categoryindexMeta);
    }
    if (data.containsKey('accountindex')) {
      context.handle(  _accountindexMeta, accountindex.isAcceptableOrUnknown(  data['accountindex'], _accountindexMeta));
    } else if (isInserting) {
      context.missing(_accountindexMeta);
    }
    if (data.containsKey('from')) {
      context.handle(  _fromMeta, from.isAcceptableOrUnknown(  data['from'], _fromMeta));
    } else if (isInserting) {
      context.missing(_fromMeta);
    }

    if (data.containsKey('to')) {
      context.handle(  _toMeta, to.isAcceptableOrUnknown(  data['to'], _toMeta));
    } else if (isInserting) {
      context.missing(_toMeta);
    }

    if (data.containsKey('status')) {
      context.handle(  _statusMeta, status.isAcceptableOrUnknown(  data['status'], _statusMeta));
    } else if (isInserting) {
      context.missing(_statusMeta);
    }

    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Transaction map(Map<String, dynamic> data, {String tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : null;
    return Transaction.fromData(data, _db, prefix: effectivePrefix);
  }

  @override
  $TransactionsTable createAlias(String alias) {
    return $TransactionsTable(_db, alias);
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(SqlTypeSystem.defaultInstance, e);
  $TransactionsTable _transactions;
  $TransactionsTable get transactions =>
      _transactions ??= $TransactionsTable(this);
  TransactionDao _transactionDao;
  TransactionDao get transactionDao =>
      _transactionDao ??= TransactionDao(this as AppDatabase);
  @override
  Iterable<TableInfo> get allTables => allSchemaEntities.whereType<TableInfo>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [transactions];
}

// **************************************************************************
// DaoGenerator
// **************************************************************************

mixin _$TransactionDaoMixin on DatabaseAccessor<AppDatabase> {
  $TransactionsTable get transactions => attachedDatabase.transactions;
  Selectable<Transaction> getTransactionForMonth(String month, String year) {
    return customSelect('SELECT * FROM transactions WHERE month = :month AND year = :year ',
        variables: [Variable.withString(month), Variable.withString(year)],
        readsFrom: {transactions}).map(transactions.mapFromRow);
  }

  Selectable<Transaction> getTransactionForYear(String year) {
    return customSelect('SELECT * FROM transactions WHERE  year = :year ',
        variables: [Variable.withString(year)],
        readsFrom: {transactions}).map(transactions.mapFromRow);
  }

  Selectable<Transaction> getTransactionForTime() {
    return customSelect('SELECT * FROM transactions ',
        // variables: [Variable.withString(year)],
        readsFrom: {transactions}).map(transactions.mapFromRow);
  }

  Selectable<Transaction> getTransactionForDay(String month, String year, String day) {
    return customSelect('SELECT * FROM transactions WHERE month = :month AND year = :year AND  day = :day',
        variables: [
          Variable.withString(month),
          Variable.withString(year),
          Variable.withString(day)
        ],
        // variables: [],
        readsFrom: {transactions}).map(transactions.mapFromRow);
  }

  Selectable<int> sumTheMoneyForMonth(String month, String year, String type) {
    return customSelect(
        'SELECT SUM(amount) FROM transactions WHERE month = :month AND year = :year AND type = :type',
        variables: [
          Variable.withString(month),
          Variable.withString(year),
          Variable.withString(type)
        ],
        readsFrom: {
          transactions
        }).map((QueryRow row) => row.readInt('SUM(amount)'));
  }

  Selectable<int> sumTheMoneyForDay(String month, String year, String type,  String day) {
    return customSelect(
        'SELECT SUM(amount) FROM transactions WHERE month = :month AND  year = :year AND day = :day AND type = :type ',
        variables: [
          Variable.withString(month),
          Variable.withString(year),
          Variable.withString(day),
          Variable.withString(type)
        ],
        readsFrom: {
          transactions
        }).map((QueryRow row) => row.readInt('SUM(amount)'));
  }

  Selectable<int> sumTheMoneyForWeek(String week, String type,  String year) {
    return customSelect(
        'SELECT SUM(amount) FROM transactions WHERE week = :week AND year = :year AND type = :type ',
        variables: [
          Variable.withString(week),
          Variable.withString(year),
          Variable.withString(type)
        ],
        readsFrom: {
          transactions
        }).map((QueryRow row) => row.readInt('SUM(amount)'));
  }

  Selectable<Transaction> getAllTransactionsForType(String month, String year, String type) {
    return customSelect(
        'SELECT * FROM transactions WHERE month = :month AND year = :year AND type = :type',
        variables: [Variable.withString(month),  Variable.withString(year), Variable.withString(type)],
        readsFrom: {transactions}).map(transactions.mapFromRow);
  }

  Selectable<Transaction> getAllTransactionsPerWeek(String week, String month, String year) {
    return customSelect(
        'SELECT * FROM transactions WHERE  week = :week AND month = :month AND year = :year ',
        variables: [Variable.withString(week), Variable.withString(month),  Variable.withString(year)],
        readsFrom: {transactions}).map(transactions.mapFromRow);
  }

    getCountTransactionBycategory(categoryindex, type) {

    return customSelect(
        'SELECT COUNT (*)  AS c FROM transactions WHERE categoryindex = :categoryindex AND type = :type',
          variables: [
            Variable.withString(categoryindex),
            Variable.withString(type),
        ],
        readsFrom: {
          transactions
        }).map((row) => row.readDouble('c')).getSingle();
  }
  // Selectable<int> getCountTransactionBycategory(int id) {
  //   return customSelect(
  //     'SELECT COUNT(*) AS c FROM todos WHERE category = ?',
  //     variables: [Variable.withInt(id)],
  //     readsFrom: {todos},
  //   ).map((row) => row.readInt('c')).watch();
  // }

}
