
import 'package:moneymanager/core/models/category_list_model.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:io' as io;
import 'dart:async';

class DBHelper{

  static final DBHelper _instance = new DBHelper.internal();
  DBHelper.internal();

  factory DBHelper() => _instance;

  static Database _db;

  Future<Database> get db async{
    if(_db!=null)
      return _db;
    _db = await setDB();
    return _db;
  }

  setDB()async{
    io.Directory directory = await getApplicationDocumentsDirectory();
    String path = join(directory.path, "money_manager");
    var dB = await openDatabase(path, version: 1, onCreate: _onCreate);
    return dB;
  }

  void _onCreate(Database db, int version) async{
    await db.execute("CREATE TABLE incominglist(id INTEGER PRIMARY KEY, name TEXT, icon TEXT, status TEXT)");
    await db.execute("CREATE TABLE expenselist(id INTEGER PRIMARY KEY, name TEXT, icon TEXT, status TEXT)");
    await db.execute("CREATE TABLE accountlist(id INTEGER PRIMARY KEY, name TEXT,  accountgroup TEXT, ammount TEXT, note TEXT, icon TEXT, status TEXT)");

    print("DB Created");
  }

  Future<int> saveIncomingList(table_name, IncomingList list) async{
    var dbClient = await db;
    int res=await dbClient.insert(table_name, list.toMap());
    print("Data Inserted");
    return res;
  }

  Future<int> saveExpenseList(table_name, ExpenseList list) async{
    var dbClient = await db;
    int res=await dbClient.insert(table_name, list.toMap());
    print("Data Inserted");
    return res;
  }

  Future<int> saveAccountList(table_name, AccountList list) async{
    var dbClient = await db;
    int res = await dbClient.insert(table_name, list.toMap());
    print("Data Inserted");
    print(res);
    return res;
  }


  Future<double> getCount(table_name) async {
    var dbClient = await db;
    var x = await dbClient.rawQuery('SELECT COUNT (*) from $table_name');
    int count = Sqflite.firstIntValue(x);
    print(count);
    return count.roundToDouble();
  }

  Future<double> getCountBintang(bintang, table_name) async {
    var dbClient = await db;
    var x = await dbClient.rawQuery('SELECT COUNT (*) from $table_name WHERE rating = $bintang');
    int count = Sqflite.firstIntValue(x);
    print(count);
    return count.roundToDouble();
  }

  Future<List<IncomingList>> getIncomingList( table_name) async {

    var dbClient = await db;
      List <Map> list = await dbClient.rawQuery('SELECT * FROM $table_name WHERE status = "0" ');
      List <IncomingList> dataSuggestion = new List();
      for(int i= 0 ; i <list.length ; i++){
        var suggestion = new IncomingList(list[i]["name"], list[i]["icon"], list[i]["status"]);
        suggestion.setIncomingListId(list[i]["id"]);
        dataSuggestion.add(suggestion);
      }
      return dataSuggestion;

  }

  Future<List<IncomingList>> getIncomingListByID( table_name, id) async {

    var dbClient = await db;
    List <Map> list = await dbClient.rawQuery('SELECT * FROM $table_name WHERE status = "0" AND id = $id');
    List <IncomingList> dataSuggestion = new List();
    for(int i= 0 ; i <list.length ; i++){
      var suggestion = new IncomingList(list[i]["name"], list[i]["icon"], list[i]["status"]);
      suggestion.setIncomingListId(list[i]["id"]);
      dataSuggestion.add(suggestion);
    }
    return dataSuggestion;

  }


  // Future<double> getCountcategory(table_name, categoryindex) async {
  //   var dbClient = await db;
  //   var x = await dbClient.rawQuery('SELECT COUNT (*) from $table_name WHERE categoryindex = $categoryindex');
  //   int count = Sqflite.firstIntValue(x);
  //   print(count);
  //   return count.roundToDouble();
  // }


  Future<List<ExpenseList>> getExpenseList( table_name) async {
    var dbClient = await db;
    List <Map> list = await dbClient.rawQuery('SELECT * FROM $table_name  WHERE status = "0"');
    List <ExpenseList> dataSuggestion2 = new List();
    for(int i= 0 ; i <list.length ; i++){
      var suggestion2 = new ExpenseList(list[i]["name"], list[i]["icon"], list[i]["status"]);
      suggestion2.setExpenseListListId(list[i]["id"]);
      dataSuggestion2.add(suggestion2);
    }
    return dataSuggestion2;

  }

  Future<List<ExpenseList>> getExpenseListByID( table_name, id) async {
    var dbClient = await db;
    List <Map> list = await dbClient.rawQuery('SELECT * FROM $table_name  WHERE status = "0" AND id = $id');
    List <ExpenseList> dataSuggestion2 = new List();
    for(int i= 0 ; i <list.length ; i++){
      var suggestion2 = new ExpenseList(list[i]["name"], list[i]["icon"], list[i]["status"]);
      suggestion2.setExpenseListListId(list[i]["id"]);
      dataSuggestion2.add(suggestion2);
    }
    return dataSuggestion2;

  }

  Future<List<AccountList>> getAccountList( table_name) async {
    var dbClient = await db;
    List <Map> list = await dbClient.rawQuery('SELECT * FROM $table_name WHERE status = "0" ');
    List <AccountList> dataSuggestion3 = new List();
    for(int i= 0 ; i <list.length ; i++){
      var suggestion3 = new AccountList(list[i]["name"], list[i]["icon"], list[i]["accountgroup"], list[i]["ammount"], list[i]["note"], list[i]["status"]);
      suggestion3.setAccountListId(list[i]["id"]);
      dataSuggestion3.add(suggestion3);
    }
    return dataSuggestion3;

  }

  Future<List<AccountList>> getAccountListByID( table_name, id) async {
    var dbClient = await db;
    List <Map> list = await dbClient.rawQuery('SELECT * FROM $table_name WHERE status = "0" AND id = $id ');
    List <AccountList> dataSuggestion3 = new List();
    for(int i= 0 ; i <list.length ; i++){
      var suggestion3 = new AccountList(list[i]["name"], list[i]["icon"], list[i]["accountgroup"], list[i]["ammount"], list[i]["note"], list[i]["status"]);
      suggestion3.setAccountListId(list[i]["id"]);
      dataSuggestion3.add(suggestion3);
    }
    return dataSuggestion3;

  }

    updateAccountList( table_name, id, data) async {
    var dbClient = await db;
    var list = await dbClient.rawQuery('UPDATE  $table_name SET status = $data  WHERE id = $id ');

    return list;

  }

  updateIncomingList( table_name, id, data) async {
    var dbClient = await db;
    var list = await dbClient.rawQuery('UPDATE  $table_name SET status = $data  WHERE id = $id ');

    return list;

  }

  updateExpenseList( table_name, id, data) async {
    var dbClient = await db;
    var list = await dbClient.rawQuery('UPDATE  $table_name SET status = $data  WHERE id = $id ');

    return list;

  }

}