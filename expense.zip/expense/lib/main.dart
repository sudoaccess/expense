import 'package:flutter/material.dart';
import 'package:moneymanager/locator.dart';
import 'package:moneymanager/ui/router.dart';
import 'package:moneymanager/ui/shared/app_colors.dart';
// import 'package:flutter_localizations/flutter_localizations.dart';

void main() {
  setupLocator();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // localizationsDelegates: [
      //   // GlobalMaterialLocalizations.delegate,
      //   // GlobalWidgetsLocalizations.delegate,
      // ],
      // supportedLocales: [
      //   Locale('id','ID'),
      //
      // ],
      title: 'Money Manager',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: "Nunito Sans",
        primaryColor: backgroundColor,
        accentColor: Colors.blue,
      ),
      initialRoute: '/',
      onGenerateRoute: Routeraja.generateRoute,
    );
  }
}